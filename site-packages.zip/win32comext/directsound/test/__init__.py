# This is a Python package, imported by the win32com test suite.
