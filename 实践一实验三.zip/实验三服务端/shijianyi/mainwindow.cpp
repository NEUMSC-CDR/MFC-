#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDateTime>
#include <QFile>
#include <QDir>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QJsonValue>
#include <QString>
#include <QDebug>
#include <QThread>
#include <QTcpServer>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    tcpServer = new QTcpServer(this);
    tcpServer->listen(QHostAddress::Any, 8888);
   // 使用了IPv4的本地主机地址，等价于QHostAddress("127.0.0.1")
   // 当有新的客户端接入时，QTcpServer内部会创建一个与客户端链接的QTcpServer对象，然后发射newConnection()信号
    connect(tcpServer, SIGNAL(newConnection()), this, SLOT(NewConnectionSlot())); // 有新连接时触发

    readuser(); // 读取users.json文件，获取用户名密码等信息
    ui->information->clear();
    for(int i=0;i<names.size();i++){
        ui->information->insertPlainText("用户名 "+names.at(i)+"\n密码 "+passwds.at(i)+"\n");
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::NewConnectionSlot()
{
    currentClient = tcpServer->nextPendingConnection();
    tcpClient.append(currentClient);
    connect(currentClient, SIGNAL(readyRead()), this, SLOT(ReadData()));
    connect(currentClient, SIGNAL(disconnected()), this, SLOT(disconnectedSlot()));
}

void MainWindow::ReadData()
{
    // 由于readyRead信号并未提供SocketDecriptor，所以需要遍历所有客户端
    for(int i=0; i<tcpClient.length(); i++)
    {
        QByteArray buffer = tcpClient[i]->readAll();
        if(buffer.isEmpty())    continue;
        // 获得接收到消息的client的端口和IP
        static QString IP_Port, IP_Port_Pre;
        IP_Port = tr("[%1:%2]:").arg(tcpClient[i]->peerAddress().toString().split("::ffff:")[1])\
                                     .arg(tcpClient[i]->peerPort());
        // 若此次消息的地址与上次不同，则需显示此次消息的客户端地址
        ui->logs->insertPlainText(QString("\n")+IP_Port);
//        if(buffer.size()>100){
//            ui->logs->insertPlainText(buffer.left(100)+"....");
//        }else{
//            ui->logs->insertPlainText(buffer);
//        }

        QString data = QString(buffer);
        QStringList dataList = data.split("==");

        if(dataList.at(dataList.size()-1)=="register"){
            if(dataList.size()==3){
                readuser();
                adduser(dataList[0],dataList[1]);
                QString data = "registerSuccess"; // 将char*转为QString
                currentClient->write(data.toLatin1());
                ui->information->clear();
                readuser();
                for(int i=0;i<names.size();i++){
                    ui->information->insertPlainText("用户名 "+names.at(i)+"\n密码 "+passwds.at(i)+"\n");
                }
                ui->logs->insertPlainText("用户"+dataList[0]+"注册成功,"+"密码为"+dataList[1]);
            }else{
                QString data = "registerError";
                currentClient->write(data.toLatin1());
                ui->logs->insertPlainText("注册失败");
            }

        }else if(dataList.at(dataList.size()-1)=="login"){
            readuser();
            if(names.contains(dataList[0]) && passwds[names.indexOf(dataList[0])] == dataList[1]){
                QString data = "loginSuccess";
                currentClient->write(data.toLatin1());
                ui->logs->insertPlainText("用户"+dataList[0]+"登录成功!");
            }else{
                QString data = "loginFailed";
                currentClient->write(data.toLatin1());
                ui->logs->insertPlainText("用户"+dataList[0]+"登录失败!未找到该用户或密码不正确");
            }
        }else if(dataList.at(dataList.size()-1)=="time"){
            // 获取时间请求，传递时间戳
            QDateTime time =QDateTime::currentDateTime();
            int timeT = time.toTime_t();
           /*
            * QString current_date1 =current_date_time.toString("yyyy.MM.dd hh:mm:ss ddd");
            * QString current_date2 =current_date_time.toString("yyyy-MM-dd hh-mm-ss");
            * QString current_date3 =current_date_time.toString("yyyy/MM/dd hh:mm:ss.zzz");
            * yyyy表示年；MM表示月；dd表示日； hh表示小时；mm表示分；ss表示秒；zzz表示毫秒；ddd表示周几
            * QString data= QString(current_date1)+"=="+QString(current_date2)+"=="+QString(current_date3)+"=="+"time"; // 将char*转为QString
            */
            QString data =  QString::number(timeT)+QString("==time");
            currentClient->write(data.toLatin1());
            ui->logs->insertPlainText("收到时间请求，发送时间戳："+QString::number(timeT));
        }else if(dataList.at(dataList.size()-1)=="logout"){
            QString data = "logout";
            currentClient->write(data.toLatin1());
        }else if(dataList.at(dataList.size()-1)=="filedata"){
            fileData += dataList[0];

        }else if(dataList.at(dataList.size()-1)=="fileover"){
            fileData += dataList[0]; // 文件最后的内容
            fileName = dataList[1]; // 文件名
            // 文件十六进制传输结束，保存至文件
            QDir dir(qApp->applicationDirPath()+"/files/");
            if(!dir.exists()){
                dir.mkdir(qApp->applicationDirPath()+"/files/");
            }
            QString fileSaveName = qApp->applicationDirPath()+QString("/files/")+fileName;
            saveFile(fileData,fileSaveName); // 十六进制数据包存成文件
            fileData.clear();
            ui->logs->insertPlainText("文件传输成功，文件保存至"+fileSaveName);
        }

    }
}
size_t MainWindow::ConvertHexStrToInt(const char* hex_str, size_t length)
{
    size_t sum = 0;
    for (size_t i = 0; i < length; ++i)
    {
        int asc = (int)hex_str[i];
        size_t r1 = (asc & 0x40) ? (asc & 0x0F) + 0x9 : (asc & 0x0F);
        sum += (r1*pow(16, length - i - 1));
    }
    return sum;
}


uint8_t * MainWindow::ConvertToBinBuf(const char* hex_str, size_t *buf_size)
{
    if (!hex_str)
    {
        *buf_size = 0;
        return NULL;
    }

    size_t len = strlen(hex_str);
    assert(!(len % 2));

    *buf_size = len / 2;
    uint8_t *buf = (uint8_t*)malloc(*buf_size);

    for (size_t i = 0, j = 0; i < len; i += 2, ++j)
    {
        uint8_t value = (uint8_t)ConvertHexStrToInt(hex_str + i, 2);
        buf[j] = value;
    }
    return buf;
}


void MainWindow::saveFile(QString fileData, QString filename){
    QByteArray m = filename.toLocal8Bit();
    QByteArray content = fileData.toLocal8Bit();
    const char* name = m.data();
    const char* str = content.data();
    FILE* file = fopen(name, "wb");
    size_t len = 0;
    uint8_t *buf2 = ConvertToBinBuf(str, &len);
    fwrite(buf2, 1, len, file);

    // 清空读文件的缓存
    free(buf2);
    fflush(file);
    fclose(file);
}

void MainWindow::disconnectedSlot()
{
    //由于disconnected信号并未提供SocketDescriptor，所以需要遍历寻找
    for(int i=0; i<tcpClient.length(); i++)
    {
        if(tcpClient[i]->state() == QAbstractSocket::UnconnectedState)
        {
             tcpClient[i]->destroyed();
             tcpClient.removeAt(i);
        }
    }
}
void MainWindow::on_clearLog_clicked()
{
    ui->logs->clear(); //清空日志
}

void MainWindow::on_saveLog_clicked() //写入日志的功能能
{

    QDateTime curDateTime=QDateTime::currentDateTime();
//    qDebug()<<QObject::tr("可执行文件所在目录:")<< qApp->applicationDirPath();
    QDir dir(qApp->applicationDirPath()+"/logs/");
    if(!dir.exists()){
        dir.mkdir(qApp->applicationDirPath()+"/logs/");
    }
    QString filename = qApp->applicationDirPath()+"/logs/"+curDateTime.toString("yyyyMMddhhmmss")+".txt";
    QFile aFile(filename);
    aFile.open(QIODevice::ReadWrite | QIODevice::Text); //打开或创建
    QString str=ui->logs->toPlainText();//整个内容作为字符串
    QByteArray strBytes=str.toUtf8();//转换为字节数组
    aFile.write(strBytes,strBytes.length());  //写入文件
    aFile.close();
    ui->logs->insertPlainText("导出日志成功，文件名为"+filename);
}


void MainWindow::adduser(QString username,QString passwd)
{
    QFile file("users.json");
    if(!file.open(QIODevice::ReadWrite)) {
        qDebug() << "File open error";
    } else {
        qDebug() <<"(w)File open!";
    }
    QJsonObject jsonObject;
    // 清空文件中的原有内容
    file.resize(0);
    for(int i=0;i<names.size();i++){
         jsonObject.insert(QString(names.at(i)), QString(passwds.at(i)));
    }
    jsonObject.insert(username, passwd);


// 使用QJsonDocument设置该json对象
    QJsonDocument jsonDoc;
    jsonDoc.setObject(jsonObject);
    // 写入文件
    file.write(jsonDoc.toJson());
    file.close();
}

void MainWindow::readuser()
{
    QFile file("users.json" );
    file.open(QIODevice::ReadOnly | QIODevice::Text);
    QString data = file.readAll();
    file.close();
    QJsonDocument jsonDocument = QJsonDocument::fromJson(data.toUtf8());
    QJsonObject jsonObject = jsonDocument.object();
    QStringList keys = jsonObject.keys();
    QStringList values ;
    for(int i=0;i<keys.size();i++){
     values.append(jsonObject[keys.at(i)].toString());
    }
    // 把用户数据交给全局数组，数据取出
    names = keys;
    passwds = values;
}
