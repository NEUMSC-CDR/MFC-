#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QTcpServer>
#include <QMessageBox>
#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

using namespace std;
class QTcpServer;
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    QStringList names;
    QStringList passwds;

    void adduser(QString username,QString passwd);
    void readuser();

    ~MainWindow();


private:
    Ui::MainWindow *ui;  
    QTcpServer *tcpServer;
    QList<QTcpSocket*> tcpClient;
    QTcpSocket *currentClient;
    QString fileData;
    QString fileName;
    void saveFile(QString fileData,QString filename);
    uint8_t * ConvertToBinBuf(const char* hex_str, size_t *buf_size);
    size_t ConvertHexStrToInt(const char* hex_str, size_t length);


private slots:
    void NewConnectionSlot();
    void disconnectedSlot();
    void on_clearLog_clicked();
    void on_saveLog_clicked();
    void ReadData();
};

#endif // MAINWINDOW_H
