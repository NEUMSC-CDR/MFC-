/********************************************************************************
** Form generated from reading UI file 'dialogfile.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGFILE_H
#define UI_DIALOGFILE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_DialogFile
{
public:
    QGroupBox *groupBox;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QPushButton *pushButton_2;
    QProgressBar *progressBar;
    QTextBrowser *textBrowser;
    QLabel *label;
    QTextBrowser *textBrowser_2;
    QLabel *label_2;

    void setupUi(QDialog *DialogFile)
    {
        if (DialogFile->objectName().isEmpty())
            DialogFile->setObjectName(QStringLiteral("DialogFile"));
        DialogFile->resize(714, 564);
        DialogFile->setMinimumSize(QSize(714, 564));
        DialogFile->setMaximumSize(QSize(714, 564));
        groupBox = new QGroupBox(DialogFile);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 0, 681, 541));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(40, 80, 97, 31));
        lineEdit = new QLineEdit(groupBox);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(40, 130, 291, 31));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(40, 180, 97, 31));
        progressBar = new QProgressBar(groupBox);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setGeometry(QRect(30, 490, 631, 31));
        progressBar->setValue(24);
        textBrowser = new QTextBrowser(groupBox);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setGeometry(QRect(360, 80, 301, 391));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(370, 40, 71, 23));
        textBrowser_2 = new QTextBrowser(groupBox);
        textBrowser_2->setObjectName(QStringLiteral("textBrowser_2"));
        textBrowser_2->setGeometry(QRect(45, 291, 261, 171));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(50, 250, 81, 31));

        retranslateUi(DialogFile);

        QMetaObject::connectSlotsByName(DialogFile);
    } // setupUi

    void retranslateUi(QDialog *DialogFile)
    {
        DialogFile->setWindowTitle(QApplication::translate("DialogFile", "Dialog", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("DialogFile", "\346\226\207\344\273\266\345\244\207\344\273\275\346\234\215\345\212\241", Q_NULLPTR));
        pushButton->setText(QApplication::translate("DialogFile", "\351\200\211\346\213\251\346\226\207\344\273\266", Q_NULLPTR));
        lineEdit->setText(QApplication::translate("DialogFile", "\346\226\207\344\273\266\350\267\257\345\276\204\346\230\276\347\244\272\345\234\250\350\277\231\351\207\214", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("DialogFile", "\344\270\212\344\274\240\346\226\207\344\273\266", Q_NULLPTR));
        label->setText(QApplication::translate("DialogFile", "\345\244\207\344\273\275\350\256\260\345\275\225", Q_NULLPTR));
        label_2->setText(QApplication::translate("DialogFile", "\345\267\262\344\270\212\344\274\240\346\226\207\344\273\266", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class DialogFile: public Ui_DialogFile {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGFILE_H
