#include "dialogtime.h"
#include "ui_dialogtime.h"

DialogTime::DialogTime(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogTime)
{
    ui->setupUi(this);
}

DialogTime::~DialogTime()
{
    delete ui;
}


void DialogTime::on_pushButton_clicked()
{

    MainWindow *ptr=(MainWindow*)parentWidget();
    ptr->askTime();
}

void DialogTime::showTime(QStringList dataList){
    int timeT = dataList[0].toInt(); // 时间戳
    QDateTime time = QDateTime::fromTime_t(timeT);
    QString current_date1 =time.toString("yyyy.MM.dd hh:mm:ss ddd");
    QString current_date2 =time.toString("yyyy-MM-dd hh-mm-ss");
    QString current_date3 =time.toString("yyyy/MM/dd hh:mm:ss.zzz");
    ui->lineEdit->setText(current_date1);
    ui->lineEdit_2->setText(current_date2);
    ui->lineEdit_3->setText(current_date3);
}
