#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "dialogtime.h"
#include "dialogfile.h"
#include "ui_dialogfile.h"
#include <QAbstractSocket>
#include <QTcpSocket>
#include <QMessageBox>
#include <QDateTime>
#include <QTimer>
#include <string>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>


class QTcpSocket;
class DialogTime;
class DialogFile;
using namespace std;
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void askTime();
    void showLoginUI();
    void sendFile(QString filename);
    string datasize; //实际的文件大小，单位KB
    ~MainWindow();

private slots:
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();

private:
    Ui::MainWindow *ui;
    QTcpSocket *tcpSocket;
    // 用来存放数据的大小信息
    quint16 blockSize;
    DialogTime *dialogTime;//= new DialogTime
    DialogFile *dialogFile;//= new DialogFile

    QString fileSize;
    QByteArray  upBlock;    //上传缓冲区
    qint64 upTotalBytes;
    QString dataToSend;
    string data;
    unsigned char temp;
    stringstream stream;
    void setIndex(int num, char* hexNumber);

    string readFileData(QString filename); // 读文件内容为十六进制
    char HEX[16] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };



private slots:
    void ReadData();
    void ReadError(QAbstractSocket::SocketError);
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
};

#endif // MAINWINDOW_H
