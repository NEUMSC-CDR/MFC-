#ifndef _DIALOGTIME_H
#define _DIALOGTIME_H

#include <QDialog>
#include "mainwindow.h"
class MainWindow;
namespace Ui {
class DialogTime;
}

class DialogTime : public QDialog
{
    Q_OBJECT

public:
    explicit DialogTime(QWidget *parent = 0);
    void showTime(QStringList dataList);
    ~DialogTime();

private slots:

    void on_pushButton_clicked();

private:
    Ui::DialogTime *ui;
    MainWindow *mainWindow ;//= new MainWindow

};

#endif // DIALOGTIME_H
