#ifndef DIALOGFILE_H
#define DIALOGFILE_H

#include <QDialog>
#include <QFileDialog>
#include <QDebug>
#include "mainwindow.h"

class MainWindow;
namespace Ui {
class DialogFile;
}

class DialogFile : public QDialog
{
    Q_OBJECT

public:
    explicit DialogFile(QWidget *parent = 0);
    void logFormat(QString log);
    ~DialogFile();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void progressBar();

private:
    Ui::DialogFile *ui;
    MainWindow *mainWindow ;//= new MainWindow
    QString upFileName;
    QString realName ;

};

#endif // DIALOGFILE_H
