#include "dialogfile.h"
#include "ui_dialogfile.h"


DialogFile::DialogFile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogFile)
{
    ui->setupUi(this);
    ui->pushButton_2->setEnabled(false);
}

DialogFile::~DialogFile()
{
    delete ui;
}

void DialogFile::on_pushButton_clicked()
{
    upFileName = QFileDialog::getOpenFileName(this);
    if(!upFileName.isEmpty()){
        ui->pushButton_2->setEnabled(true);     //上传按钮生效
        int realNameIndex = upFileName.lastIndexOf("/");
        realName = upFileName.right(upFileName.length ()-realNameIndex-1);  //取真正文件名
        ui->lineEdit->setText(realName);
    }
}



// 文件上传
void DialogFile::on_pushButton_2_clicked()
{
    MainWindow *ptr=(MainWindow*)parentWidget();
    ptr->sendFile(realName);
    QString info = "上传文件名为"+realName+",文件大小为"+QString::fromStdString(ptr->datasize);
    logFormat(info);
    ui->textBrowser_2->insertPlainText(realName+"\n");


    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(progressBar()));
    timer->start(2000);
    ui->progressBar->setMaximum(0);
    ui->progressBar->setMinimum(100);
}

 void DialogFile::progressBar(){
     //激活进度条
     ui->progressBar->setMaximum(0);
     ui->progressBar->setMinimum(0);
    }
void DialogFile::logFormat(QString log){
    QDateTime now_time = QDateTime::currentDateTime();//获取系统现在的时间
    QString time =now_time.toString("MM-dd hh:mm:ss");
    QString logFormat = "\n["+time+"]"+log;
    ui->textBrowser->insertPlainText(logFormat);
}


