#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialogtime.h"
#include "dialogfile.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFixedSize(550,300);
    ui->pushButton_3->setVisible(false);
    ui->pushButton_4->setVisible(false);
    ui->pushButton_5->setVisible(true);
    ui->label_3->setVisible(true);
    ui->label_4->setVisible(true);
    ui->lineEdit_3->setVisible(true);
    ui->lineEdit_4->setVisible(true);
    ui->label->setVisible(false);
    ui->label_2->setVisible(false);
    ui->lineEdit->setVisible(false);
    ui->lineEdit_2->setVisible(false);
    ui->pushButton->setVisible(false);
    ui->pushButton_2->setVisible(false);
    ui->pushButton_6->setVisible(false);

    tcpSocket = new QTcpSocket(this);   //实例化tcpSocket
    tcpSocket->abort();                 //取消原有连接

    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(ReadData()));  // 监听socket通信，受到内容则调用ReadData()函数
    connect(tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)), \
            this, SLOT(ReadError(QAbstractSocket::SocketError)));


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::ReadData()
{
    QByteArray buffer = tcpSocket->readAll();
    QString data = QString(buffer);
    QStringList dataList = data.split("==");
    if(dataList.at(dataList.size()-1)=="loginSuccess"){
        this->setFixedSize(550,400);

        ui->pushButton->setVisible(false);
        ui->pushButton_2->setVisible(false);
        ui->pushButton_5->setVisible(false);
        ui->pushButton_3->setVisible(true);
        ui->pushButton_4->setVisible(true);
        ui->pushButton_6->setVisible(true);
        ui->lineEdit_3->setVisible(false);
        ui->lineEdit_4->setVisible(false);
        ui->lineEdit->setDisabled(true);
        ui->lineEdit_2->setDisabled(true);

        QMessageBox *msgBox = new QMessageBox(QMessageBox::Information,QString("通知"),QString("身份验证成功，正在登录..."));
        QTimer::singleShot(2500,msgBox,SLOT(accept()));
        msgBox->exec();
    }else if(dataList.at(dataList.size()-1)=="loginFailed"){
        QMessageBox *msgBox = new QMessageBox(QMessageBox::Information,QString("错误"),QString(QLatin1String("用户名或密码错误！")));
        QTimer::singleShot(2000,msgBox,SLOT(accept()));
        msgBox->exec();
    }else if(dataList.at(dataList.size()-1)=="registerSuccess"){
        QMessageBox *msgBox = new QMessageBox(QMessageBox::Information,QString("通知"),QString(QLatin1String("注册成功，请登录")));
        QTimer::singleShot(2000,msgBox,SLOT(accept()));
        msgBox->exec();
    }else if(dataList.at(dataList.size()-1)=="time"){
        dialogTime->showTime(dataList);
    }else if(dataList.at(dataList.size()-1)=="registerError"){
        QMessageBox *msgBox = new QMessageBox(QMessageBox::Information,QString("错误"),QString("请输入完整用户名和密码"));
        QTimer::singleShot(2000,msgBox,SLOT(accept()));
        msgBox->exec();
    }else if(dataList.at(dataList.size()-1)=="logout"){
        QMessageBox *msgBox = new QMessageBox(QMessageBox::Information,QString("通知"),QString("注销成功，请重新登录"));
        QTimer::singleShot(2000,msgBox,SLOT(accept()));
        msgBox->exec();
        showLoginUI();
    }
}

void MainWindow::ReadError(QAbstractSocket::SocketError)
{
    tcpSocket->disconnectFromHost(); // 断开连接
    QMessageBox *msgBox = new QMessageBox(QMessageBox::Information,QString("警告"),QString(tr("failed to connect server because %1").arg(tcpSocket->errorString())));
    QTimer::singleShot(1000,msgBox,SLOT(accept()));
    msgBox->exec();
}



void MainWindow::on_pushButton_3_clicked()
{

    dialogTime = new DialogTime(this);
    dialogTime->setModal(false);
    dialogTime->show();
}

void MainWindow::on_pushButton_4_clicked()
{
    dialogFile = new DialogFile(this);
    dialogFile->setModal(false);
    dialogFile->show();
}

void MainWindow::askTime(){
    QString data = "time";
    tcpSocket->write(data.toLatin1());
}

void MainWindow::sendFile(QString upFileName){

    string data = readFileData(upFileName);
    fileSize = data.size();
    int flagSize = 0;
    while(flagSize<fileSize){
        // 到文件尾部
        if (flagSize+1000 > fileSize){
            dataToSend = QString::fromStdString(data.substr(flagSize))+"=="+upFileName+"==fileover"; // 文件发送结束时带上文件名
            tcpSocket->write(dataToSend.toLatin1());
            break;
        }else{
            dataToSend = QString::fromStdString(data.substr(flagSize,flagSize+1000))+"==filedata";
            tcpSocket->write(dataToSend.toLatin1()); //string to QString
            flagSize+=1000;
        }

    }
}


string MainWindow::readFileData(QString filename){

    string path = filename.toStdString();
    ifstream in = ifstream(path, ios::binary);
    if (!in.is_open()){ qDebug() << "文件打开失败"; }

    // 获取文件大小、文件名
    int Beg = in.tellg();
    in.seekg(0, ios::end);
    int End = in.tellg();
    int fileSize = End - Beg;
    in.seekg(0, ios::beg);
    datasize = to_string(fileSize / 1024.0) + "KB"; // 文件大小

    // 读文件（每次循环读取 1 字节）
    while (in.read((char*)&temp, 1))
    {
        // 读 1 字节
        int hex = (unsigned)temp;
        char a = HEX[hex / 16];
        char b = HEX[hex % 16];
        stream << a << b;
    }
    data = stream.str(); // 文件的十六进制数据
    stream.clear(); // 清除状态
    stream.str(""); // 清空内容
    in.close(); // 关闭文件流
    return data;
}

void MainWindow::on_pushButton_clicked()
{

    QString data = ui->lineEdit->text()+"=="+ui->lineEdit_2->text()+"=="+"register"; // 发送用户名密码和登录请求
    tcpSocket->write(data.toLatin1());

}

void MainWindow::on_pushButton_2_clicked()

{
    QString data = ui->lineEdit->text()+"=="+ui->lineEdit_2->text()+"=="+"login"; // 发送用户名密码和登录请求
    tcpSocket->write(data.toLatin1());
}

void MainWindow::on_pushButton_5_clicked()
{

    tcpSocket->connectToHost(ui->lineEdit_3->text(), ui->lineEdit_4->text().toInt());
    if (tcpSocket->waitForConnected(1000))  // 连接成功则进入if{}
    {
        QMessageBox msgBox;
        msgBox.setText(tr("成功连接至服务器，请登录"));
        msgBox.exec();
        showLoginUI();
    }


}

void MainWindow::on_pushButton_6_clicked()
{
    QString data = "logout"; // 发送用户名密码和登录请求
    tcpSocket->write(data.toLatin1());
    // 启用注册和登录
    ui->lineEdit->setDisabled(false);
    ui->lineEdit_2->setDisabled(false);
}


void MainWindow::showLoginUI(){
    this->setFixedSize(550,320);
    ui->label->setVisible(true);
    ui->label_2->setVisible(true);
    ui->lineEdit->setVisible(true);
    ui->lineEdit_2->setVisible(true);
    ui->pushButton->setVisible(true);
    ui->pushButton_2->setVisible(true);
    ui->pushButton_5->setVisible(false);
    ui->label_3->setVisible(false);
    ui->label_4->setVisible(false);
    ui->lineEdit_3->setVisible(false);
    ui->lineEdit_4->setVisible(false);
    ui->pushButton_6->setVisible(false);
}
