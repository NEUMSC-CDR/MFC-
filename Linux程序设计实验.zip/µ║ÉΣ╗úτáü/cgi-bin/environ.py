#!/usr/bin/python3
import os
import platform


class GenerateEnvHtml:

    def __init__(self):
        self.response_html = ""
        self.class_select_list = ["default", "success", "default", "warning"]
        self.class_select_list_all = [
            "default", "success", "default", "info", "default", "warning"]

    def print_table(self):
        self.response_html += """"""

    def gen_header_html(self):
        self.response_html += """Content-type: text/html\n\n"""

    def gen_main_html(self,):
        self.response_html += """
        
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <link rel="stylesheet" href="../static/css/bootstrap.css">
            <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
            <script type="text/javascript"  src="../static/js/bootstrap.min.js"></script>
        <title>表单测试</title>
        </head>
        <body>
            <div class="container">
                <div class="row clearfix">
                    <div class="col-md-12 column">

                            """

    def gen_tail_html(self):
        self.response_html += """
                    </div>
                </div>
            </div>
        </body>
        </html>
        </form>"""

    def get_env_html(self):
        envs = os.environ
        response_html = ""
        response_html+="""<h3 align="center">环境变量</h3>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>
                                序号
                            </th>
                            <th>
                                变量名
                            </th>
                            <th>
                                变量值
                            </th>
                        </tr>
                    </thead>"""
        for index, key in enumerate(sorted(envs)):
            response_html += """
                            <tr class="{class_select}">
                                <td>
                                    {number}
                                </td>
                                <td>
                                    {key}
                                </td>
                                <td>
                                    {value}
                                </td>
                            </tr>
                        """.format(class_select=self.class_select_list[int(index % 4)], number=index+1, key=key, value=envs[key])
        response_html+="""</table>"""
        return response_html

    def get_info_html(self):
        response_html = ""
        info_dict = dict({"操作系统类型：": platform.system(), "操作系统名称及版本号:": platform.platform(), "操作系统的位数:": str(platform.architecture()), "计算机类型：": platform.machine(),"计算机网络名称：": platform.node(),"计算机处理器名称：":platform.processor()})
        response_html+="""<br><h3 align="center">计算机信息</h3>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>
                                        序号
                                    </th>
                                    <th>
                                        变量名
                                    </th>
                                    <th>
                                        变量值
                                    </th>
                                </tr>
                            </thead>"""
        for index,key in enumerate(info_dict):
            response_html += """
                        <tr class="{class_select}">
                                    <td>
                                        {number}
                                    </td>
                                    <td>
                                        {key}
                                    </td>
                                    <td>
                                        {value}
                                    </td>
                                </tr>
                            """.format(class_select=self.class_select_list[int(index % 4)], number=index+1, key=key, value=info_dict[key])
        response_html+="""</table>"""
        return response_html
        
    def gen_response_html(self):
        self.gen_header_html()
        self.gen_main_html()
        self.response_html+=self.get_env_html()
        self.response_html+=self.get_info_html()
        # self.gen_env_html()
        self.gen_tail_html()

        print(self.response_html)


GenerateEnvHtml().gen_response_html()

