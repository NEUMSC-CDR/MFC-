#!/usr/bin/python3
# -*- coding: utf-8 -*-


import os
import cgi
import cgitb


class Tree():
    mode_descriptions = {
        'df': 'Directory First',
        'do': 'Directory Only',
        'ff': 'File First',
        'od': 'Ordered'
    }

    def __init__(self, path, indent=1, mode='od', sparse=True, dtail='/'):
        self.sparse = sparse
        self.dtail = dtail
        self.space = ' ' * indent
        self.line = '─' * indent

        self.traverses = {
            'df': self.df,
            'do': self.do,
            'ff': self.ff,
            'od': self.od
        }

        self.chmod(mode)
        self.generate(path)

    def write(self, filename):
        with open(filename, 'w+', encoding='utf-8') as fd:
            fd.write('mode: %s\n' % self.mode_descriptions[self.mode])
            fd.write('\n')
            fd.write(self.tree)

    def return_html(self):
        return self.tree.replace("\n", "<br>").replace(" ", "&nbsp;")

    def return_strlist(self):
        return self.tree.split("\n")

    def show_str(self):
        print(self.tree)

    def chmod(self, mode):
        assert mode in self.traverses
        self.traverse = self.traverses[mode]
        self.mode = mode

    def generate(self, path):
        path = os.path.abspath(path)
        assert os.path.isdir(path)
        self.tree = path + '\n'
        self.traverse(path, '')

    def get_dirs_files(self, dirpath):
        dirs, files = [], []
        for leaf in os.listdir(dirpath):
            path = os.path.join(dirpath, leaf)
            if os.path.isfile(path):
                files.append(leaf)
            else:
                dirs.append((leaf, path))

        return dirs, files

    def add_dirs(self, dirs, prefix, fprefix, dprefix, recursive):
        for dirname, path in dirs[:-1]:
            self.tree += dprefix + dirname + self.dtail + '\n'
            recursive(path, fprefix)

        dirname, path = dirs[-1]
        fprefix = prefix + ' ' + self.space
        dprefix = prefix + '└' + self.line
        self.tree += dprefix + dirname + self.dtail + '\n'
        recursive(path, fprefix)

    def add_files(self, files, fprefix):
        for file in files:
            self.tree += fprefix + file + '\n'
        if self.sparse and files:
            self.tree += fprefix.rstrip() + '\n'

    def df(self, dirpath, prefix):
        dirs, files = self.get_dirs_files(dirpath)
        if dirs:
            fprefix = prefix + '│' + self.space
            dprefix = prefix + '├' + self.line
            self.add_dirs(dirs, prefix, fprefix, dprefix, self.df)
            self.add_files(files, prefix + ' ' + self.space)

        else:
            self.add_files(files, prefix + self.space)

    def do(self, dirpath, prefix):
        dirs = []
        for leaf in os.listdir(dirpath):
            path = os.path.join(dirpath, leaf)
            if os.path.isdir(path):
                dirs.append((leaf, path))
        if dirs:
            fprefix = prefix + '│' + self.space
            dprefix = prefix + '├' + self.line
            self.add_dirs(dirs, prefix, fprefix, dprefix, self.do)

    def ff(self, dirpath, prefix):
        dirs, files = self.get_dirs_files(dirpath)
        if dirs:
            fprefix = prefix + '│' + self.space
            dprefix = prefix + '├' + self.line
            self.add_files(files, fprefix)
            self.add_dirs(dirs, prefix, fprefix, dprefix, self.ff)
        else:
            self.add_files(files, prefix + self.space)

    def od(self, dirpath, prefix):
        leaves = sorted(os.listdir(dirpath))
        if not leaves:
            return
        for leaf in leaves[:-1]:
            path = os.path.join(dirpath, leaf)
            if os.path.isfile(path):
                fprefix = prefix + '│' + self.space
                dprefix = prefix + '├' + self.line
                self.tree += dprefix + leaf + '\n'
            if os.path.isdir(path):
                fprefix = prefix + '│' + self.space
                dprefix = prefix + '├' + self.line
                self.tree += dprefix + leaf + self.dtail + '\n'
                self.od(path, fprefix)

        leaf = leaves[-1]
        path = os.path.join(dirpath, leaf)
        fprefix = prefix + ' ' + self.space
        dprefix = prefix + '└' + self.line
        if os.path.isfile(path):
            self.tree += dprefix + leaf + '\n'
        if os.path.isdir(path):
            self.tree += dprefix + leaf + self.dtail + '\n'
            self.od(path, fprefix)


class GenerateHtml:
    def __init__(self, path):
        self.path = path
        self.response_text = ""
        self.files_count = 0
        self.dirs_count = 0
        self.base_folder = path

    def get_data_tree(self):
        tree = Tree(self.path)
        filelist = tree.return_strlist()
        self.base_folder = filelist[0]+"/"
        return map(lambda x: x.replace("└─", "├─").replace("├─", "").replace("│", "~").replace(" ", "").replace("/", "#dir#"), filelist[1:])

    def formatByte(self, number):

        for(scale, label) in [(1024*1024*1024, "GB"), (1024*1024, "MB"), (1024, "KB")]:
            if number >= scale:
                return "%.2f %s" % (number*1.0/scale, label)
            elif number == 1:
                return "1字节"
            else:
                byte = "%.2f" % (number or 0)
        return (byte[:-3]+" B") if byte.endswith(".00") else byte + " B"

    # tree.show_str()

    def gen_header_html(self):
        self.response_text += "Content-type: text/html\n\n"

    def gen_tail_html(self):
        self.response_text += """</div></body></html>"""

    def gen_main_html(self):
        self.response_text += """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>文件目录</title>
            <link rel="stylesheet" href="../static/css/bootstrap.css">
            <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
            <script type="text/javascript"  src="../static/js/bootstrap.min.js"></script>
        </head>

        <body>

            <div class="container" style="padding: 30px 0px 50px 0px;">

                <nav class="navbar navbar-default" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse"
                            data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span
                                class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand">输入目录</a>
                    </div>

                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="border-color:#337ab7;background-color:#fff;">
                        <form class="navbar-form navbar-left" role="form" action="./dir.py" method="GET">
                            <div class="form-group">
                                <input type="text" class="form-control" name="path"/>
                            </div> &nbsp;&nbsp;<button type="submit" class="btn btn-default">打印</button>
                        </form>

                    </div>

                </nav>
                
        """

    def gen_success_info(self):
        self.response_text += """
        <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4>
                            Success!
                        </h4> 
                        当前路径: {path}
                        <br>
                        
                        当前目录文件数: <strong>{files_count}</strong>当前目录文件夹数: <strong>{dirs_count}</strong>
                </div>""".format(path=self.path, files_count=self.files_count, dirs_count=self.dirs_count)

    def gen_error_info(self):
        self.response_text += """
        <div class="alert alert-dismissable alert-danger">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<h4>
					Error!
				</h4>  路径打开失败，路径不存在或权限不足！
			</div>"""

    def gen_breadcrumb_html(self):

        path_rec = self.path.split("/")[1:]
        self.response_text += """<ul class="breadcrumb">"""
        for index, dir in enumerate(path_rec):
            self.response_text += """
                <li>
                    <a href="./dir.py?path={path}">{dir}</a>
                </li>
                """.format(path="/"+"/".join(path_rec[0:index+1]), dir=dir)
        self.response_text += """</ul>"""
        # self.response_text+="""
        #     <li class="active">

        #         <a href="./dir.py?path={path}">{current_dir}</a>
        #     </li>
        # </ul>""".format(current_dir=path_rec[-1])

    def gen_files_dirs_html(self, files_list):
        files_count = 0
        dirs_count = 0
        response_text = ""
        folder = ""

        for obj in files_list:
            try:
                # 不想套娃，只递归出两层，即子文件和子目录，子目录下的文件和目录不会被递归
                if obj[0:2] == "~~":
                    pass 

                elif "#dir#" in obj and obj[0] == "~":  # 子目录
                    sub_folder = folder + \
                        obj.replace("#dir#", "").replace("~", "")+"/"
                    response_text +=\
                        """<a href="./dir.py?path={path}" class="list-group-item active " style="padding: 10px 50px 10px 30px;background-color: #64b5f6;margin-left:30px;margin-right:0px;">
                            {sub_folder}
                            </a>""".format(path=sub_folder, sub_folder=obj.replace("#dir#", "").replace("~", ""))
                
                elif "#dir#" in obj:  # 目录
                    dirs_count += 1
                    folder = self.base_folder+obj.replace("#dir#", "")+"/"
                    response_text +=\
                        """<a href="./dir.py?path={path}" class="list-group-item active" style="padding: 10px 50px 10px 30px;backgroud-color:#1976d2;">
                            {folder}
                            </a>""".format(path=folder, folder=obj.replace("#dir#", ""))

                elif obj[0] == "~":  # 子文件
                    file_info = os.stat(folder+obj.replace("~", ""))
                    response_text +=\
                        """<a target="_blank" href="./download.py?filepath={path}" class="list-group-item" style="padding: 10px 50px 10px 80px;backgroud-color:#fff;margin-left:30px;margin-right:0px;">
                            {file}<span class="badge">{size}</span>
                            </a>""".format(path=folder+obj.replace("~", ""),file=obj.replace("~", ""), size=self.formatByte(file_info.st_size))
                
                elif "~" not in obj:  # 文件
                    file_info = os.stat(self.base_folder+obj)
                    files_count += 1
                    response_text +=\
                        """<a target="_blank" href="./download.py?filepath={path}" class="list-group-item" style="padding: 10px 50px 10px 30px;backgroud-color:#fff;">
                            {file}<span class="badge">{size}</span>
                            </a>""".format(path=self.base_folder+obj,file=obj, size=self.formatByte(file_info.st_size))
                else:
                    pass
            except:
                pass
                """
                    为什么要加一个try-catch呢？因为懒
                    这段代码有一个bug，会将当前目录中的最后一个子目录中的文件，识别为当前目录中的子文件，导致打印文件时出现文件找不到的错误
                    
                    │ └─js/                             ~js
                    │   ├─bootstrap.min.js   ===>       ~bootstrap.min.js
                    │   └─snow.min.js                   ~snow.min.js

                    只要捕捉错误就忽略掉就解决Bug啦～
                """
        return response_text, files_count, dirs_count

    def response_html(self):
        response_text, self.files_count, self.dirs_count = self.gen_files_dirs_html(
            self.get_data_tree())

        self.gen_header_html()
        self.gen_main_html()
        self.gen_success_info()
        self.gen_breadcrumb_html()
        self.response_text += response_text
        self.gen_tail_html()

        print(self.response_text)

    def response_error_html(self):
        self.gen_header_html()
        self.gen_main_html()
        self.gen_error_info()
        self.gen_breadcrumb_html()
        self.gen_tail_html()
        print(self.response_text)


# 创建 FieldStorage 的实例化
form = cgi.FieldStorage()

cgitb.enable()
# 获取数据
path_name = form.getvalue('path')
default_path_name = os.getcwd()
if path_name:
    print(path_name)
    if os.path.isdir(path_name):
        html = GenerateHtml(path_name.strip())
        html.response_html()
    else:
        html = GenerateHtml(default_path_name)
        html.response_error_html()

else:
    html = GenerateHtml(default_path_name)
    html.response_html()
