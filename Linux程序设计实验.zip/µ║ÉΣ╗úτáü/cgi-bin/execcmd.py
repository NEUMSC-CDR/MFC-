#!/usr/bin/python3

import os
import subprocess
import cgi
import time

form = cgi.FieldStorage()
cmd = form.getvalue("cmd")


class execCmd:
    def __init__(self, cmd):
        self.cmd = cmd
        self.response_text = ""
        self.cmd_res = ""
        self.cmd_status = 0
        self.time = 0

    
    def virtual_shell(self):
        time_start=time.time()
        self.cmd_status,self.cmd_res = subprocess.getstatusoutput(self.cmd)
        self.time = time.time()-time_start

    def gen_header_html(self):
        self.response_text += "Content-type: text/html\n\n"

    def gen_main_html(self):

        self.response_text += """
        <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>文件目录</title>
                <link rel="stylesheet" href="../static/css/bootstrap.css">
                <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
                <script type="text/javascript"  src="../static/js/bootstrap.min.js"></script>
            </head>

            <body>

                <div class="container" style="padding: 30px 0px 50px 0px;">

                    <nav class="navbar navbar-default" role="navigation" style="margin: 20px 15px 20px 15px;">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse"
                                data-target="#bs-example-navbar-collapse-1">
                                <span class="sr-only">Toggle navigation</span>
                                <span
                                    class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" style="color:#fff">执行命令</a>
                        </div>

                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="border-color:#337ab7;background-color:#337ab7;border-radius:3px;">
                            <form class="navbar-form navbar-left" role="form" action="./execcmd.py" method="GET">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="cmd"/>
                                </div> &nbsp;&nbsp;<button type="submit" class="btn btn-default">执行</button>
                            </form>
                        </div>
                    </nav>
                    """

    def gen_result_html(self):
        self.response_text+="""
            <div class="col-md-12 column">
			<div class="panel panel-success">
				<div class="panel-heading">
					<h3 class="panel-title"style=" padding:10px;">
                    <p>执行的命令：{cmd}</p>
					<p>执行状态码：{status}</p>
					</h3>
				</div>
				<div class="panel-body" style="margin:20px 0px 0px 40px;">
					
                    {res}
				</div>
				<div class="panel-footer " style="background-color:#dff0d8;margin:20px 0px 0px 0px;padding:20px">
					<h3 class="panel-title" style="color:#3c763d">
					执行用时：{time}
                    </h3>
				</div>
			</div>
		</div>
        """.format(cmd=self.cmd,status=self.cmd_status,res="<h5>"+self.cmd_res.replace('\n','</h5><h5>')+"</h5>",time=self.time)

    def gen_tail_html(self):
        self.response_text+="""

                </div>
            </body>
        </html>"""


    def response_html(self):
        self.virtual_shell()
        self.gen_header_html()
        self.gen_main_html()
        self.gen_result_html()
        self.gen_tail_html()
        print(self.response_text)


if cmd:
    execCmd(cmd.strip()).response_html()
else:
    execCmd("echo '请输入需要执行的命令！'").response_html()