#!/usr/bin/python3
# -*- coding: utf-8 -*-
import cgi
import os
import shutil
import random
import string
import hashlib


def generate_random_name():
    md5hash = hashlib.md5("".join(random.choices(string.printable+string.printable,k=5)).encode("utf-8"))
    md5 = md5hash.hexdigest()
    return str(md5[:16])+'/'

print("Content-type: text/html\n\n")
print("""
        <!DOCTYPE html>
        <html>
        <head>""")
form = cgi.FieldStorage()
base_dir = os.getcwd()+"/temp/"
filepath = form.getvalue("filepath")
if filepath and os.path.isfile(filepath):
    temp_dir = generate_random_name()
    os.mkdir(base_dir+temp_dir)
    shutil.copy(filepath,base_dir+temp_dir)
    print("""<meta http-equiv="refresh" content="5;url={url}"> """.format(url="../temp/"+temp_dir+filepath.split("/")[-1]))
    pass


#             <meta charset="utf-8">
#             <title>文件目录</title>
#             <link rel="stylesheet" href="../static/css/bootstrap.css">
#             <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
#             <script type="text/javascript"  src="../static/js/bootstrap.min.js"></script>
# <script type="text/javascript">
# function startTime()
# {
# var today=new Date()
# var h=today.getHours()
# var m=today.getMinutes()
# var s=today.getSeconds()
# m=checkTime(m)
# s=checkTime(s)
# document.getElementById('txt').innerHTML=h+":"+m+":"+s
# t=setTimeout('startTime()',500)
# }

# function checkTime(i)
# {
# if (i<10) 
#   {i="0" + i}
#   return i
# }
# function closeit()

# {

# setTimeout("self.close()", 3000);

# }
# closeit();
# </script>
#         <body onload="startTime()">
# <p>文件正在下载，十秒后关闭网页</p>

# <div id="txt"></div>
print("""<body></body></head></html>""")