
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUFSIZE 1024
#define EOL "\r\n"

struct header
{
    char field[BUFSIZE];
    char value[BUFSIZE];
};

struct request
{

    char *method;
    char *uri;
    char *version;
    char *body;

    int headers_count;
    struct header headers[30];
};

typedef struct
{
    char *ext;
    char *mimetype;
} exts;

// 文件类型与对应的mimetype
exts extensions[] = {
    {"aiff", "audio/x-aiff"},
    {"avi", "video/avi"},
    {"bin", "application/octet-stream"},
    {"bmp", "image/bmp"},
    {"css", "text/css"},
    {"c", "text/x-c"},
    {"doc", "application/msword"},
    {"gif", "image/gif"},
    {"gz", "image/gz"},
    {"htmls", "text/html"},
    {"html", "text/html"},
    {"ico", "image/ico"},
    {"jpeg", "image/jpeg"},
    {"jpg", "image/jpg"},
    {"js", "application/x-javascript"},
    {"mp3", "audio/mpeg3"},
    {"mpeg", "video/mpeg"},
    {"mpg", "video/mpeg"},
    {"md", "text/markdown"},
    {"pdf", "application/pdf"},
    {"php", "text/html"},
    {"png", "image/png"},
    {"png", "image/png"},
    {"rar", "application/octet-stream"},
    {"tar", "image/tar"},
    {"tiff", "image/tiff"},
    {"txt", "text/plain"},
    {"xml", "application/xml"},
    {"zip", "application/zip"}};

int server_socket;           // 服务端socket
int client_socket;           // 客户端socket
int port;                    // 端口号
unsigned int clientaddrLen;  // ip地址长度
struct hostent *client_info; // 客户端信息

// struct hostent
// {
//     char *h_name;       /* official name of host */
//     char **h_aliases;   /* alias list */
//     int h_addrtype;     /* host address type */
//     int h_length;       /* length of address */
//     char **h_addr_list; /* list of addresses from name server */
// };

char *host_addr;               // 主机ip地址
struct sockaddr_in serveraddr; // 服务器ip
struct sockaddr_in clientaddr; // 客户端ip
struct stat file_status;       // 文件状态

// struct sockaddr_in
// {
//     unsigned char sin_len;
//     unsigned char sin_family;
//     unsigned short sin_port;
//     struct in_addr sin_addr;

//     struct in_addr
//     {
//         unsigned int s_addr;
//     };
//     char sin_zero[8];
// };

int wait_status; // 等待状态

extern char **environ;

// 返回错误信息给客户端（浏览器）
void error_sendto_client(FILE *stream, char *cause, char *errno,
                         char *shortmsg, char *longmsg);

// 返回错误信息给终端，程序异常终止
void error_sendto_stdout(char *msg);

// 打印请求头
void print_request_header(struct request *request);

// 得到后缀
char *get_ext(char *filename);

// 将后缀转换成对应的资源类型头部信息
void check_ext(char filetype[], char *ext);

// 绑定端口
void bind_port(int server_socket);

// 响应程序主函数
void handle(struct request *request, int client_socket);

void get_host_addr(struct sockaddr_in clientaddr);
void get_host(struct sockaddr_in clientaddr);

// 分析和保存请求头信息
int analyze_request(char *request_buffer, struct request *request);
char *bufcpy(char *srcbuffer, size_t len);
