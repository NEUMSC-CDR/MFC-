#include "webserver.h"

void error_sendto_stdout(char *msg)
{
    perror(msg);
    exit(1);
}
void error_sendto_client_404(FILE *stream)
{
    fprintf(stream, "HTTP/1.1");
    fprintf(stream, "Content-type: text/html\n");
    fprintf(stream, "\n");
    fprintf(stream, "<!DOCTYPE html><html><meta http-equiv='Content-Type' content='text/html; charset=utf-8' /><head><title>404 not found!</title></head>");
    fprintf(stream, "<body bgcolor="
                    "ffffff"
                    ">\n");
    fprintf(stream,"<body background=\"http://image.iwonder.run/imgs/2020/12/3199517650bb1f6c.gif\" style=\" background-repeat:no-repeat ;background-size:100% 100%;background-attachment: fixed;\">");
    fprintf(stream,"</body></html>");
}

void error_sendto_client_403(FILE *stream)
{
    fprintf(stream, "HTTP/1.1");
    fprintf(stream, "Content-type: text/html\n");
    fprintf(stream, "\n");
    fprintf(stream, "<!DOCTYPE html><html><meta http-equiv='Content-Type' content='text/html; charset=utf-8' /><head><title>403 permission denied!</title></head>");
    fprintf(stream, "<body bgcolor="
                    "ffffff"
                    ">\n");
    fprintf(stream,"<body background=\"http://image.iwonder.run/imgs/2020/12/2f5564f7c787c16b.gif\" style=\" background-repeat:no-repeat ;background-size:100% 100%;background-attachment: fixed;\">");
    fprintf(stream,"</body></html>");
}

void bind_port(int server_socket)
{
    bzero((char *)&serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons((unsigned short)port);

    if (bind(server_socket, (struct sockaddr *)&serveraddr,
             sizeof(serveraddr)) < 0)
        error_sendto_stdout("端口绑定出错");
}
char *get_ext(char *filename)
{
    int len, i;
    len = strlen(filename);
    for (i = len - 1; i >= 0; i--)
        if (filename[i] == '.')
        {
            filename = filename + i + 1;
            break;
        }
    return filename;
}
void check_ext(char filetype[], char *ext)
{
    int mimetype_set_flag;
    mimetype_set_flag = 0;
    for (int i = 0; i < sizeof(extensions) / sizeof(exts); ++i)
    {
        if (!strcmp(extensions[i].ext, ext))
        {
            // 如果找到了文件后缀，就返回mimetype
            mimetype_set_flag = 1;
            strcpy(filetype, extensions[i].mimetype);
            break;
        }
    }
    if (!mimetype_set_flag)
    {
        strcpy(filetype, "application/octet-stream");
    }
}
void get_host(struct sockaddr_in clientaddr)
{
    /*  
        gethostbyaddr函数得到client_info
        struct hostent *gethostbyaddr(const char * addr, int len, int type);
        addr：指向网络字节顺序地址的指针
        len： 地址的长度，在AF_INET类型地址中为4
        type：地址类型，应为AF_INET
        */
    if ((client_info = gethostbyaddr((const char *)&clientaddr.sin_addr.s_addr,
                                     sizeof(clientaddr.sin_addr.s_addr), AF_INET)) == NULL)
    {
        h_errno;
        switch (h_errno)
        {
        case HOST_NOT_FOUND:
            error_sendto_stdout("指定的主机是未知的");
            break;
        case NO_RECOVERY:
            error_sendto_stdout("不可恢复的名称服务器发生错误");
            break;
        case TRY_AGAIN:
            error_sendto_stdout("一个临时错误发生在权威域名服务器,请稍后再试");
            break;
        case NO_DATA:
            error_sendto_stdout("请求的名称是有效的，但没有一个IP地址");
            break;
        }
    }
}

void get_host_addr(struct sockaddr_in clientaddr)
{
    // 将一个十进制网络字节序转换为点分十进制IP格式的字符串
    if ((host_addr = inet_ntoa(clientaddr.sin_addr)) == NULL)
        error_sendto_stdout("function inet_ntoa error\n");
}
void handle(struct request *request, int client_socket)
{
    FILE *stream;      // IO流
    char buf[BUFSIZE]; // 缓存区，buf每次取stream1024字节

    if ((stream = fdopen(client_socket, "r+")) == NULL)
        error_sendto_stdout("fdopen error");
    char filename[BUFSIZE]; // 文件名称
    char *filename_;
    char cgi_args[BUFSIZE]; // CGI参数
    int is_static;          // 判断文件状态，是否是静态文件
    char *p;                // 临时变量

    // 判断访问的是静态文件还是CGI程序，并设置正确的文件名
    if (!strstr(request->uri, "cgi-bin")) // 字符串不包含cgi-bin，说明不是访问cgi程序
    {
        is_static = 1; // 是静态文件
        strcpy(cgi_args, "");
        strcpy(filename, ".");                             // filename == "."
        strcat(filename, request->uri);                    // filename == "./"
        if (request->uri[strlen(request->uri) - 1] == '/') // 默认访问./index-basic.html，禁止直接访问路径
            strcat(filename, "index-basic.html");
    }
    else
    {
        is_static = 0; // CGI程序文件
        p = index(request->uri, '?');
        if (p)
        {
            strcpy(cgi_args, p + 1);
            *p = '\0';
        }
        else
        {
            strcpy(cgi_args, "");
        }
        strcpy(filename, ".");
        strcat(filename, request->uri);
    }

    // 判断文件是否存在
    if (stat(filename, &file_status) < 0)
    {
        error_sendto_client_404(stream);
        fclose(stream);
        return;
    }

    // 如果是静态内容，直接返回
    if (is_static)
    {
        char filetype[BUFSIZE]; // 文件类型

        filename_ = filename; // char[] to char *
        check_ext(filetype, get_ext(filename_));

        //  定义返回内容的头部
        fprintf(stream, "HTTP/1.1 200 OK\n");
        fprintf(stream, "Server: Web Server\n");
        fprintf(stream, "Content-length: %d\n", (int)file_status.st_size);
        // 加上charset=UTF-8,正确的显示中文
        fprintf(stream, "Content-type: %s;charset=UTF-8\n", filetype);
        fprintf(stream, "\r\n");
        fflush(stream);

        // 返回文件的所有内容
        int file_content = open(filename_, O_RDONLY);
        p = mmap(0, file_status.st_size, PROT_READ, MAP_PRIVATE, file_content, 0);
        fwrite(p, 1, file_status.st_size, stream);
        munmap(p, file_status.st_size);
        return;
    }

    else
    {

        if (!(S_IFREG & file_status.st_mode) || !(S_IXUSR & file_status.st_mode))
        {
            error_sendto_client_403(stream);
            fclose(stream);
            close(client_socket);
            return;
        }
        setenv("QUERY_STRING", cgi_args, 1);
        sprintf(buf, "HTTP/1.1 200 OK\n");
        write(client_socket, buf, strlen(buf));
        sprintf(buf, "Server: Web Server\n");
        write(client_socket, buf, strlen(buf));

        pid_t pid = fork();
        if (pid < 0)
        {
            perror("创建子进程出错");
            exit(1);
        }
        else if (pid > 0)
        {
            wait(&wait_status);
        }
        else
        {
            close(0);
            dup2(client_socket, 1);
            dup2(client_socket, 2);
            if (execve(filename, NULL, environ) < 0)
            {
                perror("execve函数错误");
            }
        }
        return;
    }
}
char *bufcpy(char *buffer, size_t len)
{
    char *p = malloc(len * sizeof(char));
    memcpy(p, buffer, len * sizeof(char));
    return p;
}
void print_request_header(struct request *request)
{
    printf("\n%s %s %s\n",
           request->method, request->uri, request->version);
    for (int i = 1; i < request->headers_count; ++i)
    {
        printf("%s : %s\n", request->headers[i].field, request->headers[i].value);
    }
}

int analyze_request(char *request_buffer, struct request *request)
{
    char *request_content = malloc(BUFSIZE);
    request_content = bufcpy(request_buffer, BUFSIZE);

    char *request_content_save_buffer;

    // 获得请求头的第一段：请求方法、资源地址、HTTP版本
    request->method = strtok_r(request_content, " \t\n", &request_content_save_buffer);
    request->uri = strtok_r(NULL, " \t", &request_content_save_buffer);
    request->version = strtok_r(NULL, " \t\n", &request_content_save_buffer);

    char *one_line_of_header;
    char *one_line_of_header_buffer;
    char *header_value;
    char *header_value_buffer;

    // 存放一次请求的请求头内容
    struct header _header;
    int header_count = 0;
    int header_is_over = 0;

    request_content = bufcpy(request_buffer, BUFSIZE);

    // 迭代请求头结构体，遍历赋值
    for (;; request_content = NULL)
    {

        if (header_is_over)
        {
            request->body = one_line_of_header_buffer;
            break;
        }

        // 每次得到请求头的一行
        one_line_of_header = strtok_r(request_content, "\n", &one_line_of_header_buffer);

        // 从第二行请求头开始处理
        if (header_count == 0)
        {
            header_count++;
            continue;
        }

        // 将请求头的键值分离存储
        header_value = strtok_r(one_line_of_header, ":", &header_value_buffer);
        strcpy(_header.field, header_value);

        if (header_value == NULL || (strlen(header_value) == 1 && *header_value == EOL[0]))
        {
            header_is_over = 1;
            continue;
        }

        header_value = strtok_r(NULL, "\n", &header_value_buffer);
        header_value_buffer = NULL;
        // 有的请求头值的前面有空格，需要移位处理
        if (*header_value == ' ')
        {
            header_value++;
        }

        strcpy(_header.value, header_value);

        // 将一次请求的请求头内容保存到一个连接中的请求头结构体数组中
        request->headers[header_count++] = _header;
    }

    // 请求头条数计数
    request->headers_count = header_count;
    free(request_content);
    return 1;
}

int main(int argc, char **argv)
{
    int server_socket, client_socket;

    if (argc != 2)
    {
        fprintf(stderr, "请输入有效的端口号! 使用方法：%s [端口]\n", argv[0]);
        exit(1);
    }
    port = atoi(argv[1]);

    // 打开socket文件描述符
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0)
        error_sendto_stdout("socket文件描述符打开失败");

    int optval = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR,
               (const void *)&optval, sizeof(int));

    // 绑定端口
    bind_port(server_socket);
    clientaddrLen = sizeof(clientaddr);

    while (1)
    {
        // 监听,数值很大的话，保存请求头时可能会出现混淆
        if (listen(server_socket, 2) < 0)
            error_sendto_stdout("socket监听出错");

        // 阻塞函数，等待连接
        if ((client_socket = accept(server_socket, (struct sockaddr *)&clientaddr, &clientaddrLen)) < 0)
            error_sendto_stdout("accept函数错误");

        // fork函数返回两次值，内部即实现了两个线程，一个是0（子进程），一个是父进程pid
        pid_t pid = fork();

        if (pid < 0)
        {
            error_sendto_stdout("创建子进程失败\n");
        }
        // 执行子进程
        if (pid == 0)
        {
            // 执行子进程
            close(server_socket);
            get_host(clientaddr);
            get_host_addr(clientaddr);
            struct request req;
            char *request = malloc(BUFSIZE);
            recv(client_socket, request, BUFSIZE, 0);
            if (analyze_request(request, &req) == 1)
            {
                print_request_header(&req);
            }
            handle(&req, client_socket);
            exit(0);
        }
        // 父进程
        else
        {
            close(client_socket);
        }
    }
    close(server_socket);
    return 0;
}