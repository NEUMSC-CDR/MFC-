#include "demo_filter.h"

void error(char *str)
{
    perror(str);
    exit(EXIT_FAILURE);
}
void singnal_func(int sig)
{
    if (sig == SIGINT)
    {
        show_statictics(&data);
        exit(EXIT_SUCCESS);
    }
}

void show_statictics(struct statistics *data){
    printf(COLOR_BOLD "\n┏―――――――――――――――――――――――――――――――――――――――――――――――――――┓\n" COLOR_RESET);
    printf(" " COLOR_REVERSE "                   Statistics                      " COLOR_RESET " \n");
    printf(COLOR_BOLD "┣―――――――――――――――――――――――――――――――――――――――――――――――――――┫\n" COLOR_RESET);
    printf(" ◈ packet_count:                         %10u \n", ntohs(data->packet_count));
    printf(" ◈ tcp_count:                            %10u \n", ntohs(data->tcp_count));
    printf(" ◈ udp_count:                            %10u \n", ntohs(data->udp_count));
    printf(" ◈ icmp_count:                           %10u \n", ntohs(data->icmp_count));
    printf(" ◈ arp_count:                            %10u \n", ntohs(data->arp_count));
    printf(" ◈ unknow_count:                         %10u \n", ntohs(data->unknow_count));
    printf(COLOR_BOLD "┗-------------------------+-------------------------┛\n" COLOR_RESET);
}
    
int ARP_FILTRATOR(struct ether_arp *arp)
{
    if (filter.FLAG[IP_ADDR])
    {
        if (*(int *)(arp)->arp_spa == filter.ip.s_addr || *(int *)(arp)->arp_tpa == filter.ip.s_addr)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        return TRUE;
    }
}
int IP_FILTRATOR(struct ip *ip)
{
    if (filter.FLAG[IP_ADDR])
    {
        if ((ip)->ip_src.s_addr == filter.ip.s_addr || (ip)->ip_dst.s_addr == filter.ip.s_addr)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        return TRUE;
    }
}

int TCP_FILTRATOR(struct tcphdr *tcp)
{
    if (filter.FLAG[PORT])
    {
        if ((tcp)->th_sport == filter.port || (tcp)->th_dport == filter.port)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        return TRUE;
    }
}

int UDP_FILTRATOR(struct udphdr *udp)
{
    if (filter.FLAG[PORT])
    {
        if ((udp)->uh_sport == filter.port || (udp)->uh_dport == filter.port)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        return TRUE;
    }
}
void init_flags()
{
    FLAG[ETHER] = FALSE;
    FLAG[ARP] = FALSE;
    FLAG[IP] = TRUE;
    FLAG[TCP] = TRUE;
    FLAG[UDP] = TRUE;
    FLAG[ICMP] = FALSE;
    FLAG[ALL] = FALSE;
    filter.FLAG[IP_ADDR] = FALSE;
    filter.FLAG[PORT] = FALSE;
}
void flags_all()
{
    FLAG[ETHER] = TRUE;
    FLAG[ARP] = TRUE;
    FLAG[IP] = TRUE;
    FLAG[TCP] = TRUE;
    FLAG[UDP] = TRUE;
    FLAG[ICMP] = TRUE;
}

void handle_choice(int argc, char **argv)
{
    int choice;
    while ((choice = getopt(argc, argv, "aep:f:dhft")) != EOF)
    {
        switch (choice)
        {
        case 'a':
            FLAG[ALL] = TRUE;
            break;
        case 'e':
            FLAG[ETHER] = TRUE;
            break;
        case 'p':
            FLAG[ETHER] = FALSE;
            FLAG[ARP] = FALSE;
            FLAG[IP] = FALSE;
            FLAG[TCP] = FALSE;
            FLAG[UDP] = FALSE;
            FLAG[ICMP] = FALSE;
            optind--;
            while (argv[optind] != NULL && argv[optind][0] != '-')
            {
                if (strcmp(argv[optind], "arp") == 0)
                    FLAG[ARP] = TRUE;
                else if (strcmp(argv[optind], "ip") == 0)
                    FLAG[IP] = TRUE;
                else if (strcmp(argv[optind], "tcp") == 0)
                    FLAG[TCP] = TRUE;
                else if (strcmp(argv[optind], "udp") == 0)
                    FLAG[UDP] = TRUE;
                else if (strcmp(argv[optind], "icmp") == 0)
                    FLAG[ICMP] = TRUE;
                else
                {
                    help(argv[0]);
                }
                optind++;
            }
            break;
        case 'f':
            optind--;
            while (argv[optind] != NULL && argv[optind][0] != '-')
            {
                if (strcmp(argv[optind], "ip") == 0 && argv[optind + 1] != NULL)
                {
                    filter.FLAG[IP_ADDR] = TRUE;
                    filter.ip.s_addr = inet_addr(argv[++optind]);
                }
                else if (strcmp(argv[optind], "port") == 0 && argv[optind + 1] != NULL)
                {
                    filter.FLAG[PORT] = TRUE;
                    filter.port = htons(atoi(argv[++optind]));
                }
                else
                {
                    help(argv[0]);
                }
                optind++;
            }
            break;
        case 'h':
        case '?':
        default:
            help(argv[0]);
            break;
        }
    }
    if (FLAG[ALL])
    {
        flags_all();
    }
    if (optind < argc)
    {
        while (optind < argc)
            printf("%s ", argv[optind++]);
        printf("\n");
        help(argv[0]);
    }
}
int main(int argc, char **argv)
{
    int sock;
    char ifname[256];
    struct sockaddr sock_addr;
    init_flags();
    handle_choice(argc, argv);

    if ((sock = socket(AF_INET, SOCK_PACKET, htons(0x0003))) < 0)
    { /* 0x0003 Every packet */
        error("Socket error, faild to create socket(AF_INET, SOCK_PACKET, htons(0x0003))");
    }
    if (filter.FLAG[IP_ADDR])
        printf("filter ip   = %s\n", inet_ntoa(filter.ip));
    if (filter.FLAG[PORT])
        printf("filter port = %d\n", htons(filter.port));
    memset(&sock_addr, 0, sizeof(sock_addr));
    sock_addr.sa_family = AF_INET;
    strcpy(ifname, "ens33");
    snprintf(sock_addr.sa_data, 256, "%s", ifname);

    // memset(&sock_addr, 0, sizeof(sock_addr));
    // sock_addr.sin_family = AF_INET;
    // sock_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    // sock_addr.sin_port = htons(8080);
    // if (bind(sock, (struct sockaddr *)&sock_addr, sizeof(sock_addr)) < 0)
    if (bind(sock, &sock_addr, sizeof(sock_addr)) < 0)
    {
        error("Bind error,failed to bind sock and sock_addr");
    }
    signal(SIGINT, singnal_func);
    while (1)
    {
        struct ether_header *eth;
        struct ether_arp *arp;
        struct ip *ip;
        struct icmp *icmp;
        struct tcphdr *tcp;
        struct udphdr *udp;
        char buff[8192];
        void *p;
        int len;
        int display = FALSE;
        if ((len = read(sock, buff, 8192)) < 0)
        {
            error("Read from sock error,the buffsize is 8192");
        }
        data.packet_count++;
        p = buff;
        eth = (struct ether_header *)p;
        p += sizeof(struct ether_header);

        if (ntohs(eth->ether_type) == ETHERTYPE_ARP)
        {
            arp = (struct ether_arp *)p;
            if (ARP_FILTRATOR(arp))
            {
                display = TRUE;
            }
        }
        else if (ntohs(eth->ether_type) == ETHERTYPE_IP)
        {
            ip = (struct ip *)p;
            if (FLAG[IP] == TRUE)
                display == TRUE;
            if (!IP_FILTRATOR(ip))
            {
                continue;
            }
            p += ((int)(ip->ip_hl) << 2);
            // types
            switch (ip->ip_p)
            {
            case IPPROTO_TCP:
                tcp = (struct tcphdr *)p;
                p += ((int)(tcp->th_off) << 2);
                if (!TCP_FILTRATOR(tcp))
                {
                    continue;
                }
                if (FLAG[TCP] == TRUE)
                    display = TRUE;
                break;
            case IPPROTO_UDP:
                udp = (struct udphdr *)p;
                p += sizeof(struct udphdr);
                if (FLAG[UDP] == TRUE)
                    display = TRUE;
                if (!UDP_FILTRATOR(udp))
                {
                    continue;
                }
                break;
            case IPPROTO_ICMP:
                icmp = (struct icmp *)p;
                p = icmp->icmp_data;
                if (FLAG[ICMP] == TRUE)
                    display = TRUE;
                break;
            default:
                break;
            }
        }

        if (display == TRUE)
        {
            if (FLAG[ETHER] == TRUE)
            {
                print_ethernet(eth);
            }
            if (ntohs(eth->ether_type) == ETHERTYPE_ARP)
            {
                if (FLAG[ARP] == TRUE)
                    print_arp(arp);
                data.arp_count++;
            }
            else if (ntohs(eth->ether_type) == ETHERTYPE_IP)
            {
                if (FLAG[IP] == TRUE)
                    print_ip(ip);
                if (ip->ip_p == IPPROTO_TCP && FLAG[TCP] == TRUE)
                {
                    data.tcp_count++;
                    print_tcp(tcp);
                }

                else if (ip->ip_p == IPPROTO_UDP && FLAG[UDP] == TRUE)
                {
                    data.udp_count++;
                    print_udp(udp);
                }

                else if (ip->ip_p == IPPROTO_ICMP && FLAG[ICMP] == TRUE)
                {
                    data.icmp_count++;
                    print_icmp(icmp);
                }

                else if (FLAG[ALL] == TRUE)
                {
                    data.unknow_count++;
                    printf("Protocol: unknown\n");
                }
            }
            printf("\n");
        }
    }
    return 0;
}

char *format_mac(unsigned char *d)
{
    static char str[50];
    snprintf(str, 50, "%02x:%02x:%02x:%02x:%02x:%02x",
             d[0], d[1], d[2], d[3], d[4], d[5]);
    return str;
}

void print_ethernet(struct ether_header *eth)
{
    int type = ntohs(eth->ether_type);

    // printf("Ethernet Frame:\n");
    printf(COLOR_YELLOW "┏―――――――――――――――――――――――――――――――――――――――――――――――――――┓\n" COLOR_RESET);

    printf("" COLOR_REVERSE "     Ethernet Frame      " COLOR_RESET);

    if (type < 1500)
        printf(COLOR_YELLOW "| Length:            %5u|\n" COLOR_RESET, type);
    else
        printf(COLOR_YELLOW "| Ethernet Type:    0x%04x|\n" COLOR_RESET, type);
    printf(COLOR_YELLOW "┣―――――――――――――――――――――――――――――――――――――――――――――――――――┫\n" COLOR_RESET);
    printf(" ◈ Destination MAC Address:"
           "        %17s\n",
           format_mac(eth->ether_dhost));
    printf(" ◈ Source MAC Address:     "
           "        %17s\n",
           format_mac(eth->ether_shost));
    printf(COLOR_YELLOW "┗-------------------------+-------------------------┛\n" COLOR_RESET);
}

void print_arp(struct ether_arp *arp)
{
    char *arp_op_name[] = {
        "Undefine",
        "(ARP Request)",
        "(ARP Reply)",
        "(RARP Request)",
        "(RARP Reply)"};
    int ARP_OP_MAX = (sizeof arp_op_name / sizeof arp_op_name[0]);
    int op = ntohs(arp->ea_hdr.ar_op);
    if (op < 0 || ARP_OP_MAX < op)
        op = 0;

    printf(COLOR_BLUE "┏―――――――――――――――――――――――――――――――――――――――――――――――――――┓\n" COLOR_RESET);
    printf(" " COLOR_REVERSE "                    Protocol: ARP                  " COLOR_RESET " \n");
    printf(COLOR_BLUE "┣―――――――――――――――――――――――――――――――――――――――――――――――――――┫\n" COLOR_RESET);
    printf(" ◈ OP:     %4d  %16s:                         \n", ntohs(arp->ea_hdr.ar_op), arp_op_name[op]);
    printf(" ◈ Source MAC Address:            %17s \n", format_mac(arp->arp_sha));
    printf(" ◈ Destination MAC Address:       %17s \n", format_mac(arp->arp_tha));
    printf(" ◈ Source IP Address:              %16s \n", inet_ntoa(*(struct in_addr *)&arp->arp_spa));
    printf(" ◈ Destination IP Address:         %16s \n", inet_ntoa(*(struct in_addr *)&arp->arp_tpa));
    printf(COLOR_BLUE "┗-------------------------+-------------------------┛\n" COLOR_RESET);
}

char *format_ip_flag(int flag)
{
    int f[] = {'R', 'D', 'M'};
    int IP_FLG_MAX = (sizeof f / sizeof f[0]);
    char str[IP_FLG_MAX + 1];
    unsigned int mask = 0x8000;
    int i;

    for (i = 0; i < IP_FLG_MAX; i++)
    {
        if (((flag << i) & mask) != 0)
            str[i] = f[i];
        else
            str[i] = '0';
    }
    str[i] = '\0';

    return str;
}

char *format_ip_tos(int flag)
{
    int f[] = {'1', '1', '1', 'D', 'T', 'R', 'C', 'X'};
    int TOS_MAX = (sizeof f / sizeof f[0]);
    char str[TOS_MAX + 1];
    unsigned int mask = 0x80;
    int i;
    for (i = 0; i < TOS_MAX; i++)
    {
        if (((flag << i) & mask) != 0)
            str[i] = f[i];
        else
            str[i] = '0';
    }
    str[i] = '\0';
    return str;
}

void print_ip(struct ip *ip)
{
    printf(COLOR_BLUE "┏―――――――――――――――――――――――――――――――――――――――――――――――――――┓\n" COLOR_RESET);
    printf(" " COLOR_REVERSE "                    Protocol: IP                  " COLOR_RESET " \n");
    printf(COLOR_BLUE "┣―――――――――――――――――――――――――――――――――――――――――――――――――――┫\n" COLOR_RESET);
    printf(" ◈ version:       %5u   ◈ header length:%10u \n", ip->ip_v, ip->ip_hl);
    printf(" ◈ Identifier:    %5u   ◈ Total Length: %10u \n", ip->ip_id, ip->ip_len);
    printf(" ◈ TTL:           %5u   ◈ Protocol:     %10u \n", ip->ip_ttl, ip->ip_p);
    printf(" ◈ Checksum:                              %10u \n", ntohs(ip->ip_sum));
    printf(" ◈ Source IP Address:                %15s\n", inet_ntoa(*(struct in_addr *)&(ip->ip_src)));
    printf(" ◈ Destination IP Address:           %15s\n", inet_ntoa(*(struct in_addr *)&(ip->ip_dst)));
    printf(COLOR_BLUE "┗-------------------------+-------------------------┛\n" COLOR_RESET);
}

void print_icmp(struct icmp *icmp)
{
    char *type_name[] = {
        "Echo Reply",
        "Undefine",
        "Undefine",
        "Destination Unreachable",
        "Source Quench",
        "Redirect (change route)",
        "Undefine",
        "Undefine",
        "Echo Request",
        "Undefine",
        "Undefine",
        "Time Exceeded",
        "Parameter Problem",
        "Timestamp Request",
        "Timestamp Reply",
        "Information Request",
        "Information Reply",
        "Address Mask Request",
        "Address Mask Reply",
        "Unknown"};
    int ICMP_TYPE_MAX = (sizeof type_name / sizeof type_name[0]);
    int type = icmp->icmp_type;

    if (type < 0 || ICMP_TYPE_MAX <= type)
        type = ICMP_TYPE_MAX - 1;

    printf("┏―――――――――――――――――――――――――――――――――――――――――――――――――――┓\n");
    printf(" " COLOR_BOLD "     Protocol: ICMP (%s)                  "
           " \n" COLOR_RESET,
           type_name[type]);
    printf("┣―――――――――――――――――――――――――――――――――――――――――――――――――――┫\n");

    printf(" ◈ Type:            %3u  ◈ Checksum:           %5u \n",
           icmp->icmp_type, ntohs(icmp->icmp_cksum));
    printf("┣-------------------------+-------------------------┫\n");
    if (icmp->icmp_type == 0 || icmp->icmp_type == 8)
    {
        printf(" ◈ Identification:%5u  ◈ Sequence Number:    %5u \n",

               ntohs(icmp->icmp_id), ntohs(icmp->icmp_seq));
        printf("┗-------------------------+-------------------------┛\n");
    }
    else if (icmp->icmp_type == 3)
    {
        if (icmp->icmp_code == 4)
        {
            printf(" ◈ void:          %5u  ◈ Next MTU:           %5u \n",
                   ntohs(icmp->icmp_pmvoid), ntohs(icmp->icmp_nextmtu));
            printf("┗-------------------------+-------------------------┛\n");
        }
        else
        {
            printf(" ◈ Unused:                               %10lu \n",
                   (unsigned long)ntohl(icmp->icmp_void));
            printf("┗-------------------------+-------------------------┛\n");
        }
    }
    else if (icmp->icmp_type == 5)
    {
        printf(" ◈ Router IP Address:                %15s\n",
               inet_ntoa(*(struct in_addr *)&(icmp->icmp_gwaddr)));
        printf("┗-------------------------+-------------------------┛\n");
    }
    else if (icmp->icmp_type == 11)
    {
        printf(" ◈ Unused:                               %10lu \n",
               (unsigned long)ntohl(icmp->icmp_void));
        printf("┗-------------------------+-------------------------┛\n");
    }

    if (icmp->icmp_type == 3 || icmp->icmp_type == 5 || icmp->icmp_type == 11)
    {
        struct ip *ip = (struct ip *)icmp->icmp_data;
        char *p = (char *)ip + ((int)(ip->ip_hl) << 2);

        print_ip(ip);
        switch (ip->ip_p)
        {
        case IPPROTO_TCP:
            print_tcp_mini((struct tcphdr *)p);
            break;
        case IPPROTO_UDP:
            print_udp((struct udphdr *)p);
            break;
        }
    }
}

void print_tcp_mini(struct tcphdr *tcp)
{
    printf(COLOR_BLUE "┏―――――――――――――――――――――――――――――――――――――――――――――――――――┓\n" COLOR_RESET);
    printf(" " COLOR_REVERSE "                    Protocol: TCP                  " COLOR_RESET " \n");
    printf(COLOR_BLUE "┣―――――――――――――――――――――――――――――――――――――――――――――――――――┫\n" COLOR_RESET);
    printf(" ◈ Source Port:                          %10u \n", ntohs(tcp->th_sport));
    printf(" ◈ Destination Port:                     %10u \n", ntohs(tcp->th_dport));
    printf(" ◈ Sequence Number:                      %10lu \n", (unsigned long)ntohl(tcp->th_seq));
    printf(COLOR_BLUE "┗-------------------------+-------------------------┛\n" COLOR_RESET);
}

void print_tcp(struct tcphdr *tcp)
{
    printf(COLOR_BLUE "┏―――――――――――――――――――――――――――――――――――――――――――――――――――┓\n" COLOR_RESET);
    printf(" " COLOR_REVERSE "                    Protocol: TCP                  " COLOR_RESET " \n");
    printf(COLOR_BLUE "┣―――――――――――――――――――――――――――――――――――――――――――――――――――┫\n" COLOR_RESET);
    printf(" ◈ Source Port:                          %10u \n", ntohs(tcp->th_sport));
    printf(" ◈ Destination Port:                     %10u \n", ntohs(tcp->th_dport));
    printf(" ◈ Sequence Number:                      %10lu\n", (unsigned long)ntohl(tcp->th_seq));
    printf(" ◈ Acknowledgement Number:               %10lu\n", (unsigned long)ntohl(tcp->th_ack));
    printf(" ◈ Window Size:                          %10u \n", ntohs(tcp->th_win));
    printf(" ◈ Checksum:                             %10u \n", ntohs(tcp->th_sum));
    printf(COLOR_BLUE "┗-------------------------+-------------------------┛\n" COLOR_RESET);
}

char *format_tcp(int flag)
{
    int f[] = {'U', 'A', 'P', 'R', 'S', 'F'};
    int TCP_FLG_MAX = (sizeof f / sizeof f[0]);
    char str[TCP_FLG_MAX + 1];
    unsigned int mask = 1 << (TCP_FLG_MAX - 1);
    int i;
    for (i = 0; i < TCP_FLG_MAX; i++)
    {
        if (((flag << i) & mask) != 0)
            str[i] = f[i];
        else
            str[i] = '0';
    }
    str[i] = '\0';

    return str;
}

void print_udp(struct udphdr *udp)
{

    printf(COLOR_BLUE "┏―――――――――――――――――――――――――――――――――――――――――――――――――――┓\n" COLOR_RESET);
    printf(" " COLOR_REVERSE "                    Protocol: UDP                  " COLOR_RESET " \n");
    printf(COLOR_BLUE "┣―――――――――――――――――――――――――――――――――――――――――――――――――――┫\n" COLOR_RESET);
    printf(" ◈ Source Port:                          %10u \n", ntohs(udp->uh_sport));
    printf(" ◈ Destination Port:                     %10u \n", ntohs(udp->uh_dport));
    printf(" ◈ Length:                               %10u \n", ntohs(udp->uh_ulen));
    printf(" ◈ Checksum:                             %10u \n", ntohs(udp->uh_sum));
    printf(COLOR_BLUE "┗-------------------------+-------------------------┛\n" COLOR_RESET);
}

void help(char *cmd)
{
    printf(COLOR_BLUE "┏――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――┓\n" COLOR_RESET);
    printf(" " COLOR_REVERSE "                           Help                             " COLOR_RESET " \n");
    printf(COLOR_BLUE "┣――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――┫\n" COLOR_RESET);
    printf(COLOR_BOLD"  usage: %s [-a all protocols] [-e ether] [-p protocols]  \n"COLOR_RESET,cmd);
    printf(COLOR_BOLD"            [-f filters(ip/port)] [-h/-? help]\n"COLOR_RESET,cmd);
    printf(COLOR_BLUE "┣――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――┫\n" COLOR_RESET);
    printf(" ◈ -a : show all protocols infomation,default IP TCP UDP\n");
    printf(" ◈ -e : show ether header's infomation,default not\n");
    printf(" ◈ -p : select the protocol to show (arp ip tcp up icmp) \n");
    printf(" ◈ -f : define filtering rules (-f ip 39.105.228.43 port 443)\n");
    printf(COLOR_BLUE "┗-------------------------+----------------------------------┛\n" COLOR_RESET);
    exit(EXIT_FAILURE);
}
