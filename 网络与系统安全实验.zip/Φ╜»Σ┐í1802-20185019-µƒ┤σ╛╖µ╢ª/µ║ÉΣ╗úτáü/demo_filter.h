
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include <netinet/if_ether.h>
#include <signal.h>

#define TRUE 1
#define FALSE 0
#define COLOR_YELLOW "\x1b[33m"
#define COLOR_BLUE "\e[0;34m" 
#define COLOR_RESET "\x1b[0m"
#define COLOR_BOLD "\e[1m"
#define COLOR_REVERSE "\e[7m"

struct FILTER
{
    struct in_addr ip;
    unsigned short int port;
    int FLAG[2];
};

struct statistics
{
    int packet_count;
    int tcp_count;
    int udp_count;
    int icmp_count;
    int arp_count;
    int unknow_count;
};

enum
{
    ETHER,
    ARP,
    IP,
    TCP,
    UDP,
    ICMP,
    ALL,
};
enum
{
    IP_ADDR,
    PORT
};
int FLAG[7];
struct FILTER filter;
struct statistics data;

int ARP_FILTRATOR(struct ether_arp *arp);
int IP_FILTRATOR(struct ip *ip);
int TCP_FILTRATOR(struct tcphdr *tcp);
int UDP_FILTRATOR(struct udphdr *udp);
void print_ethernet(struct ether_header *eth);
void print_arp(struct ether_arp *arp);
void print_ip(struct ip *ip);
void print_icmp(struct icmp *icmp);
void print_tcp(struct tcphdr *tcp);
void print_tcp_mini(struct tcphdr *tcp);
void print_udp(struct udphdr *udp);
void dump_packet(unsigned char *buff, int len);
char *format_mac(unsigned char *d);
char *format_tcp(int flag);
char *format_ip_tos(int flag);
char *format_ip_flag(int flag);
void handle_choice(int argc, char **argv);
void help(char *cmd);
void init_flags();
void flags_all();
void error(char *str);
void singnal_func(int sig);