#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow *instance;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    instance = this;
    setFixedSize(757,629);
}

MainWindow::~MainWindow()
{
    delete ui;
}


MainWindow *MainWindow::getInstance()
{
    return instance;
}

void MainWindow::on_pushButton_clicked()
{
    startSniffer(100);
}

QString errClr = "de7e73";
QString highClr = "A593E0";

//抓取数据包，传入抓取数量
void MainWindow::startSniffer(int num)
{
    //获取
    ui->textBrowser_2->append("正在搜索设备...");
    if(pcap_findalldevs(&allDev, errbuf) == -1)
    {
        ui->textBrowser_2->append(QString("<font color=\"#%1\"> 未找到可用网卡</font>").arg(errClr));
        printf("No device has been found! \n");
    }
    dev = allDev -> name;
    ui->textBrowser_2->append(QString("监听网卡: <font color=\"#%1\"> %2 </font>\n").arg(highClr).arg(dev));

    /*硬编码    dev = "eth0";*/

    //打开设备网络

//    pcap_t * pcap_open_live(char *device, int snaplen, int promisc, int to_ms, char *ebuf);
//    - snaplen参数定义捕获数据的最大字节数， 一般使用BUFSIZ， 该参数一般位于<pcap.h>中，若没有定义，应使用unsigned int的最大值。
//    - promisc指定是否将网络接口置于混杂模式， 如果设置为true(当promisc>0时)可以使用混杂模式进行数据包的抓取。
//    - to_ms参数指定超时时间（毫秒），如果设置为0意味着没有超时等待这一说法。
//    - ebuf参数则仅在pcap_open_live()函数出错返回NULL时用于传递错误消息。
    pcap = pcap_open_live(dev, snapLen, 1, 0, errbuf); // 混合模式，如果出错将返回空指针
    if(pcap == nullptr)
    {
        ui->textBrowser_2->append(QString("<font color=\"#%1\">打开网络设备(pcap_open_live)出现错误</font>").arg(errClr));
        ui->textBrowser_2->append(errbuf);
    }


//  pcap_lookupnet用于获取网卡的网络号和子网掩码。其中device参数是网卡名，netp 和maskp表示将要获得的网络号和子网掩码
    if(pcap_lookupnet(dev, &net, &mask, errbuf) == -1)
    {
        ui->textBrowser_2->append(QString("<font color=\"#%1\">pcap_lookupnet出现错误</font>").arg(errClr));
        ui->textBrowser_2->append(errbuf);
        net = 0;
        mask = 0;
    }
//   由于抓数据包占用内存可能导致界面操作不被及时响应（假死），调用者个函数优先处理界面操作
    QApplication::processEvents();
    /*BPF过滤规则的结构体
    struct bpf_program {
        u_int bf_len;
        struct bpf_insn *bf_insns;
    };
    */
    struct bpf_program bp;
    //读取过滤条件
    if(!ui->lineEdit->text().isEmpty())
    {
        filter = QString(ui->lineEdit->text().toStdString().data());

//        int pcap_compile(pcap_t *p, struct bpf_program *fp,char *str, int optimize, bpf_u_int32 netmask)
//        将str参数bai指定的字符du串编译到过滤程序zhi中。
//        fp是一个bpf_program结构的指针，在pcap_compile()函数中被赋值。
//        optimize参数控制结果代码的dao优化。
//        netmask参数指定本地网络的网络掩码。
        if(pcap_compile(pcap, &bp, filter.toLatin1(), 0, net) == -1)
        {
            QMessageBox *msgBox = new QMessageBox(QMessageBox::Information,QString("错误"),QString(QLatin1String("BPF规则不合法！")));
            QTimer::singleShot(2000,msgBox,SLOT(accept()));
            msgBox->exec();
            exit(-2);
        }

//        int pcap_setfilter(pcap_t *p, struct bpf_program *fp)
//         p：表示pcap的会话句柄；
//         fp：表示经过编译后的过滤规则；
//         返回值：-1表示操作失败，其他值表成功。
        if(pcap_setfilter(pcap, &bp) == -1)
        {
            QMessageBox *msgBox = new QMessageBox(QMessageBox::Information,QString("错误"),QString(QLatin1String("BPF规则不合法！")));
            QTimer::singleShot(2000,msgBox,SLOT(accept()));
            msgBox->exec();
            exit(-2);
        }
    }
    QApplication::processEvents();
    int ok = 0;
    pcap_loop(pcap, num, flowAnalyze, (u_char *) &ok);

    //关闭设备
    pcap_close(pcap);
    ui->textBrowser_2->append(QString("<font color=\"#%1\"> 监听结束 </font>\n").arg(highClr));
}



//停止循环
void MainWindow::stopSniffer()
{
    pcap_breakloop(pcap);
}

//arp协议头分析
QString MainWindow::arpAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet)
{
    struct arp *aHead = (struct arp *)(packet + 6);

    QString res;
    res.clear();

    if(ntohs(aHead -> arpProtocol) == 0x0800)
    {

        res += "\n上层协议类型为: IPV4";
    }
    else
    {
        res += "\n上层协议类型为: 其他";
    }

    if(ntohs(aHead -> arpOperation) == 1)
    {
        res+="\nARP包类型：ARP请求包";
    }
    else
    {
        res+="\nARP包类型：ARP应答包";
    }

    return res;
}


void flowAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet)
{
    MainWindow *main = MainWindow::getInstance();

    struct ethernet *eHead;
    u_short protocol;
    char *time = ctime((const time_t*)&pcapPkt -> ts.tv_sec);
    long long flow = pcapPkt -> len;

    main->id++;

    QString data = "\n============信息总览============\n"
                "BPF规则："+main->filter+"\n"
                "网卡设备："+QString(main->dev)+"\n"
                "流量包ID："+QString::number(main->id)+"\n"
                "流量包长度："+QString::number(flow)+"\n"
                "接受时间："+QString(QLatin1String(time))+
                "================================";
    data += "\n************* 网络层 *************";
    main->ui->textBrowser_2->append(data);
    data.clear(); // 清空元素，复用

    eHead = (struct ethernet*)packet; // 以太网帧头部
    protocol = ntohs(eHead -> etherType); // 类型为 unsigned short int
    switch (protocol)
    {
    case 0x0800: //2048
        data += "流量包网络层协议为：IPv4";
        data += main->ipAnalyze(arg, pcapPkt, packet);
        break;
    case 0x0806: //2054
        data += "流量包网络层协议为：ARP";
        data += main->arpAnalyze(arg, pcapPkt, packet);
        main->arpCnt ++;
        break;
    case 0x0835:
        data += "流量包网络层协议为：RARP";
        break;
    case 0x08DD:
        data += "流量包网络层协议为：IPv6";
        break;
    default:
        data += "流量包网络层为其他类型协议";
        main->otherCnt ++;
        break;
    }
    main->ui->textBrowser_2->append(data);
    data.clear();
}

//icmp协议头分析
QString MainWindow::icmpAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet)
{
    struct icmp *icmpHead = (struct icmp *)(packet + ethernetAddr + ipHead(packet));
    int icmpType = icmpHead -> icmpType - 0; // char 转为 int

    QString res;
    res.clear();
    res += "ICMP类型:";
    switch (icmpType)
    {
    case 0x08:
        res += "ICMP请求包\n";
        break;
    case 0x00:
        res += "ICMP应答包\n";
        break;
    case 0x11:
        res += "请求超时\n";
        break;
    }
    res += "ICMP code为："+QString(icmpHead->icmpCode);
    res += "ICMP校验值为"+QString::number(icmpHead->icmpCkSum);
    return res;
}

//tcp标志位分析
char *tcpFlagAnalyze(const u_char tcpFlags)
{
    char flags[100] = "";
    if((tcpCWR & tcpFlags) == tcpCWR)
        strncat(flags, "CWR: ", 100);
    if((tcpECE & tcpFlags) == tcpECE)
        strncat(flags, "ECE: ", 100);
    if((tcpURG & tcpFlags) == tcpURG)
        strncat(flags, "URG: ", 100);
    if((tcpACK & tcpFlags) == tcpACK)
        strncat(flags, "ACK: ", 100);
    if((tcpPSH & tcpFlags) == tcpPSH)
        strncat(flags, "PSH: ", 100);
    if((tcpRST & tcpFlags) == tcpRST)
        strncat(flags, "RST: ", 100);
    if((tcpSYN & tcpFlags) == tcpSYN)
        strncat(flags, "SYN: ", 100);
    if((tcpFIN & tcpFlags) == tcpFIN)
        strncat(flags, "FIN: ", 100);
    flags[99] = '\0';
    return flags;
}

//tcp协议头分析
QString MainWindow::tcpAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet)
{
    struct tcp *tHead = (struct tcp *)(packet + ethernetAddr + ipHead(packet)); // 根据各层协议位置计算出偏移量
    QString res;
    res.clear();
    res += "\n源端口:"+QString::number(ntohs(tHead -> tcpS));
    res += "\n目的端口:"+QString::number(ntohs(tHead -> tcpD));
    res += "\nSeq值:"+QString::number(ntohs(tHead -> tcpSeq));
    res += "\nAck值:"+QString::number(ntohs(tHead -> tcpAck));
    res += "\nTCP头部长度:"+QString::number((tHead -> tcpHR & 0xf0) >> 4);
    res += "\n校验值:"+QString::number(ntohs(tHead -> tcpCkSum));

    res += "\n************* 分析结束 *************\n";
    return res;
}

//udp协议头分析
QString MainWindow::udpAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet)
{
    struct udp *uHead = (struct udp *)(packet + ethernetAddr + ipHead(packet));

    QString res;
    res.clear();
    res += "\nUDP包长度:"+QString::number((int)ntohs(uHead -> udpLen));
    res += "\n校验值:"+QString::number((int)ntohs(uHead -> udpCkSum));
    res += "\n************* 分析结束 *************\n";
    return res;
}

//ip协议头分析
QString MainWindow::ipAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet)
{
    struct ip *ipHead;
    ipHead = (struct ip *)(packet + 14); // 获得IP协议头

    QString res;
    res.clear();

    res += "\n版本号:"+QString::number((ipHead -> ipHV & 0xf0) >> 4);
    res += "\n协议头长度:"+QString::number(ipHead -> ipLen);
    res += "\nIP包ID:"+QString::number(ipHead -> ipId);
    res += "\nTTL(存活时间):"+QString::number(ipHead -> ipTtl +0); // char转为int
    res += "\n协议号:"+QString::number(ipHead -> ipProtocol +0);
    res += "\nIP包校验值:"+QString::number(ipHead -> ipCkSum);

    int protocol = (int)(ipHead -> ipProtocol);
    qDebug()<<protocol;
    if(protocol == 1)
    {
        res += "\n流量包协议为：ICMP\n";
        res += icmpAnalyze(arg, pcapPkt, packet);
        icmpCnt ++;
    }

    res += "\n************* 传输层 *************\n";
    //IP层协议分流
    switch (protocol)
    {
    case 6:
        res += "流量包协议为：TCP";
        res += tcpAnalyze(arg, pcapPkt, packet);
        tcpCnt ++;
        break;
    case 17:
        res += "流量包协议为：UDP";
        res += udpAnalyze(arg, pcapPkt, packet);
        udpCnt ++;
        break;
    case 2:
        res += "流量包协议为：IGMP";
        break;
    default:
        res += "不能识别此协议";
        break;
    }
    return res;
}

void MainWindow::on_pushButton_3_clicked()
{
    stopSniffer();
}

void MainWindow::on_pushButton_4_clicked()
{
    ui->textBrowser_2->clear();
}

void MainWindow::on_pushButton_2_clicked()
{
    QString data = ui->textBrowser_2->toPlainText();
    std::ofstream out("./log.txt",std::ios::app);//app表示每次操作前均定位到文件末尾
    if(!out.fail()){
        out<<"日志文件:\n"<<data.toLocal8Bit().data()<<std::endl;
        out.close();
    }

}

// 更新统计
void MainWindow::on_pushButton_5_clicked()
{

    ui->lineEdit_2->setText(QString::number(id)+"条");
    ui->lineEdit_3->setText(QString::number(arpCnt)+"条");
    ui->lineEdit_4->setText(QString::number(udpCnt)+"条");
    ui->lineEdit_5->setText(QString::number(tcpCnt)+"条");
    ui->lineEdit_6->setText(QString::number(icmpCnt)+"条");
}
