#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <pcap/pcap.h>
#include <netinet/in.h>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <QMessageBox>
#include <QTimer>
#include <iostream>
#include <fstream>
#include <QDebug>
#include <memory.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);

    static MainWindow* getInstance(); // 在静态函数中操控MainWindow对象，实现操控主界面控件

    Ui::MainWindow *ui;
    char *dev; //抓包设备
    QString filter; //过滤条件
    pcap_t *pcap; // 原始流量
    char errbuf[PCAP_ERRBUF_SIZE]; // 错误信息
    pcap_if_t *allDev; //设备（网卡）
    unsigned int net; //网络地址
    unsigned int mask; // 掩码
    int id; // 流量包id
    int ethernetHead=14;
    int ethernetAddr=6;
    int tcpCnt = 0,arpCnt = 0,udpCnt = 0,icmpCnt = 0, otherCnt = 0;

    QString arpAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet);
    QString icmpAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet);
    QString tcpAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet);
    QString udpAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet);
    QString ipAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet);

    void insertData(QString data);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_5_clicked();

private:

    void startSniffer(int num);
    void stopSniffer();

};


#define ipHead(packet) ((((struct ip *)(packet + ethernetHead)) -> ipHV & 0x0f) * 4)
//ip头字节数
// 取低4位即头部长度，单位4B，强转ip结构体
#define snapLen 1518
//最大抓包长度
// Ethernet 1500字节 + 以太网帧头部14字节 + 以太网帧尾部4字节
//TCP 标志位
#define tcpFIN 0x01
#define tcpSYN 0x02
#define tcpRST 0x04
#define tcpPSH 0x08
#define tcpACK 0x10
#define tcpURG 0x20
#define tcpECE 0x40
#define tcpCWR 0x80

void flowAnalyze(u_char *arg, const struct pcap_pkthdr *pcapPkt, const u_char *packet);

struct ethernet
{
    unsigned char etherHostD[6];
    unsigned char etherHostS[6];
    unsigned short etherType;
};


struct ip
{

   unsigned char ipHV;     //4位首部长度+4位IP版本号
   unsigned char ipTos;       //服务类型
   unsigned short ipLen;  //总长度
   unsigned short ipId;       //标志
   unsigned short frag_and_flags; //分片和偏移
   unsigned char ipTtl;       //生存时间
   unsigned char ipProtocol;  //协议
   unsigned short ipCkSum;  //检验和
   struct in_addr srcaddr;  //源IP地址
   struct in_addr dstaddr;  //目的IP地址

};

struct tcp
{
    unsigned short tcpS;    //源端口号
    unsigned short tcpD;    //目的端口号
    unsigned int tcpSeq;        //序列号
    unsigned int tcpAck;        //确认号
    unsigned char tcpHR; //16位，包含以上全部内容
    unsigned char tcpFlag;

    unsigned short tcpWin;    //16位窗口大小
    unsigned short tcpCkSum;     //16位TCP检验和
    unsigned short tcpUrgP;      //16为紧急指针
};

struct udp
{
   unsigned short udpS; //远端口号
   unsigned short udpD; //目的端口号
   unsigned short udpLen;      //udp头部长度
   unsigned short udpCkSum;  //16位udp检验和
};

struct arp
{

    unsigned short arpHardware;//硬件类型
    unsigned short arpProtocol;//协议类型
    unsigned char arpMac;//硬件地址长度(6)
    unsigned char arpIp;//协议地址长度(4)
    unsigned short arpOperation;//操作类型(1-ARP请求 2-ARP应答 3-RARP请求 4-RARP应答)
    unsigned char arpSM[6];//发送端MAC地址
    in_addr arpSI;//发送端IP地址
    unsigned char arpDM[6];//目的端MAC地址
    in_addr arpDI;//目的端IP地址


};

struct icmp
{
   unsigned char icmpType;   //类型
   unsigned char icmpCode;        //代码
   unsigned short icmpCkSum;    //16位检验和

};

#endif // MAINWINDOW_H
