﻿// EnDecoder.cpp : 实现文件
//

#include "stdafx.h"
#include "EX_SDI.h"
#include "EnDecoder.h"
#include "afxdialogex.h"
// #include "Python.h"
#include "String"
#include <afxpriv.h>
#include <stdlib.h>  
using namespace std;

// EnDecoder 对话框

IMPLEMENT_DYNAMIC(EnDecoder, CDialogEx)

EnDecoder::EnDecoder(CWnd* pParent /*=NULL*/)
	: CDialogEx(EnDecoder::IDD, pParent)
{

}

EnDecoder::~EnDecoder()
{
}

void EnDecoder::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(EnDecoder, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_b64encode, &EnDecoder::OnBnClickedButtonb64encode)
	ON_BN_CLICKED(IDC_BUTTON_b64decode, &EnDecoder::OnBnClickedButtonb64decode)
	//ON_BN_CLICKED(IDC_BUTTON_b32encode, &EnDecoder::OnBnClickedButtonb32encode)
	//ON_BN_CLICKED(IDC_BUTTON_b32decode, &EnDecoder::OnBnClickedButtonb32decode)
	ON_BN_CLICKED(IDC_BUTTON_utf82unicode, &EnDecoder::OnBnClickedButtonutf82unicode)
	ON_BN_CLICKED(IDC_BUTTON_unicode2utf8, &EnDecoder::OnBnClickedButtonunicode2utf8)
	ON_BN_CLICKED(IDC_BUTTON_URLencode2, &EnDecoder::OnBnClickedButtonUrlencode2)
	ON_BN_CLICKED(IDC_BUTTON_URLdecode, &EnDecoder::OnBnClickedButtonUrldecode)
	ON_BN_CLICKED(IDC_BUTTON_char2hex, &EnDecoder::OnBnClickedButtonchar2hex)
	ON_BN_CLICKED(IDC_BUTTON_hex2char, &EnDecoder::OnBnClickedButtonhex2char)
	ON_BN_CLICKED(IDC_BUTTON_mecding, &EnDecoder::OnBnClickedButtonmecding)
	ON_BN_CLICKED(IDC_BUTTON_cmcoding, &EnDecoder::OnBnClickedButtoncmcoding)
END_MESSAGE_MAP()



// Base64的加解密函数实现

unsigned char * base64 = (unsigned char *)"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
CString Base64::Encode(CString src, int srclen)
{
	int n, buflen, i, j;
	static unsigned char *dst;
	CString buf = src;
	buflen = n = srclen;
	dst = (unsigned char*)malloc(buflen / 3 * 4 + 3);
	memset(dst, 0, buflen / 3 * 4 + 3);
	for (i = 0, j = 0; i <= buflen - 3; i += 3, j += 4) {
		dst[j] = (buf[i] & 0xFC) >> 2;
		dst[j + 1] = ((buf[i] & 0x03) << 4) + ((buf[i + 1] & 0xF0) >> 4);
		dst[j + 2] = ((buf[i + 1] & 0x0F) << 2) + ((buf[i + 2] & 0xC0) >> 6);
		dst[j + 3] = buf[i + 2] & 0x3F;
	}
	if (n % 3 == 1) {
		dst[j] = (buf[i] & 0xFC) >> 2;
		dst[j + 1] = ((buf[i] & 0x03) << 4);
		dst[j + 2] = 64;
		dst[j + 3] = 64;
		j += 4;
	}
	else if (n % 3 == 2) {
		dst[j] = (buf[i] & 0xFC) >> 2;
		dst[j + 1] = ((buf[i] & 0x03) << 4) + ((buf[i + 1] & 0xF0) >> 4);
		dst[j + 2] = ((buf[i + 1] & 0x0F) << 2);
		dst[j + 3] = 64;
		j += 4;
	}
	for (i = 0; i < j; i++)
		dst[i] = base64[(int)dst[i]];
	dst[j] = 0;
	return CString(dst);
}

CString Base64::Decode(CString inpt, int srclen)
{
	int n, i, j, pad;
	unsigned char *p;
	static unsigned char *dst;
	unsigned char * src;
	srclen = 0;
	pad = 0;
	n = inpt.GetLength();
	src = new unsigned char[n];
	for (i = 0; i < n; i++)
		src[i] = inpt[i];

	while (n>0 && src[n - 1] == '=') {
		src[n - 1] = 0;
		pad++;
		n--;
	}
	for (i = 0; i < n; i++) {
		p = (unsigned char *)strchr((const char *)base64, (int)src[i]);
		if (!p)
			break;
		src[i] = p - (unsigned char *)base64;
	}

	dst = (unsigned char *)malloc(n * 3 / 4 + 1);
	memset(dst, 0, n * 3 / 4 + 1);
	for (i = 0, j = 0; i < n; i += 4, j += 3) {
		dst[j] = (src[i] << 2) + ((src[i + 1] & 0x30) >> 4);
		dst[j + 1] = ((src[i + 1] & 0x0F) << 4) + ((src[i + 2] & 0x3C) >> 2);
		dst[j + 2] = ((src[i + 2] & 0x03) << 6) + src[i + 3];
		srclen += 3;
	}
	srclen -= pad;
	return CString(dst);
}

void EnDecoder::OnBnClickedButtonb64encode()
{
	// TODO:  在此添加控件通知处理程序代码
	CString str;
	CString b64encode_str;
	Base64 _Base64;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str);
	b64encode_str = _Base64.Encode(str, str.GetLength()); // 不能使用sizeof()获取长度
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(b64encode_str);
}

void EnDecoder::OnBnClickedButtonb64decode()
{
	// TODO:  在此添加控件通知处理程序代码
	CString str;
	CString b64decode_str;
	Base64 _Base64;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str);
	b64decode_str = _Base64.Decode(str, str.GetLength());
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(b64decode_str);
}


//// 由于Base16、 Base32的实现较为复杂，借用python实现算法   经一整天的修bug之后，我认输
//
//
//void EnDecoder::OnBnClickedButtonb32encode()
//{
//	// TODO:  在此添加控件通知处理程序代码
//	Py_SetPythonHome(PY_modePath); //内嵌python虚拟机的出时python环境
//	Py_Initialize();//使用python之前，要调用Py_Initialize();这个函数进行初始化
//
//	PyRun_SimpleString("import sys");
//	PyRun_SimpleString("sys.path.append("./")");//这一步很重要，修改Python路径
//
//	PyObject * pModule = NULL;//声明变量
//	PyObject * pFunc = NULL;// 声明变量
//	CString str = "";
//	//CString t = "";
//	//GetDlgItem(IDC_EDIT_Output)->SetWindowText(t); //如果有值则清空
//	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str); //获取编辑栏中的值
//
//	pModule = PyImport_ImportModule("basecode");//这里是要调用的文件名basecode.py
//	PyRun_SimpleString("import base64"); //导入模块
//	char * funcname = "b32e";
//	pFunc = PyObject_GetAttrString(pModule,"b32e");//这里是要调用的函数名
//	
//	char * strs = "";
//	strs = T2A((LPTSTR)(LPCTSTR)str);
//	// strcpy_s(strs,sizeof(str),T2A((LPTSTR)(LPCTSTR)str)); //实现CString 转换为 char* 
//	PyObject* args = Py_BuildValue("s",strs); //绑定参数
//	PyObject* pRet = PyObject_CallObject(pFunc, args); //调用函数并传参
//	char res;
//	PyArg_ParseTuple(pRet,"s",&res);
//	//PyArg_Parse(pRet, "s", *res);//转换返回类型
//
//	//int PyArg_Parse(PyObject *args, const char *format, ...)¶
//	//	函数被用来析构“旧类型”函数的参数列表——这些函数使用的 METH_OLDARGS 参数解析方法已从Python 3中移除。这不被推荐用于新代码的参数解析，并且在标准解释器中的大多数代码已被修改，已不再用于该目的。它仍然方便于分解其他元组，然而可能因为这个目的被继续使用。
//
//
//	//CString encode_str(res); // char*转CString
//	CString b32encode_str = "";
//	b32encode_str.Format("%s", res);
//	GetDlgItem(IDC_EDIT_Output)->SetWindowText(b32encode_str);
//	Py_DECREF(pModule);
//	Py_DECREF(pFunc);
//	Py_DECREF(args);
//	Py_DECREF(pRet);
//
//	Py_Finalize(); // 与初始化对应
//
//}
////$(LibraryPath);
//
//
//void EnDecoder::OnBnClickedButtonb32decode()
//{
//	// TODO:  在此添加控件通知处理程序代码
//	Py_Initialize();   // 初始化
//
//	PyRun_SimpleString("print "hello"");
//
//	Py_Finalize();
//
//}
CString UTF8_Unicode::UTF8AndUnicode_Convert(CString &strSource, UINT nSourceCodePage, UINT nTargetCodePage)
{
	CString        strTarget;

	wchar_t        *pWideBuf;
	int            nWideBufLen;

	char           *pMultiBuf;
	int            nMiltiBufLen;

	int            nSourceLen;

	nSourceLen = strSource.GetLength();
	nWideBufLen = MultiByteToWideChar(nSourceCodePage, 0, strSource, -1, NULL, 0);

	pWideBuf = new wchar_t[nWideBufLen + 1];
	memset(pWideBuf, 0, (nWideBufLen + 1) * sizeof(wchar_t));

	MultiByteToWideChar(nSourceCodePage, 0, strSource, -1, (LPWSTR)pWideBuf, nWideBufLen);

	pMultiBuf = NULL;
	nMiltiBufLen = WideCharToMultiByte(nTargetCodePage, 0, (LPWSTR)pWideBuf, -1, (char *)pMultiBuf, 0, NULL, NULL);

	pMultiBuf = new char[nMiltiBufLen + 1];
	memset(pMultiBuf, 0, nMiltiBufLen + 1);

	WideCharToMultiByte(nTargetCodePage, 0, (LPWSTR)pWideBuf, -1, (char *)pMultiBuf, nMiltiBufLen, NULL, NULL);

	strTarget.Format(_T("%s"), pMultiBuf);

	delete pWideBuf;
	delete pMultiBuf;

	return strTarget;
}



CString URLendecoder::URLEncoding(CString strMsg)
{
	//unsigned char *pchInData = new unsigned char[strMsg.GetLength() + 100]; //默认输入位数为100，多的会被截断
	//memset(pchInData, 0, strMsg.GetLength() + 100);

	char *pchInData;
	pchInData = (char*)strMsg.GetBuffer(strMsg.GetLength());  //无位数限制，直接将CString转为char*

	CString strResult;
	for (int i = 0; i <= strlen(pchInData); i++)
	{
		if (pchInData[i] >= 'a' && pchInData[i] <= 'z'){
			char chOut = pchInData[i];
			strResult += chOut;
		}
		else if (pchInData[i] >= 'A' && pchInData[i] <= 'Z')
		{
			char chOut = pchInData[i];
			strResult += chOut;
		}
		else if (pchInData[i] >= '0' && pchInData[i] <= '9')
		{
			char chOut = pchInData[i];
			strResult += chOut;
		}
		else
		{
			strResult += "%";
			CString strTT;
			strTT.Format("%02X", pchInData[i]);
			strResult += strTT;
		}
	}
		//delete[] pchInData;
		return strResult;

}

int DeCodeHex(char chr)
{
	if (chr < 'A') return chr - '0';
	if (chr > 'F') return chr - 'a' + 10;
	return chr - 'A' + 10;
}
CString URLendecoder::URLDecoding(CString strSmsContent)
{

	CString sOut;
	const int nLen = strSmsContent.GetLength() + 1;
	register LPBYTE pOutTmp = NULL;
	register LPBYTE pInTmp = NULL;
	LPBYTE pInBuf = (LPBYTE)strSmsContent.GetBuffer(nLen);
	BYTE * pTOutchar = new BYTE[nLen];
	memset(pTOutchar, 0, nLen);
	BYTE b = 0;
	if (pTOutchar)
	{
		pInTmp = pInBuf;
		pOutTmp = pTOutchar;
		while (*pInTmp)
		{
			if (*pInTmp == '%')
			{
				pInTmp++;
				BYTE tB = DeCodeHex(*pInTmp++) << 4;
				tB += DeCodeHex(*pInTmp++);
				*pOutTmp++ = tB;
			}
			else if (*pInTmp == '+')
			{
				*pOutTmp++ = ' ';
				pInTmp++;
			}
			else
			{
				*pOutTmp++ = *pInTmp;
				pInTmp++;
			}
		}
		*pOutTmp = '\0';
	}
	strSmsContent.ReleaseBuffer();
	sOut = pTOutchar;
	delete[] pTOutchar;
	return sOut;
}




BOOL EnDecoder::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  在此添加额外的初始化

	return TRUE;  // return TRUE unless you set the focus to a control
	// 异常:  OCX 属性页应返回 FALSE
}


void EnDecoder::OnBnClickedButtonutf82unicode()
{
	// TODO:  在此添加控件通知处理程序代码
	CString str,_str;
	UTF8_Unicode _UTF8_Unicode;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str);
	_str = _UTF8_Unicode.UTF8AndUnicode_Convert(str, CP_UTF8, CP_ACP);
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(_str);
}


void EnDecoder::OnBnClickedButtonunicode2utf8()
{
	CString str, _str;
	UTF8_Unicode _UTF8_Unicode;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str);
	_str = _UTF8_Unicode.UTF8AndUnicode_Convert(str, CP_ACP, CP_UTF8);
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(_str);
}



void EnDecoder::OnBnClickedButtonUrlencode2()
{
	// TODO:  在此添加控件通知处理程序代码
	CString str = "", URLencode_str = "";
	URLendecoder URLencoder;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str);
	URLencode_str = URLencoder.URLEncoding(str);
	URLencode_str.Replace("%00"," ");
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(URLencode_str);

}


void EnDecoder::OnBnClickedButtonUrldecode()
{
	// TODO:  在此添加控件通知处理程序代码
	CString str, URLdecode_str;
	URLendecoder URLencoder;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str);
	URLdecode_str = URLencoder.URLDecoding(str);
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(URLdecode_str);
}



void HEX_CHAR::char_2_Hex(char* Char, char* Hex)
{
	int length = strlen(Char);
	for (int i = 0; i < length; i++)
	{
		int tmp = int(Char[i]);
		if (Char[i] < 0)
			tmp = (-1) * Char[i] + 128;
		int high = tmp / 16;
		int low = tmp % 16;
		char HIHG;
		char LOW;

		if (high >= 10)
			HIHG = char(high - 10 + 65);
		else
			HIHG = char(high + 48);

		if (low >= 10)
			LOW = char(low - 10 + 65);
		else
			LOW = char(low + 48);

		Hex[2 * i] = HIHG;
		Hex[2 * i + 1] = LOW;
	}

}

//16 -> char 
void HEX_CHAR::Hex_2_char(char*Hex, char* Char)
{
	int length = strlen(Hex) / 2;
	for (int i = 0; i < length; i++)
	{
		int high;
		int low;
		if (int(Hex[2 * i]) >= 65)
			high = int(Hex[2 * i] - 65 + 10);
		else
			high = int(Hex[2 * i] - 48);

		if (int(Hex[2 * i + 1]) >= 65)
			low = int(Hex[2 * i + 1] - 65 + 10);
		else
			low = int(Hex[2 * i + 1] - 48);

		Char[i] = char(high * 16 + low);
	}
}







void EnDecoder::OnBnClickedButtonchar2hex() //char2hex
{
	// TODO:  在此添加控件通知处理程序代码
	CString str,_str;
	char* str_char;
	
	HEX_CHAR hex_char;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str); //
	str_char = (char*)str.GetBuffer(str.GetLength());  //无位数限制，直接将CString转为char*
	char* str_hex = (char*)malloc(strlen(str_char) * sizeof(char));
	strncpy(str_hex, "", strlen(str_hex));
	hex_char.char_2_Hex(str_char, str_hex);
	_str.Format("%s", str_hex);
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(_str);

}

void EnDecoder::OnBnClickedButtonhex2char()
{
	// TODO:  在此添加控件通知处理程序代码
	CString str, _str;
	char* str_hex;
	HEX_CHAR hex_char;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str); //
	str_hex = (char*)str.GetBuffer(str.GetLength());
	char* str_char = (char*)malloc(strlen(str_hex) * sizeof(char));
	strncpy(str_char, "", strlen(str_char));

	hex_char.Hex_2_char(str_hex, str_char);
	_str.Format("%s", str_char);
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(_str);

}

void EnDecoder::OnBnClickedButtonmecding()
{
	// TODO:  在此添加控件通知处理程序代码

	Manchester manchester;
	CString str, _str; 
	string mcststr;
	string binstr;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str);
	binstr = str.GetBuffer(str.GetLength());
	// char* mcststr = (char*)malloc(strlen(binstr) );//* sizeof(char)
	mcststr = manchester.Mcoding(binstr, mcststr);
	_str = mcststr.c_str();
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(_str);

}


void EnDecoder::OnBnClickedButtoncmcoding()
{
	// TODO:  在此添加控件通知处理程序代码
	Manchester manchester;
	CString str, _str;
	string mcststr;
	char *  binstr;
	GetDlgItem(IDC_EDIT_Input)->GetWindowText(str);
	binstr = str.GetBuffer(str.GetLength());
	// char* mcststr = (char*)malloc(strlen(binstr) );//* sizeof(char)
	mcststr = manchester.CMcoding(binstr, mcststr);
	_str = mcststr.c_str();
	GetDlgItem(IDC_EDIT_Output)->SetWindowText(_str);

}



//曼彻斯特

string Manchester::Mcoding(string num, string res) {
	int len = num.length();
	string lh = "_-";
	string hl = "-_";
	for (int i = 0; i < len; i++) {
		if (num.substr(i,1) == "0") {
			res += lh;
		}
		else {
			res += hl;
		}
	}
	return res;
}

//差分曼彻斯特
string Manchester::CMcoding(char * num, string res) {
	 
	int len = strlen(num);
	string blank = " ";
	char ans[100];
	if (num[0] == '1') {
		ans[0] = '-', ans[1] = '_';
	}
	else {
		ans[0] = '_', ans[1] = '-';
	}
	for (int i = 1, j = 0; i < len; i++) {
		j = 2 * i; //记录下标的
		if (num[i] == '0') {
			//当前位置0
			if (num[i - 1] == '1') {
				//前一位置是1
				ans[j] = ans[j - 2];
				ans[j + 1] = ans[j - 1];
			}
			else {
				//前一位置是0
				ans[j] = ans[j - 2];
				ans[j + 1] = ans[j - 1];
			}
		}
		else {
			// 当前位置是1
			if (num[i - 1] == '1') {
				// 前一位置是1
				ans[j] = ans[j - 1];
				ans[j + 1] = ans[j - 2];
			}
			else {
				// 前一位置是0
				ans[j] = ans[j - 1];
				ans[j + 1] = ans[j - 2];
			}
		}
	}
	// char ans[2*len];
	for (int i = 0; i < len * 2; i++) {
		if (i && i % 2 == 0) { res+=blank; };
		res += ans[i];
	}
	return res;
}






