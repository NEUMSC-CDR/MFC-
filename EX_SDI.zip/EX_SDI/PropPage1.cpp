// PropPage1.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EX_SDI.h"
#include "PropPage1.h"
#include "afxdialogex.h"


// CPropPage1 �Ի���

IMPLEMENT_DYNAMIC(CPropPage1, CPropertyPage)

CPropPage1::CPropPage1()
	: CPropertyPage(CPropPage1::IDD)
{

	m_nOccupation = 0;
}

CPropPage1::~CPropPage1()
{
}

void CPropPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPropPage1, CPropertyPage)
END_MESSAGE_MAP()


// CPropPage1 ��Ϣ��������
