#pragma once


// CDlgBtnCreate �Ի���

class CDlgBtnCreate : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgBtnCreate)

public:
	CDlgBtnCreate(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgBtnCreate();

// �Ի�������
	enum { IDD = IDD_DIALOG3 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
private:
	CButton m_btnMine;
public:
	afx_msg void OnBnClickedButton1();
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
};
