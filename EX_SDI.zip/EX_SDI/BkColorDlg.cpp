// BkColorDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EX_SDI.h"
#include "BkColorDlg.h"
#include "afxdialogex.h"


// CBkColorDlg �Ի���

IMPLEMENT_DYNAMIC(CBkColorDlg, CDialogEx)

CBkColorDlg::CBkColorDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CBkColorDlg::IDD, pParent)
	, m_nGreen(0)
	, m_nBlue(0)
{

}

CBkColorDlg::~CBkColorDlg()
{
}

void CBkColorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Slider(pDX, IDC_SLIDER_GREEN, m_nGreen);
	DDX_Control(pDX, IDC_SLIDER_GREEN, m_sliderGreen);
	DDX_Control(pDX, IDC_SCROLLBAR_RED, m_scrollRed);
	DDX_Control(pDX, IDC_SLIDER_BLUE, m_sliderBlue);
	DDX_Slider(pDX, IDC_SLIDER_BLUE, m_nBlue);
}


BEGIN_MESSAGE_MAP(CBkColorDlg, CDialogEx)
	ON_WM_HSCROLL()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CBkColorDlg ��Ϣ��������


BOOL CBkColorDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	m_scrollRed.SetScrollRange(0, 255);
	m_sliderBlue.SetRange(0, 255);
	m_sliderGreen.SetRange(0, 255);
	m_nBlue = m_nGreen = m_nRedValue = 192;
	UpdateData(FALSE);
	m_scrollRed.SetScrollPos(m_nRedValue);
	return TRUE;

}


void CBkColorDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	int nID = pScrollBar->GetDlgCtrlID();
	if (nID == IDC_SCROLLBAR_RED)
	{
		switch (nSBCode)
		{
		case SB_LINELEFT: m_nRedValue--;
			break;
		case SB_LINERIGHT: m_nRedValue++;
			break;
		case SB_PAGELEFT: m_nRedValue -= 10;
			break;
		case SB_PAGERIGHT: m_nRedValue += 10;
			break;
		case SB_THUMBTRACK: m_nRedValue = nPos;
			break;
		}//end switch
		if (m_nRedValue<0) m_nRedValue = 0;
		if (m_nRedValue>255) m_nRedValue = 255;
		m_scrollRed.SetScrollPos(m_nRedValue);
	}//end if
	Invalidate();		// repaint the dialog
	CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);


}


HBRUSH CBkColorDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	UpdateData(TRUE);
	COLORREF color = RGB(m_nRedValue, m_nGreen, m_nBlue);
	m_Brush.Detach();
	m_Brush.CreateSolidBrush(color);
	pDC->SetBkColor(color);
	return (HBRUSH)m_Brush;
}
