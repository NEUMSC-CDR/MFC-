#pragma once
#include "afxwin.h"


// CFirstDlg �Ի���

class CFirstDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CFirstDlg)

public:
	CFirstDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CFirstDlg();

// �Ի�������
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CButton m_RelBtn; //ӳ��Ϊ�ؼ�Buuton1
	CString m_strEdit;
	afx_msg void OnBnClickedButton1();
};



