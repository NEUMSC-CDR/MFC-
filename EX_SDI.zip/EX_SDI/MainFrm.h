
// MainFrm.h : CMainFrame ��Ľӿ�
//

#pragma once

class CMainFrame : public CFrameWnd
{
	
protected: // �������л�����
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// ����
public:

// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// ʵ��
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // �ؼ���Ƕ���Ա
	CStatusBar        m_wndStatusBar;

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP();

public:
	afx_msg void OnMODALDlg();
	afx_msg void OnModalessDlg();
	afx_msg void OnFileDlg();
	afx_msg void OnBtnCreate();
	afx_msg void OnCtlNet();
	afx_msg void OnCtlColor();
	afx_msg void OnCtlStudentList();
	afx_msg void OnCommandTest();
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	afx_msg void OnUpdateMenuCheck(CCmdUI *pCmdUI);
private:
	BOOL m_bTag;
	CBitmap m_bitmap;
	CMenu menu;
	CStatic *p_MyStatic;

public:
	afx_msg void OnMenuCheck();
	afx_msg void OnUpdateMenuDefault(CCmdUI *pCmdUI);
	afx_msg void OnUpdateMenuPic(CCmdUI *pCmdUI);
	afx_msg void OnMenuTools();
	afx_msg void OnMenuReturn();
	afx_msg void OnToolsendecoder();
	afx_msg void OnToolsendecryption();
};




