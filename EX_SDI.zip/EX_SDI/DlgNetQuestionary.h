#pragma once


// CDlgNetQuestionary �Ի���

class CDlgNetQuestionary : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgNetQuestionary)

public:
	CDlgNetQuestionary(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgNetQuestionary();

// �Ի�������
	enum { IDD = IDD_NET_QUESTIONARY };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
};
