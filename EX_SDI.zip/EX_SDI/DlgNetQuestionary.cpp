// DlgNetQuestionary.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EX_SDI.h"
#include "DlgNetQuestionary.h"
#include "afxdialogex.h"
#include "DlgNetQuestionary.h"


// CDlgNetQuestionary �Ի���

IMPLEMENT_DYNAMIC(CDlgNetQuestionary, CDialogEx)

CDlgNetQuestionary::CDlgNetQuestionary(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgNetQuestionary::IDD, pParent)
{

}

CDlgNetQuestionary::~CDlgNetQuestionary()
{
}

void CDlgNetQuestionary::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgNetQuestionary, CDialogEx)
	ON_BN_CLICKED(IDOK, &CDlgNetQuestionary::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgNetQuestionary ��Ϣ��������


BOOL CDlgNetQuestionary::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CheckRadioButton(IDC_AGE_L18, IDC_AGE_M38, IDC_AGE_18T27);
	CheckRadioButton(IDC_CM_FTTL, IDC_CM_OTHER, IDC_CM_FTTL);
	CButton* pBtn = (CButton*)GetDlgItem(IDC_DO_POP);
	pBtn->SetCheck(1);
	return TRUE;
}



void CDlgNetQuestionary::OnBnClickedOk()
{
	CString str, strCtrl;
	str = "������䣺";
	UINT nID = GetCheckedRadioButton(IDC_AGE_L18,
		IDC_AGE_M38);
	GetDlgItemText(nID, strCtrl);
	str = str + strCtrl;
	str = str + "\n��ʹ�õĽ��뷽ʽ��";
	nID = GetCheckedRadioButton(IDC_CM_FTTL,
		IDC_CM_OTHER);
	GetDlgItemText(nID, strCtrl);
	str = str + strCtrl;
	str = str + "\n��������Ҫ�ǣ�\n";
	UINT nCheckIDs[4] = { IDC_DO_POP, IDC_DO_NEWS,
		IDC_DO_GAME, IDC_DO_OTHER };
	CButton* pBtn;
	for (int i = 0; i<4; i++)
	{
		pBtn = (CButton*)GetDlgItem(nCheckIDs[i]);
		if (pBtn->GetCheck())
		{
			pBtn->GetWindowText(strCtrl);
			str = str + strCtrl;
			str = str + "  ";
		}
	}
	MessageBox(str);
	CDialog::OnOK();

}
