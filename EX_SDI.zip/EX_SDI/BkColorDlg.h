#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CBkColorDlg �Ի���

class CBkColorDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CBkColorDlg)

public:
	CBkColorDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBkColorDlg();

// �Ի�������
	enum { IDD = IDD_COLOR };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	int m_nGreen;
	CSliderCtrl m_sliderGreen;
	CScrollBar m_scrollRed;
	CSliderCtrl m_sliderBlue;
	int m_nBlue;
private:
	int         m_nRedValue;
	CBrush m_Brush;
public:
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};


