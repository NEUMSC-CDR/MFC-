#pragma once
// #define  PY_modePath L"E:\\Ӧ��\\�칫����\\Python" ������python�������·����ʼ��

// EnDecoder �Ի���
#include "String"
using namespace std;
class EnDecoder : public CDialogEx
{
	DECLARE_DYNAMIC(EnDecoder)

public:
	EnDecoder(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~EnDecoder();

// �Ի�������
	enum { IDD = IDD_DIALOG4 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonb64encode();
	afx_msg void OnBnClickedButtonb64decode();
	//afx_msg void OnBnClickedButtonb32encode();
	//afx_msg void OnBnClickedButtonb32decode();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonutf82unicode();
	afx_msg void OnBnClickedButtonunicode2utf8();
	afx_msg void OnBnClickedButtonUrlencode2();
	afx_msg void OnBnClickedButtonUrldecode();
	afx_msg void OnBnClickedButtonchar2hex();
	afx_msg void OnBnClickedButtonhex2char();
	afx_msg void OnBnClickedButtonmecding();
	afx_msg void OnBnClickedButtoncmcoding();
};

/**
* Base64 ����/����
*/
class Base64{
	//	static const char base64_pad = '='; 
public:

	CString Encode(CString src, int bytes);
	CString Decode(CString src, int bytes);
	void Debug(bool open = true);
};
class UTF8_Unicode{
public :
	CString UTF8AndUnicode_Convert(CString &strSource, UINT nSourceCodePage, UINT nTargetCodePage);

};

class URLendecoder{
public:
	CString URLEncoding(CString str);
	CString URLDecoding(CString str);
};

class HEX_CHAR{

public:
	void char_2_Hex(char* Char, char* Hex);
	void Hex_2_char(char* Hex, char* Char);
};


class Manchester{
public:

	string Mcoding(string num, string res);
	string CMcoding(char *  num, string res);
};