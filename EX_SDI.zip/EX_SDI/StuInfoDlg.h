#pragma once
#include "atltime.h"
#include "afxwin.h"


// CStuInfoDlg �Ի���

class CStuInfoDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CStuInfoDlg)

public:
	CStuInfoDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CStuInfoDlg();

// �Ի�������
	enum { IDD = IDD_STUINFO };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:

	CString m_strName;
	CString m_strNo;
	CTime m_tBirth;
	CComboBox m_comboSpecial;
	CString m_strSpecial;
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
};
