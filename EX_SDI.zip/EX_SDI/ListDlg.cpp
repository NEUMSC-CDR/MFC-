// ListDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EX_SDI.h"
#include "ListDlg.h"
#include "afxdialogex.h"
#include "StuInfoDlg.h"


// CListDlg �Ի���

IMPLEMENT_DYNAMIC(CListDlg, CDialogEx)

CListDlg::CListDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CListDlg::IDD, pParent)
{

}

CListDlg::~CListDlg()
{
}

void CListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_ListCtrl);
}


BEGIN_MESSAGE_MAP(CListDlg, CDialogEx)
	ON_BN_CLICKED(IDC_RADIO_LARGE, &CListDlg::OnBnClickedRadioLarge)
	ON_BN_CLICKED(IDC_RADIO_SMALL, &CListDlg::OnBnClickedRadioSmall)
	ON_BN_CLICKED(IDC_RADIO_LIST, &CListDlg::OnBnClickedRadioList)
	ON_BN_CLICKED(IDC_RADIO_REPORT, &CListDlg::OnBnClickedRadioReport)
	ON_BN_CLICKED(IDC_BUTTON_ADD, &CListDlg::OnBnClickedButtonAdd)
END_MESSAGE_MAP()


// CListDlg ��Ϣ��������


BOOL CListDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	CheckRadioButton(IDC_RADIO_LARGE, IDC_RADIO_REPORT, IDC_RADIO_REPORT);
	SetCtrlStyle(m_ListCtrl.m_hWnd, LVS_REPORT);
	CImageList* pImageList;
	pImageList = new CImageList();
	pImageList->Create(32, 32, ILC_COLOR, 0, 1);
	pImageList->Add(AfxGetApp()->
		LoadIcon(IDI_ICON1));//show icon
	m_ListCtrl.SetImageList(pImageList,
		LVSIL_NORMAL);
	CString strHeader[5] = { "ѧ��", "����",
		"��������", "רҵ" };
	int nWidth[4] = { 80, 100, 100, 200 };
	for (int nCol = 0; nCol<4; nCol++)
		m_ListCtrl.InsertColumn(nCol, strHeader[nCol], LVCFMT_LEFT, nWidth[nCol]);
	return TRUE;
	
}

void CListDlg::SetCtrlStyle(HWND hWnd, DWORD dwNewStyle)
{
	DWORD	dwOldStyle;
	dwOldStyle = GetWindowLong(hWnd, GWL_STYLE);
	if ((dwOldStyle&LVS_TYPEMASK) != dwNewStyle)
	{
		dwOldStyle &= ~LVS_TYPEMASK;
		dwNewStyle |= dwOldStyle;
		SetWindowLong(hWnd, GWL_STYLE, dwNewStyle);
	}
}




void CListDlg::OnBnClickedRadioLarge()
{
	SetCtrlStyle(m_ListCtrl.m_hWnd, LVS_ICON);
}



void CListDlg::OnBnClickedRadioSmall()
{
	SetCtrlStyle(m_ListCtrl.m_hWnd, LVS_SMALLICON);
}



void CListDlg::OnBnClickedRadioList()
{
	SetCtrlStyle(m_ListCtrl.m_hWnd, LVS_LIST);

}


void CListDlg::OnBnClickedRadioReport()
{
	SetCtrlStyle(m_ListCtrl.m_hWnd, LVS_REPORT);
}


void CListDlg::OnBnClickedButtonAdd()
{
	CStuInfoDlg dlg;
	if (IDOK != dlg.DoModal())
		return;
	LVFINDINFO info;
	info.flags = LVFI_PARTIAL | LVFI_STRING;
	info.psz = dlg.m_strNo;
	if (m_ListCtrl.FindItem(&info) != -1)
	{
		CString str;
		str.Format("ѧ��Ϊ%s��ѧ��������Ϣ�����ӹ���", dlg.m_strNo);
		MessageBox(str);
		return;

	}
	// add student information
	int nIndex =
		m_ListCtrl.InsertItem(m_ListCtrl.GetItemCount(), dlg.m_strNo);
	m_ListCtrl.SetItemText(nIndex, 1, dlg.m_strName);
	m_ListCtrl.SetItemText(nIndex, 2,
		dlg.m_tBirth.Format("%Y-%m-%d"));
	m_ListCtrl.SetItemText(nIndex, 3, dlg.m_strSpecial);


}
