// EnDecryption.cpp : ʵ���ļ�
#include "stdafx.h"
#include "EX_SDI.h"
#include "EnDecryption.h"
#include "afxdialogex.h"
#include "String"
using namespace std;

// EnDecryption �Ի���

IMPLEMENT_DYNAMIC(EnDecryption, CDialogEx)

EnDecryption::EnDecryption(CWnd* pParent /*=NULL*/)
	: CDialogEx(EnDecryption::IDD, pParent)
{

}

EnDecryption::~EnDecryption()
{
}

void EnDecryption::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(EnDecryption, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &EnDecryption::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON3, &EnDecryption::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &EnDecryption::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &EnDecryption::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON7, &EnDecryption::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON_RC4, &EnDecryption::OnBnClickedButtonRc4)
	ON_BN_CLICKED(IDC_BUTTON_crc32, &EnDecryption::OnBnClickedButtoncrc32)
	ON_BN_CLICKED(IDC_BUTTON_caser, &EnDecryption::OnBnClickedButtoncaser)
END_MESSAGE_MAP()


// permuted choice table (PC1)
const static char PC1_Table[56] = {
	57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18,
	10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36,
	63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22,
	14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20, 12, 4
};
// permuted choice key (PC2)
const static char PC2_Table[48] = {
	14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10,
	23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2,
	41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48,
	44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32
};
// number left rotations of pc1 
const static char Shift_Table[16] = {
	1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1
};
// initial permutation (IP)
const static char IP_Table[64] = {
	58, 50, 42, 34, 26, 18, 10, 2, 60, 52, 44, 36, 28, 20, 12, 4,
	62, 54, 46, 38, 30, 22, 14, 6, 64, 56, 48, 40, 32, 24, 16, 8,
	57, 49, 41, 33, 25, 17, 9, 1, 59, 51, 43, 35, 27, 19, 11, 3,
	61, 53, 45, 37, 29, 21, 13, 5, 63, 55, 47, 39, 31, 23, 15, 7
};
// expansion operation matrix (E)
const static char E_Table[48] = {
	32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9,
	8, 9, 10, 11, 12, 13, 12, 13, 14, 15, 16, 17,
	16, 17, 18, 19, 20, 21, 20, 21, 22, 23, 24, 25,
	24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1
};
// The (in)famous S-boxes 
const static char S_Box[8][4][16] = {
	// S1
	14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7,
	0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8,
	4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0,
	15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13,
	// S2 
	15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10,
	3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5,
	0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15,
	13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9,
	// S3 
	10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8,
	13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1,
	13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7,
	1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12,
	// S4 
	7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15,
	13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9,
	10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4,
	3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14,
	// S5 
	2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9,
	14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6,
	4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14,
	11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3,
	// S6 
	12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11,
	10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8,
	9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6,
	4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13,
	// S7 
	4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1,
	13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6,
	1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2,
	6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12,
	// S8 
	13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7,
	1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2,
	7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8,
	2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11
};
// 32-bit permutation function P used on the output of the S-boxes 
const static char P_Table[32] = {
	16, 7, 20, 21, 29, 12, 28, 17, 1, 15, 23, 26, 5, 18, 31, 10,
	2, 8, 24, 14, 32, 27, 3, 9, 19, 13, 30, 6, 22, 11, 4, 25
};
// final permutation IP^-1 
const static char IPR_Table[64] = {
	40, 8, 48, 16, 56, 24, 64, 32, 39, 7, 47, 15, 55, 23, 63, 31,
	38, 6, 46, 14, 54, 22, 62, 30, 37, 5, 45, 13, 53, 21, 61, 29,
	36, 4, 44, 12, 52, 20, 60, 28, 35, 3, 43, 11, 51, 19, 59, 27,
	34, 2, 42, 10, 50, 18, 58, 26, 33, 1, 41, 9, 49, 17, 57, 25
};


// DES�㷨����

EnDedes::EnDedes()
{
	memset(szCiphertextRaw, 0, 64);
	memset(szPlaintextRaw, 0, 64);
	memset(szCiphertextInBytes, 0, 8);
	memset(szPlaintextInBytes, 0, 8);
	memset(szCiphertextInBinary, 0, 65);
	memset(szCiphertextInHex, 0, 17);
	memset(szPlaintext, 0, 9);
	memset(szFCiphertextAnyLength, 0, 8192);
	memset(szCiphertextInHex, 0, 8192);
}
EnDedes::~EnDedes()
{
}

void EnDedes::InitializeKey(char* srcBytes, unsigned int keyN)
{
	//convert 8 char-bytes key to 64 binary-bits
	char sz_64key[64] = { 0 };
	Bytes2Bits(srcBytes, sz_64key, 64);
	//PC 1
	char sz_56key[56] = { 0 };
	for (int k = 0; k<56; k++)
	{
		sz_56key[k] = sz_64key[PC1_Table[k] - 1];
	}
	CreateSubKey(sz_56key, keyN);
}

void EnDedes::CreateSubKey(char* sz_56key, unsigned int keyN)
{
	char szTmpL[28] = { 0 };
	char szTmpR[28] = { 0 };
	char szCi[28] = { 0 };
	char szDi[28] = { 0 };
	memcpy(szTmpL, sz_56key, 28);
	memcpy(szTmpR, sz_56key + 28, 28);

	for (int i = 0; i<16; i++)
	{
		//shift to left
		//Left 28 bits
		memcpy(szCi, szTmpL + Shift_Table[i], 28 - Shift_Table[i]);
		memcpy(szCi + 28 - Shift_Table[i], szTmpL, Shift_Table[i]);
		//Right 28 bits
		memcpy(szDi, szTmpR + Shift_Table[i], 28 - Shift_Table[i]);
		memcpy(szDi + 28 - Shift_Table[i], szTmpR, Shift_Table[i]);

		//permuted choice 48 bits key
		char szTmp56[56] = { 0 };
		memcpy(szTmp56, szCi, 28);
		memcpy(szTmp56 + 28, szDi, 28);
		for (int j = 0; j<48; j++)
		{
			szSubKeys[keyN][i][j] = szTmp56[PC2_Table[j] - 1];
		}
		//Evaluate new szTmpL and szTmpR
		memcpy(szTmpL, szCi, 28);
		memcpy(szTmpR, szDi, 28);
	}
}

void EnDedes::EncryptData(char* _srcBytes, unsigned int keyN)
{
	char szSrcBits[64] = { 0 };
	char sz_IP[64] = { 0 };
	char sz_Li[32] = { 0 };
	char sz_Ri[32] = { 0 };
	char sz_Final64[64] = { 0 };

	Bytes2Bits(_srcBytes, szSrcBits, 64);
	//IP
	InitialPermuteData(szSrcBits, sz_IP);
	memcpy(sz_Li, sz_IP, 32);
	memcpy(sz_Ri, sz_IP + 32, 32);

	for (int i = 0; i<16; i++)
	{
		FunctionF(sz_Li, sz_Ri, i, keyN);
	}
	//so D=LR

	memcpy(sz_Final64, sz_Ri, 32);
	memcpy(sz_Final64 + 32, sz_Li, 32);

	//~IP
	for (int j = 0; j<64; j++)
	{
		szCiphertextRaw[j] = sz_Final64[IPR_Table[j] - 1];
	}
	Bits2Bytes(szCiphertextInBytes, szCiphertextRaw, 64);
}

void EnDedes::DecryptData(char* _srcBytes, unsigned int keyN)
{
	char szSrcBits[64] = { 0 };
	char sz_IP[64] = { 0 };
	char sz_Li[32] = { 0 };
	char sz_Ri[32] = { 0 };
	char sz_Final64[64] = { 0 };
	Bytes2Bits(_srcBytes, szSrcBits, 64);
	//IP --- return is sz_IP
	InitialPermuteData(szSrcBits, sz_IP);
	//divide the 64 bits data to two parts
	memcpy(sz_Ri, sz_IP, 32); //exchange L to R
	memcpy(sz_Li, sz_IP + 32, 32);  //exchange R to L
	//16 rounds F and xor and exchange
	for (int i = 0; i<16; i++)
	{
		FunctionF(sz_Ri, sz_Li, 15 - i, keyN);
	}
	memcpy(sz_Final64, sz_Li, 32);
	memcpy(sz_Final64 + 32, sz_Ri, 32);
	// ~IP
	for (int j = 0; j<64; j++)
	{
		szPlaintextRaw[j] = sz_Final64[IPR_Table[j] - 1];
	}
	Bits2Bytes(szPlaintextInBytes, szPlaintextRaw, 64);
}

void EnDedes::FunctionF(char* sz_Li, char* sz_Ri, unsigned int iKey, unsigned int keyN)
{
	char sz_48R[48] = { 0 };
	char sz_xor48[48] = { 0 };
	char sz_P32[32] = { 0 };
	char sz_Rii[32] = { 0 };
	char sz_Key[48] = { 0 };
	char s_Compress32[32] = { 0 };
	memcpy(sz_Key, szSubKeys[keyN][iKey], 48);
	ExpansionR(sz_Ri, sz_48R);
	XOR(sz_48R, sz_Key, 48, sz_xor48);

	CompressFuncS(sz_xor48, s_Compress32);
	PermutationP(s_Compress32, sz_P32);
	XOR(sz_P32, sz_Li, 32, sz_Rii);
	memcpy(sz_Li, sz_Ri, 32);
	memcpy(sz_Ri, sz_Rii, 32);
}

void EnDedes::InitialPermuteData(char* _src, char* _dst)
{
	//IP
	for (int i = 0; i<64; i++)
	{
		_dst[i] = _src[IP_Table[i] - 1];
	}
}

void EnDedes::ExpansionR(char* _src, char* _dst)
{
	for (int i = 0; i<48; i++)
	{
		_dst[i] = _src[E_Table[i] - 1];
	}
}

void EnDedes::XOR(char* szParam1, char* szParam2, unsigned int uiParamLength, char* szReturnValueBuffer)
{
	for (unsigned int i = 0; i<uiParamLength; i++)
	{
		szReturnValueBuffer[i] = szParam1[i] ^ szParam2[i];
	}
}
CString EnDedes::DESr(CString strPlaintext, CString strKey)
{
	CString strCiphertext;
	memset(szSourceKey1, 0, 8);
	memset(szSourceKey2, 0, 8);
	memset(szPlaintextData, 0, 8192);
	memcpy(szSourceKey1, strKey.GetBuffer(), strKey.GetLength() < 8 ? strKey.GetLength() : 8);
	InitializeKey(szSourceKey1, 0);
	memcpy(szPlaintextData, strPlaintext.GetBuffer(), strPlaintext.GetLength());
	EncryptAnyLength(szPlaintextData, strlen(szPlaintextData), 0);
	ConvertCiphertext2OtherFormat(strlen(szPlaintextData) % 8 == 0 ? strlen(szPlaintextData) << 3 : ((strlen(szPlaintextData) >> 3) + 1) << 6, GetCiphertextAnyLength());
	return hexCiphertextAnyLength;
}
CString EnDedes::DESw(CString strCiphertext, CString strKey)
{
	memset(szSourceKey1, 0, 8);
	memset(szSourceKey2, 0, 8);
	memset(szCiphertextData, 0, 8192);
	memcpy(szSourceKey1, strKey.GetBuffer(), strKey.GetLength() < 8 ? strKey.GetLength() : 8);
	InitializeKey(szSourceKey1, 0);
	DecryptAnyLength(szCiphertextData, ConvertOtherFormat2Ciphertext(strCiphertext.GetBuffer()), 0);
	return GetPlaintextAnyLength();
}
CString EnDedes::DESr(CString strPlaintext, CString strKey, CString strKeyTDES)
{
	CString strCiphertext;
	memset(szSourceKey1, 0, 8);
	memset(szSourceKey2, 0, 8);
	memset(szPlaintextData, 0, 8192);
	memcpy(szSourceKey1, strKey.GetBuffer(), strKey.GetLength() < 8 ? strKey.GetLength() : 8);
	memcpy(szSourceKey2, strKeyTDES.GetBuffer(), strKeyTDES.GetLength() < 8 ? strKeyTDES.GetLength() : 8);
	InitializeKey(szSourceKey1, 0);
	memcpy(szPlaintextData, strPlaintext.GetBuffer(), strPlaintext.GetLength());
	InitializeKey(szSourceKey2, 1); //use key2
	//E(key0)-D(key1)-E(key0)
	EncryptAnyLength(szPlaintextData, strlen(szPlaintextData), 0);
	DecryptAnyLength(GetCiphertextAnyLength(), strlen(GetCiphertextAnyLength()), 1);
	EncryptAnyLength(GetPlaintextAnyLength(), strlen(GetPlaintextAnyLength()), 0);
	ConvertCiphertext2OtherFormat(strlen(szPlaintextData) % 8 == 0 ? strlen(szPlaintextData) << 3 : ((strlen(szPlaintextData) >> 3) + 1) << 6, GetCiphertextAnyLength());
	return hexCiphertextAnyLength;
}
CString EnDedes::DESw(CString strCiphertext, CString strKey, CString strKeyTDES)
{
	memset(szSourceKey1, 0, 8);
	memset(szSourceKey2, 0, 8);
	memset(szCiphertextData, 0, 8192);
	memcpy(szSourceKey1, strKey.GetBuffer(), strKey.GetLength() < 8 ? strKey.GetLength() : 8);
	memcpy(szSourceKey2, strKeyTDES.GetBuffer(), strKeyTDES.GetLength() < 8 ? strKeyTDES.GetLength() : 8);
	InitializeKey(szSourceKey1, 0);
	InitializeKey(szSourceKey2, 1); //key2
	//D(key0)-E(key1)-D(key0)
	DecryptAnyLength(szCiphertextData, ConvertOtherFormat2Ciphertext(strCiphertext.GetBuffer()), 0);
	EncryptAnyLength(GetPlaintextAnyLength(), strlen(GetPlaintextAnyLength()), 1);
	DecryptAnyLength(GetCiphertextAnyLength(), strlen(GetCiphertextAnyLength()), 0);
	return GetPlaintextAnyLength();
}
void EnDedes::ConvertCiphertext2OtherFormat(int iBitsLen, char *szCipherInBytes)
{
	memset(hexCiphertextAnyLength, 0, 16384);
	memset(bitsCiphertextAnyLength, 0, 32768);
	Bytes2Bits(szCipherInBytes, bitsCiphertextAnyLength, iBitsLen);
	Bits2Hex(hexCiphertextAnyLength, bitsCiphertextAnyLength, iBitsLen);
	for (int i = 0; i<iBitsLen; i++)
	{
		bitsCiphertextAnyLength[i] += 48;
	}
}

int EnDedes::ConvertOtherFormat2Ciphertext(char *szCipher)
{
	int iLen = 0;
	memset(szCiphertextData, 0, 8192);
	iLen = ((strlen(szCipher) >> 2) + (strlen(szCipher) % 4 == 0 ? 0 : 1)) << 4;
	memset(hexCiphertextAnyLength, 0, 16384);
	memcpy(hexCiphertextAnyLength, szCipher, strlen(szCipher));
	Hex2Bits(hexCiphertextAnyLength, bitsCiphertextAnyLength, iLen);
	Bits2Bytes(szCiphertextData, bitsCiphertextAnyLength, iLen);
	return iLen >> 3;
}
void EnDedes::CompressFuncS(char* _src48, char* _dst32)
{
	char bTemp[8][6] = { 0 };
	char dstBits[4] = { 0 };
	for (int i = 0; i<8; i++)
	{
		memcpy(bTemp[i], _src48 + i * 6, 6);
		int iX = (bTemp[i][0]) * 2 + (bTemp[i][5]);
		int iY = 0;
		for (int j = 1; j<5; j++)
		{
			iY += bTemp[i][j] << (4 - j);
		}
		Int2Bits(S_Box[i][iX][iY], dstBits);
		memcpy(_dst32 + i * 4, dstBits, 4);
	}

}

void EnDedes::PermutationP(char* _src, char* _dst)
{
	for (int i = 0; i<32; i++)
	{
		_dst[i] = _src[P_Table[i] - 1];
	}
}

void EnDedes::Bytes2Bits(char *srcBytes, char* dstBits, unsigned int sizeBits)
{
	for (unsigned int i = 0; i < sizeBits; i++)
		dstBits[i] = ((srcBytes[i >> 3] << (i & 7)) & 128) >> 7;
}

void EnDedes::Bits2Bytes(char *dstBytes, char* srcBits, unsigned int sizeBits)
{
	memset(dstBytes, 0, sizeBits >> 3);
	for (unsigned int i = 0; i < sizeBits; i++)
		dstBytes[i >> 3] |= (srcBits[i] << (7 - (i & 7)));
}

void EnDedes::Int2Bits(unsigned int _src, char* dstBits)
{
	for (unsigned int i = 0; i < 4; i++)
		dstBits[i] = ((_src << i) & 8) >> 3;
}

void EnDedes::Bits2Hex(char *dstHex, char* srcBits, unsigned int sizeBits)
{
	memset(dstHex, 0, sizeBits >> 2);
	for (unsigned int i = 0; i < sizeBits; i++) //convert to int 0-15
		dstHex[i >> 2] += (srcBits[i] << (3 - (i & 3)));
	for (unsigned int j = 0; j < (sizeBits >> 2); j++)
		dstHex[j] += dstHex[j] > 9 ? 55 : 48; //convert to char '0'-'F'
}

void EnDedes::Hex2Bits(char *srcHex, char* dstBits, unsigned int sizeBits)
{
	memset(dstBits, 0, sizeBits);
	for (unsigned int i = 0; i < (sizeBits >> 2); i++)
		srcHex[i] -= srcHex[i] > 64 ? 55 : 48; //convert to char int 0-15
	for (unsigned int j = 0; j < sizeBits; j++)
		dstBits[j] = ((srcHex[j >> 2] << (j & 3)) & 15) >> 3;

}

char* EnDedes::GetCiphertextInBinary()
{
	for (unsigned int i = 0; i<64; i++)
	{
		szCiphertextInBinary[i] = szCiphertextRaw[i] + 48; // from int(0) to char('0') and int1 to char('1')
	}
	szCiphertextInBinary[64] = '\0';
	return szCiphertextInBinary;
}

char* EnDedes::GetCiphertextInHex()
{
	Bits2Hex(szCiphertextInHex, szCiphertextRaw, 64);
	szCiphertextInHex[16] = '\0';
	return szCiphertextInHex;
}

char* EnDedes::GetCiphertextInBytes()
{
	return szCiphertextInBytes;
}

char* EnDedes::GetPlaintext()
{
	memcpy(szPlaintext, szPlaintextInBytes, 8);
	szPlaintext[8] = '\0';
	return szPlaintext;
}

char* EnDedes::GetCiphertextAnyLength()
{
	return szFCiphertextAnyLength;
}

char* EnDedes::GetPlaintextAnyLength()
{
	return szFPlaintextAnyLength;
}

void EnDedes::EncryptAnyLength(char* _srcBytes, unsigned int _bytesLength, unsigned int keyN)
{
	if (_bytesLength == 8)
	{
		EncryptData(_srcBytes, keyN);
		memcpy(szFCiphertextAnyLength, szCiphertextInBytes, 8);
		szFCiphertextAnyLength[8] = '\0';
	}
	else if (_bytesLength < 8)
	{
		char _temp8bytes[8] = { 0 };
		memcpy(_temp8bytes, _srcBytes, _bytesLength);
		EncryptData(_temp8bytes, keyN);
		memcpy(szFCiphertextAnyLength, szCiphertextInBytes, 8);
		szFCiphertextAnyLength[8] = '\0';
	}
	else if (_bytesLength > 8)
	{
		int iParts = _bytesLength >> 3;
		int iResidue = _bytesLength % 8;
		char szLast8Bits[8] = { 0 };
		for (int i = 0; i<iParts; i++)
		{
			memcpy(szLast8Bits, _srcBytes + (i << 3), 8);
			EncryptData(szLast8Bits, keyN);
			memcpy(szFCiphertextAnyLength + (i << 3), szCiphertextInBytes, 8);
		}
		memset(szLast8Bits, 0, 8);
		memcpy(szLast8Bits, _srcBytes + (iParts << 3), iResidue);

		EncryptData(szLast8Bits, keyN);
		memcpy(szFCiphertextAnyLength + (iParts << 3), szCiphertextInBytes, 8);
		szFCiphertextAnyLength[((iParts + 1) << 3)] = '\0';
	}
}

void EnDedes::DecryptAnyLength(char* _srcBytes, unsigned int _bytesLength, unsigned int keyN)
{
	if (_bytesLength == 8)
	{
		DecryptData(_srcBytes, keyN);
		memcpy(szFPlaintextAnyLength, szPlaintextInBytes, 8);
		szFPlaintextAnyLength[8] = '\0';
	}
	else if (_bytesLength < 8)
	{
		char _temp8bytes[8] = { 0 };
		memcpy(_temp8bytes, _srcBytes, 8);
		DecryptData(_temp8bytes, keyN);
		memcpy(szFPlaintextAnyLength, szPlaintextInBytes, _bytesLength);
		szFPlaintextAnyLength[_bytesLength] = '\0';
	}
	else if (_bytesLength > 8)
	{
		int iParts = _bytesLength >> 3;
		int iResidue = _bytesLength % 8;
		char szLast8Bits[8] = { 0 };
		for (int i = 0; i<iParts; i++)
		{
			memcpy(szLast8Bits, _srcBytes + (i << 3), 8);
			DecryptData(szLast8Bits, keyN);
			memcpy(szFPlaintextAnyLength + (i << 3), szPlaintextInBytes, 8);
		}
		if (iResidue != 0)
		{
			memset(szLast8Bits, 0, 8);
			memcpy(szLast8Bits, _srcBytes + (iParts << 3), 8);
			DecryptData(szLast8Bits, keyN);
			memcpy(szFPlaintextAnyLength + (iParts << 3), szPlaintextInBytes, iResidue);
		}
		szFPlaintextAnyLength[_bytesLength] = '\0';
	}
}



// MD5�㷨����

CMd5A::CMd5A()
{

}

CMd5A::~CMd5A()
{

}

void CMd5A::MD5Init(MD5_CTX *context)    /* context */
{
	context->count[0] = context->count[1] = 0;
	context->state[0] = 0x67452301;    /* Load magic initialization constants.*/
	context->state[1] = 0xefcdab89;
	context->state[2] = 0x98badcfe;
	context->state[3] = 0x10325476;
}


void CMd5A::MD5Update(MD5_CTX *context, unsigned char *input, unsigned int inputLen)
{
	unsigned int i, index, partLen;
	index = (unsigned int)((context->count[0] >> 3) & 0x3F);   /* Compute number of bytes mod 64 */

	if ((context->count[0] += ((UINT4)inputLen << 3)) < ((UINT4)inputLen << 3))
		context->count[1]++;

	context->count[1] += ((UINT4)inputLen >> 29);
	partLen = 64 - index;

	/* Transform as many times as possible.*/
	if (inputLen >= partLen)
	{
		MD5_memcpy((POINTER)&context->buffer[index], (POINTER)input, partLen);
		MD5Transform(context->state, context->buffer);

		for (i = partLen; i + 63 < inputLen; i += 64)
			MD5Transform(context->state, &input[i]);

		index = 0;
	}
	else
		i = 0;
	/* Buffer remaining input */
	MD5_memcpy((POINTER)&context->buffer[index], (POINTER)&input[i], inputLen - i);
}


void CMd5A::MD5Final(unsigned char digest[16], MD5_CTX *context)
/* message digest */      /* context */
{
	unsigned char bits[8];
	unsigned int index, padLen;

	Encode(bits, context->count, 8); /* Save number of bits */

	/* Pad out to 56 mod 64.*/
	index = (unsigned int)((context->count[0] >> 3) & 0x3f);
	padLen = (index < 56) ? (56 - index) : (120 - index);
	MD5Update(context, (unsigned char*)PADDING, padLen);

	MD5Update(context, bits, 8);   /* Append length (before padding) */
	Encode(digest, context->state, 16); /* Store state in digest */

	/* Zeroize sensitive information.*/
	MD5_memset((POINTER)context, 0, sizeof(*context));
}

/* MD5 basic transformation. Transforms state based on block.
*/
void CMd5A::MD5Transform(UINT4 state[4], unsigned char block[64])
{
	int i = 0;
	UINT4 a = state[0], b = state[1], c = state[2], d = state[3], x[16];

	Decode(x, block, 64);
	/* Round 1 */
	FF(a, b, c, d, x[0], S11, 0xd76aa478); /* 1 */
	FF(d, a, b, c, x[1], S12, 0xe8c7b756); /* 2 */
	FF(c, d, a, b, x[2], S13, 0x242070db); /* 3 */
	FF(b, c, d, a, x[3], S14, 0xc1bdceee); /* 4 */
	FF(a, b, c, d, x[4], S11, 0xf57c0faf); /* 5 */
	FF(d, a, b, c, x[5], S12, 0x4787c62a); /* 6 */
	FF(c, d, a, b, x[6], S13, 0xa8304613); /* 7 */
	FF(b, c, d, a, x[7], S14, 0xfd469501); /* 8 */
	FF(a, b, c, d, x[8], S11, 0x698098d8); /* 9 */
	FF(d, a, b, c, x[9], S12, 0x8b44f7af); /* 10 */
	FF(c, d, a, b, x[10], S13, 0xffff5bb1); /* 11 */
	FF(b, c, d, a, x[11], S14, 0x895cd7be); /* 12 */
	FF(a, b, c, d, x[12], S11, 0x6b901122); /* 13 */
	FF(d, a, b, c, x[13], S12, 0xfd987193); /* 14 */
	FF(c, d, a, b, x[14], S13, 0xa679438e); /* 15 */
	FF(b, c, d, a, x[15], S14, 0x49b40821); /* 16 */
	/* Round 2 */
	GG(a, b, c, d, x[1], S21, 0xf61e2562); /* 17 */
	GG(d, a, b, c, x[6], S22, 0xc040b340); /* 18 */
	GG(c, d, a, b, x[11], S23, 0x265e5a51); /* 19 */
	GG(b, c, d, a, x[0], S24, 0xe9b6c7aa); /* 20 */
	GG(a, b, c, d, x[5], S21, 0xd62f105d); /* 21 */
	GG(d, a, b, c, x[10], S22, 0x2441453); /* 22 */
	GG(c, d, a, b, x[15], S23, 0xd8a1e681); /* 23 */
	GG(b, c, d, a, x[4], S24, 0xe7d3fbc8); /* 24 */
	GG(a, b, c, d, x[9], S21, 0x21e1cde6); /* 25 */
	GG(d, a, b, c, x[14], S22, 0xc33707d6); /* 26 */
	GG(c, d, a, b, x[3], S23, 0xf4d50d87); /* 27 */
	GG(b, c, d, a, x[8], S24, 0x455a14ed); /* 28 */
	GG(a, b, c, d, x[13], S21, 0xa9e3e905); /* 29 */
	GG(d, a, b, c, x[2], S22, 0xfcefa3f8); /* 30 */
	GG(c, d, a, b, x[7], S23, 0x676f02d9); /* 31 */
	GG(b, c, d, a, x[12], S24, 0x8d2a4c8a); /* 32 */
	/* Round 3 */
	HH(a, b, c, d, x[5], S31, 0xfffa3942); /* 33 */
	HH(d, a, b, c, x[8], S32, 0x8771f681); /* 34 */
	HH(c, d, a, b, x[11], S33, 0x6d9d6122); /* 35 */
	HH(b, c, d, a, x[14], S34, 0xfde5380c); /* 36 */
	HH(a, b, c, d, x[1], S31, 0xa4beea44); /* 37 */
	HH(d, a, b, c, x[4], S32, 0x4bdecfa9); /* 38 */
	HH(c, d, a, b, x[7], S33, 0xf6bb4b60); /* 39 */
	HH(b, c, d, a, x[10], S34, 0xbebfbc70); /* 40 */
	HH(a, b, c, d, x[13], S31, 0x289b7ec6); /* 41 */
	HH(d, a, b, c, x[0], S32, 0xeaa127fa); /* 42 */
	HH(c, d, a, b, x[3], S33, 0xd4ef3085); /* 43 */
	HH(b, c, d, a, x[6], S34, 0x4881d05); /* 44 */
	HH(a, b, c, d, x[9], S31, 0xd9d4d039); /* 45 */
	HH(d, a, b, c, x[12], S32, 0xe6db99e5); /* 46 */
	HH(c, d, a, b, x[15], S33, 0x1fa27cf8); /* 47 */
	HH(b, c, d, a, x[2], S34, 0xc4ac5665); /* 48 */
	/* Round 4 */
	II(a, b, c, d, x[0], S41, 0xf4292244); /* 49 */
	II(d, a, b, c, x[7], S42, 0x432aff97); /* 50 */
	II(c, d, a, b, x[14], S43, 0xab9423a7); /* 51 */
	II(b, c, d, a, x[5], S44, 0xfc93a039); /* 52 */
	II(a, b, c, d, x[12], S41, 0x655b59c3); /* 53 */
	II(d, a, b, c, x[3], S42, 0x8f0ccc92); /* 54 */
	II(c, d, a, b, x[10], S43, 0xffeff47d); /* 55 */
	II(b, c, d, a, x[1], S44, 0x85845dd1); /* 56 */
	II(a, b, c, d, x[8], S41, 0x6fa87e4f); /* 57 */
	II(d, a, b, c, x[15], S42, 0xfe2ce6e0); /* 58 */
	II(c, d, a, b, x[6], S43, 0xa3014314); /* 59 */
	II(b, c, d, a, x[13], S44, 0x4e0811a1); /* 60 */
	II(a, b, c, d, x[4], S41, 0xf7537e82); /* 61 */
	II(d, a, b, c, x[11], S42, 0xbd3af235); /* 62 */
	II(c, d, a, b, x[2], S43, 0x2ad7d2bb); /* 63 */
	II(b, c, d, a, x[9], S44, 0xeb86d391); /* 64 */

	state[0] += a;
	state[1] += b;
	state[2] += c;
	state[3] += d;

	/* Zeroize sensitive information.*/
	MD5_memset((POINTER)x, 0, sizeof(x));
}

/* Encodes input (UINT4) into output (unsigned char). Assumes len is
a multiple of 4.
*/
void CMd5A::Encode(unsigned char *output, UINT4 *input, unsigned int len)
{
	unsigned int i, j;

	for (i = 0, j = 0; j < len; i++, j += 4)
	{
		output[j] = (unsigned char)(input[i] & 0xff);
		output[j + 1] = (unsigned char)((input[i] >> 8) & 0xff);
		output[j + 2] = (unsigned char)((input[i] >> 16) & 0xff);
		output[j + 3] = (unsigned char)((input[i] >> 24) & 0xff);
	}
}

/* Decodes input (unsigned char) into output (UINT4). Assumes len is
a multiple of 4.
*/
void CMd5A::Decode(UINT4 *output, unsigned char *input, unsigned int len)
{
	unsigned int i, j;

	for (i = 0, j = 0; j < len; i++, j += 4)
		output[i] = ((UINT4)input[j]) | (((UINT4)input[j + 1]) << 8) | (((UINT4)input[j + 2]) << 16) | (((UINT4)input[j + 3]) << 24);
}

/* Note: Replace "for loop" with standard memcpy if possible. */
void CMd5A::MD5_memcpy(POINTER output, POINTER input, unsigned int len)
{
	unsigned int i;

	for (i = 0; i < len; i++)
		output[i] = input[i];
}

/* Note: Replace "for loop" with standard memset if possible. */
void CMd5A::MD5_memset(POINTER output, int value, unsigned int len)
{
	unsigned int i;

	for (i = 0; i < len; i++)
		((char *)output)[i] = (char)value;
}

/* Digests a string and prints the result. */
char* CMd5A::MDString(char *string)
{
	MD5_CTX context;
	unsigned char digest[16];
	char output1[33];
	static  char output[33] = { "\0" };
	unsigned int len = strlen(string);
	int i;
	MD5Init(&context);
	MD5Update(&context, (unsigned char*)string, len);
	MD5Final(digest, &context);

	for (i = 0; i < 16; i++)
	{
		sprintf(&(output1[2 * i]), "%02x", (unsigned char)digest[i]);
		//sprintf(&(output1[2*i+1]),"%02x",(unsigned char)(digest[i]<<4));
	}
	for (i = 0; i<32; i++)
		output[i] = output1[i];
	return output;
}


/* Digests a file and prints the result. */
//char* CMd5A::MDFile (CString filename)
CString CMd5A::MDFile(CString filename)
{
	static char output[33] = { "\0" };
	CFile file;
	CString result;
	MD5_CTX context;
	int len;
	unsigned char buffer[1024], digest[16];
	int i;
	char output1[33];
	//UINT aaa;
	if (file.Open(filename, CFile::modeRead) == 0)
	{
		//printf ("%s can't be opened\n", filename);
		AfxMessageBox("open file error");
		return "";
	}
	else
	{
		MD5Init(&context);
		while (len = file.Read(buffer, 1024))//, 1024, file))
			MD5Update(&context, buffer, len);
		MD5Final(digest, &context);
		file.Close();
		for (i = 0; i < 16; i++)
		{
			sprintf(&(output1[2 * i]), "%02x", (unsigned char)digest[i]);
			//	sprintf(&(output1[2*i+1]),"%02x",(unsigned char)(digest[i]<<4));
		}
		for (i = 0; i<32; i++)
			output[i] = output1[i];
		result = output;
		return result;
	}
}

char* CMd5A::hmac_md5(char* text, char*  key)
{
	char   digest[16];
	char   output1[32];
	static char output[33] = { "\0" };
	MD5_CTX context;
	unsigned char k_ipad[65];    /* inner padding -
								 * key XORd with ipad
								 */
	unsigned char k_opad[65];    /* outer padding -
								 * key XORd with opad
								 */
	unsigned char tk[16];
	int i;
	int text_len = strlen(text);
	int key_len = strlen(key);
	/* if key is longer than 64 bytes reset it to key=MD5(key) */
	if (key_len > 64)
	{
		MD5_CTX      tctx;

		MD5Init(&tctx);
		MD5Update(&tctx, (unsigned char*)key, key_len);
		MD5Final(tk, &tctx);

		key = (char*)tk;
		key_len = 16;
	}

	/*
	* the HMAC_MD5 transform looks like:
	*
	* MD5(K XOR opad, MD5(K XOR ipad, text))
	*
	* where K is an n byte key
	* ipad is the byte 0x36 repeated 64 times
	* opad is the byte 0x5c repeated 64 times
	* and text is the data being protected
	*/

	/* start out by storing key in pads */

	/*bzero( k_ipad, sizeof k_ipad);
	bzero( k_opad, sizeof k_opad);
	*/

	for (i = 0; i<65; i++)
		k_ipad[i] = (unsigned char)0;
	for (i = 0; i<65; i++)
		k_opad[i] = (unsigned char)0;

	/*bcopy( key, k_ipad, key_len);
	bcopy( key, k_opad, key_len);
	*/
	for (i = 0; i<key_len; i++)
	{
		k_ipad[i] = (unsigned char)key[i];
		k_opad[i] = (unsigned char)key[i];
	}

	/* XOR key with ipad and opad values */
	for (i = 0; i<64; i++)
	{
		k_ipad[i] ^= 0x36;
		k_opad[i] ^= 0x5c;
	}
	/*
	* perform inner MD5
	*/
	MD5Init(&context);                   /* init context for 1st
										 * pass */
	MD5Update(&context, k_ipad, 64);      /* start with inner pad */
	MD5Update(&context, (unsigned char*)text, text_len); /* then text of datagram */

	MD5Final((unsigned char*)digest, &context);          /* finish up 1st pass */
	/*
	* perform outer MD5
	*/
	MD5Init(&context);                   /* init context for 2nd
										 * pass */
	MD5Update(&context, k_opad, 64);     /* start with outer pad */
	MD5Update(&context, (unsigned char*)digest, 16);     /* then results of 1st
														 * hash */
	MD5Final((unsigned char*)digest, &context);          /* finish up 2nd pass */
	for (i = 0; i < 16; i++)
	{
		sprintf(&(output1[2 * i]), "%02x", (unsigned char)digest[i]);
		sprintf(&(output1[2 * i + 1]), "%02x", (unsigned char)(digest[i] << 4));
	}
	for (i = 0; i<32; i++)
		output[i] = output1[i];
	return output;
}


char* RC4::rc4(char* text, char* key)
{
	int S[256];
	int T[256];

	int  count = 0;
	count = strlen(key);

	for (int i = 0; i < 256; i++)
	{
		S[i] = i;
		int tmp = i % count;
		T[i] = key[tmp];
	}

	int m = 0;

	for (int i = 0; i < 256; i++)
	{
		m = (m + S[i] + T[i]) % 256;
		int tmp;
		tmp = S[m];
		S[m] = S[i];
		S[i] = tmp;
	}

	int length = 0;
	length = strlen(text);

	int i, j;
	i = 0, j = 0;

	for (int p = 0; p < length; p++)
	{

		i = (i + 1) % 256;
		j = (j + S[i]) % 256;
		int tmp;
		tmp = S[j];
		S[j] = S[i];
		S[i] = tmp;

		int k = S[(S[i] + S[j]) % 256];
		text[p] = text[p] ^ k;
	}

	return text;
}


// MFC����������Ӧ��ť


void EnDecryption::OnBnClickedButton1() //DES encryption
{

	CString str,key,encrystr;
	EnDedes des;
	
	GetDlgItem(IDC_EDIT_plaintext)->GetWindowText(str);
	GetDlgItem(IDC_EDIT_key)->GetWindowText(key);
	encrystr = des.DESr(str, key);
	GetDlgItem(IDC_EDIT_ciphertext)->SetWindowText(encrystr);

}



void EnDecryption::OnBnClickedButton3() // DES decryption
{
	 
	CString str, key, decrystr;
	EnDedes des;

	GetDlgItem(IDC_EDIT_plaintext)->GetWindowText(str);
	GetDlgItem(IDC_EDIT_key)->GetWindowText(key);
	decrystr = des.DESw(str, key);
	GetDlgItem(IDC_EDIT_ciphertext)->SetWindowText(decrystr);

}


void EnDecryption::OnBnClickedButton4() //3DES encryption
{

	CString str, key, decrystr,iv;
	EnDedes des;

	GetDlgItem(IDC_EDIT_plaintext)->GetWindowText(str);
	GetDlgItem(IDC_EDIT_key)->GetWindowText(key);
	GetDlgItem(IDC_EDIT_iv)->GetWindowText(iv);
	decrystr = des.DESr(str, key,iv);
	GetDlgItem(IDC_EDIT_ciphertext)->SetWindowText(decrystr);

}


void EnDecryption::OnBnClickedButton5() // 3DES decryption
{
	 
	CString str, key, decrystr,iv;
	EnDedes des;

	GetDlgItem(IDC_EDIT_plaintext)->GetWindowText(str);
	GetDlgItem(IDC_EDIT_key)->GetWindowText(key);
	GetDlgItem(IDC_EDIT_iv)->GetWindowText(iv);
	decrystr = des.DESw(str, key,iv);
	GetDlgItem(IDC_EDIT_ciphertext)->SetWindowText(decrystr);
}



void EnDecryption::OnBnClickedButton7()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������

	//	ʹ�÷�����
	//	CString str = "123";
	//	CMd5A md5;
	//	MessageBox(md5.MDString((char*)(LPCTSTR)str));
	CString str,md5str;
	GetDlgItem(IDC_EDIT_plaintext)->GetWindowText(str);
	CMd5A md5;
	md5str = md5.MDString((char*)(LPCTSTR)str);
	GetDlgItem(IDC_EDIT_ciphertext)->SetWindowText(md5str);

}


void EnDecryption::OnBnClickedButtonRc4() // RC4�ӽ���
{
	CString str,_str;
	CString str_key;
	char * text;
	char * key;
	RC4 rc4;
	GetDlgItem(IDC_EDIT_plaintext)->GetWindowText(str);
	GetDlgItem(IDC_EDIT_key)->GetWindowText(str_key);

	//str_hex = (char*)str.GetBuffer(str.GetLength());
	text = (char*)str.GetBuffer(str.GetLength()); //����CString��str��ֵ������char *��text
	key = (char*)str_key.GetBuffer(str_key.GetLength());
	//char* str_char = (char*)malloc(strlen(str_hex) * sizeof(char));
	//strncpy(str_char, "", strlen(str_char));
	text = rc4.rc4(text, key);

	//hex_char.Hex_2_char(str_hex, str_char);
	_str.Format("%s", text);
	GetDlgItem(IDC_EDIT_ciphertext)->SetWindowText(_str);

}


unsigned int CRC32::_CRC32(void *pData, size_t iLen)
{
	unsigned int uiCRC32 = 0xFFFFFFFF;
	unsigned char *pszData = (unsigned char*)pData;

	for (size_t i = 0; i<iLen; ++i)
		uiCRC32 = ((uiCRC32 >> 8) & 0x00FFFFFF) ^ uiCRC32_Table[(uiCRC32 ^ (unsigned int)*pszData++) & 0xFF];

	return (uiCRC32 ^ 0xFFFFFFFF);
}

#include <string>
#include <iostream>
#include <strstream>
void unsigned_to_hex(unsigned int value, std::string & hex_string)
{
	std::strstream buffer;
	buffer.setf(std::ios::showbase);
	buffer << std::hex << value;
	buffer >> hex_string;
}


void EnDecryption::OnBnClickedButtoncrc32()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	CString str, _str;
	CRC32 crc32;
	char* text;
	std::string hex_string;
	GetDlgItem(IDC_EDIT_plaintext)->GetWindowText(str);

	text = (char*)str.GetBuffer(str.GetLength()); //����CString��str��ֵ������char *��text
	unsigned int Hash = crc32._CRC32(text, strlen(text));
	unsigned_to_hex(Hash, hex_string);

	//key = (char*)str_key.GetBuffer(str_key.GetLength());
	//text = rc4.rc4(text, key);
	_str = hex_string.c_str();
	GetDlgItem(IDC_EDIT_ciphertext)->SetWindowText(_str.MakeUpper()); //תΪ��д

}


void EnDecryption::OnBnClickedButtoncaser()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	CString str, _str;
	string str_in, str_out;
	char words[50] = "\0"; //����ǰ
	char _words[50] = "\0";
	int i = 0;
	int j = 0;
	GetDlgItem(IDC_EDIT_plaintext)->GetWindowText(str);

	str_in = str.GetBuffer(str.GetLength()); //CStringתΪstring
	::strncpy(words, str_in.c_str(), str_in.length() + 1); //��str_in��ֵתΪchar[]
	for (i = 0; i < 26; i++)
	{
		for (j = 0; words[j] != '\0'; j++)
		{
			if (words[j] >= 'A' && words[j] <= 'Z')
				_words[j] = (words[j] - 'A' + i) % 26 + 'A';   //����Կkey����i���г���
			else if (words[j] >= 'a' && words[j] <= 'z')
				_words[j] = (words[j] - 'a' + i) % 26 + 'a';
		}
		str_out += "��"+to_string(i+1)+"�γ��ԣ�"+_words+"\r\n";
	}
	_str = str_out.c_str();
	GetDlgItem(IDC_EDIT_ciphertext)->SetWindowText(_str);
	
}
