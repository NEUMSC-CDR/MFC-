#pragma once
#include "afxcmn.h"


// CListDlg �Ի���

class CListDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CListDlg)

public:
	CListDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CListDlg();
	void SetCtrlStyle(HWND hWnd, DWORD dwNewStyle);
// �Ի�������
	enum { IDD = IDD_LIST };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_ListCtrl;
	virtual BOOL OnInitDialog();
	
	afx_msg void OnBnClickedRadioLarge();
	afx_msg void OnBnClickedRadioSmall();
	afx_msg void OnBnClickedRadioList();
	afx_msg void OnBnClickedRadioReport();
	afx_msg void OnBnClickedButtonAdd();
};
