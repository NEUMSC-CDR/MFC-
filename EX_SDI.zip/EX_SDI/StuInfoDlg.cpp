// StuInfoDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EX_SDI.h"
#include "StuInfoDlg.h"
#include "afxdialogex.h"



// CStuInfoDlg �Ի���

IMPLEMENT_DYNAMIC(CStuInfoDlg, CDialogEx)

CStuInfoDlg::CStuInfoDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CStuInfoDlg::IDD, pParent)
	, m_strName(_T(""))
	, m_strNo(_T(""))
	, m_tBirth(0)
	, m_strSpecial(_T(""))
{

}

CStuInfoDlg::~CStuInfoDlg()
{
}

void CStuInfoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_NAME, m_strName);
	DDV_MaxChars(pDX, m_strName, 10);
	DDX_Text(pDX, IDC_EDIT_NO, m_strNo);
	DDV_MaxChars(pDX, m_strNo, 10);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER1, m_tBirth);
	DDX_Control(pDX, IDC_COMBO_SPECIAL, m_comboSpecial);
	DDX_CBString(pDX, IDC_COMBO_SPECIAL, m_strSpecial);
}


BEGIN_MESSAGE_MAP(CStuInfoDlg, CDialogEx)

	ON_BN_CLICKED(IDOK, &CStuInfoDlg::OnBnClickedOk)
END_MESSAGE_MAP()




BOOL CStuInfoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_tBirth = CTime(1986, 1, 1, 0, 0, 0); UpdateData(FALSE);
	return TRUE;

}


void CStuInfoDlg::OnBnClickedOk()
{
	UpdateData();
	m_strName.TrimLeft();
	m_strNo.TrimLeft();
	if (m_strName.IsEmpty())
		MessageBox("����Ҫ��������");
	else if (m_strNo.IsEmpty())
		MessageBox("����Ҫ��ѧ�ţ�");
	else
		CDialog::OnOK();

}
