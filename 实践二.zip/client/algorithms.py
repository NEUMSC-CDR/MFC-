import random
import os
import string
import codecs
import string
import base64
import os
import binascii
import hashlib


class algoRithms:

    def caesar_encrypt(self, x, k):
        """第一个参数为明文字符串，第二个参数为向后移位的位数"""
        result = ''
        move = k % 26
        for i in x:
            pass
            # 如果是大写
            if (i.isupper()):
                result = result + chr(65 + (ord(i) + move - 65) % 26)
            elif (i.islower()):
                result = result + chr(97 + (ord(i) + move - 97) % 26)
        return result

    def keywords_encrypt(self, plaintext, _key):
        plaintext = list(plaintext.lower())
        ciphertext = list(string.ascii_lowercase)
        _key = list(_key.lower())
        key = []
        for i in _key:
            if i not in key:
                key.append(i)
        for i in ciphertext:
            if i not in key:
                key.append(i)
        all_letter = list(string.ascii_lowercase)
        ciphertext = []
        for i in plaintext:
            for j in range(26):
                if i == all_letter[j]:
                    ciphertext.append(key[j])
        return "".join(key), "".join(ciphertext)  # 返回的是重拍的key和密文

    def affine_encrypt(self, plainText, key_a, key_b):
        _encrypt = {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5,
                    'g': 6, 'h': 7, 'i': 8, 'j': 9, 'k': 10, 'l': 11, 'm': 12,
                    'n': 13, 'o': 14, 'p': 15, 'q': 16, 'r': 17, 's': 18, 't': 19,
                    'u': 20, 'v': 21, 'w': 22, 'x': 23, 'y': 24, 'z': 25}
        _decrypt = {0: 'a', 1: 'b', 2: 'c', 3: 'd', 4: 'e', 5: 'f', 6: 'g',
                    7: 'h', 8: 'i', 9: 'j', 10: 'k', 11: 'l', 12: 'm', 13: 'n', 14: 'o', 15: 'p', 16: 'q', 17: 'r',
                    18: 's', 19: 't', 20: 'u', 21: 'v', 22: 'w', 23: 'x', 24: 'y', 25: 'z'}
        key_a = key_a % 26
        key_b = key_b % 26
        result = ""
        for i in plainText:
            result += _decrypt.get((key_a * (_encrypt.get(i)) + key_b) % 26)
        return result

    def multiliteral_encrypt(self, pla, key):
        pla = pla.lower()
        key = key.lower()
        cip = []
        # 定义好矩阵
        table = [['', key[0], key[1], key[2], key[3], key[4]],
                 [key[0], 'a', 'b', 'c', 'd', 'e'],
                 [key[1], 'f', 'g', 'h', 'i', 'k'],
                 [key[2], 'l', 'm', 'n', 'o', 'p'],
                 [key[3], 'q', 'r', 's', 't', 'u'],
                 [key[4], 'v', 'w', 'x', 'y', 'z']]
        for k in pla:
            # 当明文中有“j”的时候，当做“i”进行处理
            if k == 'j':
                k = 'i'
            for i in range(1, 6):
                for j in range(1, 6):
                    if k == table[i][j] and k != 'j':
                        cip.append(table[i][0])
                        cip.append(table[0][j])
        cipertext = ''.join(cip)
        return cipertext

    def vigenere_encrypt(self, plaintext, key):
        def str2num(str):
            if len(str) == 1:
                return ord(str) - 65
            else:
                tmpstr = []
                for i in range(len(str)):
                    tmpstr.append(ord(str[i]) - 65)
                return tmpstr

        # 将0-26的数转化为字母A-Z
        def num2str(str):
            tmpstr = ""
            for i in str:
                tmpstr += chr(i + 65)
            return tmpstr

        plaintext = plaintext.upper()

        def keymodify(key, length):
            if len(key) > length:
                return key[:length]
            elif len(key) == length:
                return key
            else:
                while len(key) < length:
                    key += key
                if len(key) != length:
                    return key[:length]  # 处理掉多余的部分
                else:
                    return key

        key = key.upper()
        Key = keymodify(key, len(plaintext))
        cipherText = []
        for index, item in enumerate(plaintext):
            cipherText.append(((str2num(Key[index]) + str2num(item)) % 26))
        return num2str(cipherText)

    def autokey_plaintext_encrypt(self, plainText, key):
        alphabet = [chr(65 + x) for x in range(26)]
        cipherTable = []
        count1 = 0
        for x in range(26):
            row = alphabet[count1:] + alphabet[:count1]
            cipherTable.append(row)
            count1 += 1
        plainTextList = [x.upper() for x in plainText if
                         (ord(x) >= ord("a") and ord(x) <= ord("z")) or (ord(x) >= ord("A") and ord(x) <= ord("Z"))]
        keyList = [x.upper() for x in key]
        count2 = 0
        cipherTextList, cipherTextPartList = [], []
        for x in plainTextList:
            cipherTextPartList.append(
                cipherTable[ord(keyList[count2]) - ord("A")][ord(x) - ord("A")])
            count2 += 1
            if count2 == len(keyList):
                for y in cipherTextPartList:
                    cipherTextList.append(y)
                keyList = [x for x in cipherTextPartList]
                cipherTextPartList = []
                count2 = 0

        if count2 != 0:
            for x in cipherTextPartList:
                cipherTextList.append(x)
        else:
            pass
        cipherText = ""
        for x in cipherTextList:
            cipherText += x
        return cipherText

    def autokey_ciphertext_encrypt(self, plaintext, key):
        _key = key + plaintext[0:len(plaintext) - len(key)]
        matrix = [([0] * 26) for i in range(26)]
        for x in range(26):  # 生成加密的26*26矩阵
            for y in range(26):
                t = 65 + y + x
                if t > 90:
                    matrix[x][y] = chr(t - 26)
                if t <= 90:
                    matrix[x][y] = chr(t)

        __key = ''  # 后面的大写密钥
        for x in _key:  # 将密钥全部转化为大写
            if ord(x) >= 97:
                x = chr(ord(x) - 32)
            __key = __key + x
        compare_matrix = [([0] * 2)
                          for i in range(len(plaintext))]  # 加密一对一对照矩阵

        cipherText = ''
        t = 0  # 用于密钥和明文匹配时循环判断
        for i in range(len(plaintext)):
            t = t % len(_key)
            compare_matrix[i][0] = plaintext[i]
            compare_matrix[i][1] = __key[t]
            t = t + 1

        for i in range(len(plaintext)):
            if ord(compare_matrix[i][0]) >= 97:
                t = ord(compare_matrix[i][0]) - 97
                x = ord(compare_matrix[i][1]) - 65
                cipherText = cipherText + chr(ord(matrix[t][x]) + 32)
            if ord(compare_matrix[i][0]) < 97:
                t = ord(compare_matrix[i][0]) - 65
                x = ord(compare_matrix[i][1]) - 65
                cipherText = cipherText + chr(ord(matrix[t][x]))
        return cipherText

    def playfair_encrypt(self, key, plaintext):
        key = key.lower()
        plaintext = plaintext.lower()

        def pos(row, col):
            return row * 5 + col

        def cell(position):
            row = int(position / 5)
            col = position % 5
            return row, col

        table = ""
        for c in key.lower() + string.ascii_lowercase:
            if c in ['i', 'j']:  # treat i/j as the same char
                if ('i' not in table) and ('j' not in table):
                    table = table + 'i'
            elif c not in table:
                table = table + c
        ciphertext = ""
        while plaintext != "":
            if len(plaintext) == 1:
                a = plaintext[0]
                b = "x"
                plaintext = ""
            # duplicate letter
            elif plaintext[0] == plaintext[1]:
                a = plaintext[0]
                b = "x"
                plaintext = plaintext[1:]
            else:
                a = plaintext[0]
                b = plaintext[1]
                plaintext = plaintext[2:]

            a = "i" if a == "j" else a
            b = "i" if b == "j" else b
            c1 = cell(table.find(a))
            c2 = cell(table.find(b))

            shift = 1
            if c1[0] == c2[0]:
                ciphertext = ciphertext + table[pos(c1[0], (c1[1] + shift) % 5)] + table[
                    pos(c2[0], (c2[1] + shift) % 5)]
            elif c1[1] == c2[1]:
                ciphertext = ciphertext + table[pos((c1[0] + shift) % 5, c1[1])] + table[
                    pos((c2[0] + shift) % 5, c2[1])]
            else:
                ciphertext = ciphertext + \
                    table[pos(c1[0], c2[1])] + table[pos(c2[0], c1[1])]
        return ciphertext

    def permutation_encrypt(self, plaintext, key):
        def treatment(chunks, order):
            result = ''
            for x in chunks:
                for pos in order:
                    result += x[pos]
            return result.replace(' ', '')

        def plaintextToChunks(plaintext, key):
            plaintext = plaintext.replace(' ', '')
            while len(plaintext) % len(key) != 0:
                plaintext += ' '
            chunks = []
            for i in range(0, len(plaintext), len(key)):
                chunks.append(plaintext[i:i + len(key)])
            return chunks

        def keyToEncrpty(key):
            order = [0] * len(key)
            sorted_key = ''.join(sorted(key))
            for i, x in enumerate(key):
                order[sorted_key.find(x)] = i
            return order

        plaintext = plaintext.replace(' ', '')
        chunks = plaintextToChunks(plaintext, key)
        order = keyToEncrpty(key)
        return treatment(chunks, order)

    def column_permutation_encrypt(self, plaintext, key):
        def orderFormat(key):
            result = []
            tmp = []
            for i in key:
                tmp.append(ord(i))
            order = tmp.copy().sort()  # 获得新表
            for e in set(order):
                if order.count(e) == 1:
                    result.append(tmp.index(e))
                else:
                    for j in [i for (i, j) in enumerate(tmp) if j == e]:
                        result.append(j)
            return result

        ciphertext = ""
        Plaintext = ""
        while len(plaintext) % len(key) != 0:
            Plaintext += "e"
        n = len(Plaintext) // len(key)
        order = orderFormat(key)
        for i in order:
            excursion = 0
            for j in range(n):
                ciphertext += Plaintext[i + excursion]
                excursion += len(key)
        return ciphertext

    def double_transposition_encrypt(self, plaintext, key_a, key_b):
        def replacement(plaintttext, key):  # 此为一次置换，不是两次
            plaintext = plaintttext
            lineNum = len(key)
            matrix = [0 for i in range(lineNum)]
            textLen = len(plaintext)
            i = textLen % lineNum
            if i == 0:  # 确定列数
                columnsNum = int(textLen / lineNum)
            if i != 0:
                columnsNum = int(textLen / lineNum) + 1
            matrix = [([0] * lineNum) for i in range(columnsNum)]
            t = 0  # t用于循环判断，填充矩阵
            for x in range(columnsNum):  # 循环判断，填充矩阵
                for y in range(lineNum):
                    if t < textLen:
                        matrix[x][y] = plaintext[t]
                        t = t + 1
                    if t > textLen:
                        matrix[x][y] = '+'
            for x in range(lineNum):  # 对密钥的字母大小进行排序
                for y in range(lineNum):
                    if x == y:
                        matrix[x] = matrix[x] + 1
                    if ord(key[x]) > ord(key[y]):
                        matrix[x] = matrix[x] + 1
                    if ord(key[x]) < ord(key[y]):
                        continue
                    if (ord(key[x]) == ord(key[y])) & (x > y):
                        matrix[x] = matrix[x] + 1

            keyList = [0 for i in range(
                (columnsNum) * lineNum)]  # 声明存储加密字符串的数组
            res = ''
            for i in range(len(keyList)):  # 打印输出加密
                res = res + str(keyList[i])
            return res

        return replacement(replacement(plaintext, key_a), key_b)


# RC4加解密


class RC4():

    def KSA(self, key):
        # Key Scheduling Algorithm
        len_key = len(key)
        S = list(range(256))
        # S = [0,1,2, ... , 255]
        j = 0
        for i in range(256):
            j = (j + S[i] + key[i % len_key]) % 256
            S[i], S[j] = S[j], S[i]
        return S

    def PRGA(self, S):
        i = 0
        j = 0
        K = []
        while True:
            i = (i + 1) % 256
            j = (j + S[i]) % 256
            S[i], S[j] = S[j], S[i]
            K = S[(S[i] + S[j]) % 256]
            yield K

    # yield语法是为了生成可迭代的容器，因为这里不知道要生成多少K，让第55行来决定

    def get_keystream(self, key):
        S = self.KSA(key)
        return self.PRGA(S)

    def encrypt_logic(self, key, text):
        key = [ord(c) for c in key]
        keystream = self.get_keystream(key)
        res = []
        for c in text:
            val = ("%02X" % (c ^ next(keystream)))
            res.append(val)
        return ''.join(res)

    def rc4_encrypt(self, plaintext, key):
        plaintext = [ord(c) for c in plaintext]
        return self.encrypt_logic(key, plaintext)

    def rc4_decrypt(self, ciphertext, key):
        ciphertext = codecs.decode(ciphertext, 'hex_codec')
        res = self.encrypt_logic(key, ciphertext)
        return codecs.decode(res, 'hex_codec').decode('utf-8')

    def rc4_encrypt_file(self, file_plain, file_ciphered, key):
        with open(file_plain, 'r') as myfile:
            lines = myfile.readlines()
        with open(file_ciphered, 'w') as myfile:
            for plaintext in lines:
                plaintext = [ord(c) for c in plaintext.replace('\n', '')]
                ciphertext = self.encrypt_logic(key, plaintext)
                myfile.write(ciphertext + '\n')

    def rc4_decrypt_file(self, file_plain, file_ciphered, key):
        with open(file_ciphered, 'r') as myfile:
            lines = myfile.readlines()
        with open(file_plain, 'w') as myfile:
            for ciphertext in lines:
                ciphertext = codecs.decode(
                    ciphertext.replace('\n', ''), 'hex_codec')
                res = self.encrypt_logic(key, ciphertext)
                decrptedtext = codecs.decode(res, 'hex_codec').decode('utf-8')
                myfile.write(decrptedtext + '\n')


# DES


class DES(object):
    def bytes_hex(self, m):
        res = ''
        for i in m:
            res += hex(i)[2:].rjust(2, '0')
        return res

    IP = (58, 50, 42, 34, 26, 18, 10, 2,
          60, 52, 44, 36, 28, 20, 12, 4,
          62, 54, 46, 38, 30, 22, 14, 6,
          64, 56, 48, 40, 32, 24, 16, 8,
          57, 49, 41, 33, 25, 17, 9, 1,
          59, 51, 43, 35, 27, 19, 11, 3,
          61, 53, 45, 37, 29, 21, 13, 5,
          63, 55, 47, 39, 31, 23, 15, 7)
    FP = (40, 8, 48, 16, 56, 24, 64, 32,
          39, 7, 47, 15, 55, 23, 63, 31,
          38, 6, 46, 14, 54, 22, 62, 30,
          37, 5, 45, 13, 53, 21, 61, 29,
          36, 4, 44, 12, 52, 20, 60, 28,
          35, 3, 43, 11, 51, 19, 59, 27,
          34, 2, 42, 10, 50, 18, 58, 26,
          33, 1, 41, 9, 49, 17, 57, 25)
    E = (32, 1, 2, 3, 4, 5,
         4, 5, 6, 7, 8, 9,
         8, 9, 10, 11, 12, 13,
         12, 13, 14, 15, 16, 17,
         16, 17, 18, 19, 20, 21,
         20, 21, 22, 23, 24, 25,
         24, 25, 26, 27, 28, 29,
         28, 29, 30, 31, 32, 1)
    P = (16, 7, 20, 21,
         29, 12, 28, 17,
         1, 15, 23, 26,
         5, 18, 31, 10,
         2, 8, 24, 14,
         32, 27, 3, 9,
         19, 13, 30, 6,
         22, 11, 4, 25)
    S = [[[14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7],
          [0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8],
          [4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0],
          [15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13]],

         [[15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10],
          [3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5],
          [0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15],
          [13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9]],

         [[10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8],
          [13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1],
          [13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7],
          [1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12]],

         [[7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15],
          [13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9],
          [10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4],
          [3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14]],

         [[2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9],
          [14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6],
          [4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14],
          [11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3]],

         [[12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11],
          [10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8],
          [9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6],
          [4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13]],

         [[4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1],
          [13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6],
          [1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2],
          [6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12]],

         [[13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7],
          [1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2],
          [7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8],
          [2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11]]]

    PC_1L = (57, 49, 41, 33, 25, 17, 9,
             1, 58, 50, 42, 34, 26, 18,
             10, 2, 59, 51, 43, 35, 27,
             19, 11, 3, 60, 52, 44, 36)
    PC_1R = (63, 55, 47, 39, 31, 23, 15,
             7, 62, 54, 46, 38, 30, 22,
             14, 6, 61, 53, 45, 37, 29,
             21, 13, 5, 28, 20, 12, 4)
    PC_2 = (14, 17, 11, 24, 1, 5,
            3, 28, 15, 6, 21, 10,
            23, 19, 12, 4, 26, 8,
            16, 7, 27, 20, 13, 2,
            41, 52, 31, 37, 47, 55,
            30, 40, 51, 45, 33, 48,
            44, 49, 39, 56, 34, 53,
            46, 42, 50, 36, 29, 32)

    def Permute(self, block, b_len, PP):
        # 通过置换矩阵PP对block进行置换,b_len是块长度(位，bit)
        res = 0
        for i in PP:
            res = res << 1
            # 第i-1的位置 即倒数第
            res |= (block >> (b_len - i)) & 0x01
        return res

    def bytesToblocks(self, m):
        # 字节序列转换位blocks    b'\x00\x01\x02\x03\xff\xff\xff\xff' -> [0x00010203,0xffffffff]
        while len(m) % 8 != 0:
            m += b'\x00'
        blocks = []
        for i in range(len(m) // 4):
            blocks.append((m[4 * i] << 24) | (m[4 * i + 1] << 16) |
                          (m[4 * i + 2] << 8) | (m[4 * i + 3]))
        return blocks

    def blocksTobytes(self, blocks):
        # blocks转换为字节序列    [0x00010203,0xffffffff] -> b'\x00\x01\x02\x03\xff\xff\xff\xff'
        res = b''
        for i in blocks:
            res += i.to_bytes(4, byteorder="big")
        return res

    def L(self, x, n):
        return ((x << n) | (x >> (28 - n))) & 0x0fffffff

    # 对一个28bits的数x进行循环左移n位
    def F(self, block, subKeyid):
        """
        :param block: 32bits
        :param subKeyid:
        :return: res: 32bits
        """
        temp = self.Permute(block, 32, self.E) ^ self.subKs[subKeyid]
        res = 0
        for i in range(8):
            res = res << 4
            xx = (temp >> 6 * (7 - i)) & 0x3f
            p = (xx & 0x1f) >> 1
            yy = ((xx >> 5) << 1) | (xx & 0x01)
            res |= self.S[i][yy][p]
        res = self.Permute(res, 32, self.P)
        return res & 0xffffffff

    def __init__(self, K: bytes):
        # 通过密钥K生成实例
        self.K = K
        self.K_blocks = self.bytesToblocks(K)[:2]
        # 生成字密钥self.subKs[16]
        self.subKs = None
        self.generate_subKs()

    def Encrypt(self, m: bytes) -> bytes:
        # 加密
        blocks = self.bytesToblocks(m)
        cblocks = []
        for i in range(len(blocks) // 2):
            # 每个64bits的高32bits，低32bits
            high, low = blocks[2 * i], blocks[2 * i + 1]
            # 第一步：初始置换IP
            temp = self.Permute((high << 32) | low, 64,
                                self.IP) & 0xffffffffffffffff
            # 第二步：获取 Li 和 Ri
            high, low = temp >> 32, temp & 0xffffffff
            # 第三步：共16轮迭代
            for j in range(16):
                high, low = low, (high ^ self.F(low, j))
            # 第四步：合并L16和R16，注意合并为 R16L16
            high, low = low, high
            # 第五步：末尾置换FP
            temp = self.Permute((high << 32) | low, 64,
                                self.FP) & 0xffffffffffffffff
            high, low = temp >> 32, temp & 0xffffffff
            cblocks.append(high)
            cblocks.append(low)
        return self.blocksTobytes(cblocks)

    def Decrypt(self, e: bytes) -> bytes:
        # 解密
        blocks = self.bytesToblocks(e)
        cblocks = []
        for i in range(len(blocks) // 2):
            # 每个64bits的高32bits，低32bits
            high, low = blocks[2 * i], blocks[2 * i + 1]
            # 第一步：初始置换IP
            temp = self.Permute((high << 32) | low, 64,
                                self.IP) & 0xffffffffffffffff
            # 第二步：获取 Li 和 Ri
            high, low = temp >> 32, temp & 0xffffffff
            # 第三步：共16轮迭代, 子密钥逆序
            for j in range(16):
                high, low = low, (high ^ self.F(low, 15 - j))
            # 第四步：合并L16和R16，注意合并为 R16L16
            high, low = low, high
            # 第五步：末尾置换FP
            temp = self.Permute((high << 32) | low, 64,
                                self.FP) & 0xffffffffffffffff
            high, low = temp >> 32, temp & 0xffffffff
            cblocks.append(high)
            cblocks.append(low)
        return self.blocksTobytes(cblocks)

    def generate_subKs(self):
        # print(bin((self.K_blocks[0] << 32) | self.K_blocks[1])[2:].rjust(32, '0'))
        C = self.Permute(
            (self.K_blocks[0] << 32) | self.K_blocks[1], 64, self.PC_1L) & 0x0fffffff
        D = self.Permute(
            (self.K_blocks[0] << 32) | self.K_blocks[1], 64, self.PC_1R) & 0x0fffffff
        # print(bin(C)[2:].rjust(28, '0'))
        # print(bin(D)[2:].rjust(28, '0'))
        self.subKs = []
        for i in range(16):
            if i in (0, 1, 8, 15):
                C = self.L(C, 1)
                D = self.L(D, 1)
            else:
                C, D = self.L(C, 2), self.L(D, 2)
            self.subKs.append(self.Permute((C << 28) | D, 56, self.PC_2))
            # print(hex(self.subKs[i]))



class AESE():
    def __init__(self, blk, key, Nr):
        self.blk = blk
        self.key = key
        self.Nr = Nr
        self.sbox = (0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
                     0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
                     0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
                     0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
                     0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
                     0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
                     0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
                     0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
                     0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
                     0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
                     0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
                     0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
                     0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
                     0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
                     0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
                     0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16)

    def xtime(self, x):
        if (x & 0x80):
            return (((x << 1) ^ 0x1b) & 0xff)
        return x << 1

    def MixColumns(self):
        tmp = [0 for t in range(4)]
        xt = [0 for q in range(4)]
        n = 0
        for x in range(4):
            xt[0] = self.xtime(self.blk[n])
            xt[1] = self.xtime(self.blk[n + 1])
            xt[2] = self.xtime(self.blk[n + 2])
            xt[3] = self.xtime(self.blk[n + 3])
            tmp[0] = xt[0] ^ xt[1] ^ self.blk[n +
                                              1] ^ self.blk[n + 2] ^ self.blk[n + 3]
            tmp[1] = self.blk[n] ^ xt[1] ^ xt[2] ^ self.blk[n + 2] ^ self.blk[n + 3]
            tmp[2] = self.blk[n] ^ self.blk[n +
                                            1] ^ xt[2] ^ xt[3] ^ self.blk[n + 3]
            tmp[3] = xt[0] ^ self.blk[n] ^ self.blk[n +
                                                    1] ^ self.blk[n + 2] ^ xt[3]
            self.blk[n] = tmp[0]
            self.blk[n + 1] = tmp[1]
            self.blk[n + 2] = tmp[2]
            self.blk[n + 3] = tmp[3]
            n = n + 4

    def ShiftRows(self):
        # 2nd row
        t = self.blk[1]
        self.blk[1] = self.blk[5]
        self.blk[5] = self.blk[9]
        self.blk[9] = self.blk[13]
        self.blk[13] = t
        # 3nd row
        t = self.blk[2]
        self.blk[2] = self.blk[10]
        self.blk[10] = t
        t = self.blk[6]
        self.blk[6] = self.blk[14]
        self.blk[14] = t
        # 4nd row
        t = self.blk[15]
        self.blk[15] = self.blk[11]
        self.blk[11] = self.blk[7]
        self.blk[7] = self.blk[3]
        self.blk[3] = t

    def SubBytes(self):
        for x in range(16):
            self.blk[x] = self.sbox[self.blk[x]]

    def AddRoundKey(self, key):
        x = 0
        k = [0 for m in range(16)]
        for c in range(4):
            for r in range(4):
                k[x] = key[r][c]
                x = x + 1
        for y in range(16):
            self.blk[y] ^= int(k[y])

    def show(self):
        for i in range(16):
            print(hex(self.blk[i]))

    def ScheduleKey(self, w, Nk):
        Rcon = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36]
        for r in range(4):
            for c in range(4):
                w[0][r][c] = self.key[r + c * 4]
        for i in range(1, self.Nr + 1, 1):
            for j in range(Nk):
                t = [0 for x in range(4)]
                for r in range(4):
                    if j:
                        t[r] = w[i][r][j - 1]
                    else:
                        t[r] = w[i - 1][r][3]
                if j == 0:
                    temp = t[0]
                    for r in range(3):
                        t[r] = self.sbox[t[(r + 1) % 4]]
                    t[3] = self.sbox[temp]
                    t[0] ^= int(Rcon[i - 1])
                for r in range(4):
                    w[i][r][j] = w[i - 1][r][j] ^ t[r]

    # 加密函数
    def AesEncrypt(self):
        outkey = []
        outkey = [[[0 for col in range(4)]
                   for row in range(4)] for s in range(11)]
        self.ScheduleKey(outkey, 4)
        self.AddRoundKey(outkey[0])
        for x in range(1, self.Nr, 1):
            self.SubBytes()
            self.ShiftRows()
            self.MixColumns()
            self.AddRoundKey(outkey[x])
        self.SubBytes()
        self.ShiftRows()
        self.AddRoundKey(outkey[10])
        cText = ""
        for i in range(16):
            xxl = hex(self.blk[i])
            if (len(xxl) == 3):
                cText += "0" + xxl[2:]
            else:
                cText += xxl[2:]
        return cText


class AESD():
    def __init__(self, blk, key, Nr):
        self.blk = blk
        self.key = key
        self.Nr = Nr
        self.sbox = (0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
                     0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
                     0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
                     0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
                     0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
                     0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
                     0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
                     0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
                     0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
                     0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
                     0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
                     0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
                     0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
                     0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
                     0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
                     0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16)

    def xtime(self, x):
        if (x & 0x80):
            return (((x << 1) ^ 0x1b) & 0xff)
        return x << 1

    def ReMixColumns(self):
        tmp = [0 for q in range(4)]
        xt1 = [0 for w in range(4)]
        xt2 = [0 for e in range(4)]
        xt3 = [0 for r in range(4)]
        n = 0
        for x in range(4):
            xt1[0] = self.xtime(self.blk[n])
            xt1[1] = self.xtime(self.blk[n + 1])
            xt1[2] = self.xtime(self.blk[n + 2])
            xt1[3] = self.xtime(self.blk[n + 3])
            xt2[0] = self.xtime(self.xtime(self.blk[n]))
            xt2[1] = self.xtime(self.xtime(self.blk[n + 1]))
            xt2[2] = self.xtime(self.xtime(self.blk[n + 2]))
            xt2[3] = self.xtime(self.xtime(self.blk[n + 3]))
            xt3[0] = self.xtime(self.xtime(self.xtime(self.blk[n])))
            xt3[1] = self.xtime(self.xtime(self.xtime(self.blk[n + 1])))
            xt3[2] = self.xtime(self.xtime(self.xtime(self.blk[n + 2])))
            xt3[3] = self.xtime(self.xtime(self.xtime(self.blk[n + 3])))
            tmp[0] = xt1[0] ^ xt2[0] ^ xt3[0] ^ self.blk[n + 1] ^ xt1[1] ^ xt3[1] ^ self.blk[n + 2] ^ xt2[2] ^ xt3[2] ^ \
                self.blk[n + 3] ^ xt3[3]
            tmp[1] = self.blk[n] ^ xt3[0] ^ xt1[1] ^ xt2[1] ^ xt3[1] ^ self.blk[n + 2] ^ xt1[2] ^ xt3[2] ^ self.blk[
                n + 3] ^ xt2[3] ^ xt3[3]
            tmp[2] = self.blk[n] ^ xt2[0] ^ xt3[0] ^ self.blk[n + 1] ^ xt3[1] ^ xt1[2] ^ xt2[2] ^ xt3[2] ^ self.blk[
                n + 3] ^ xt1[3] ^ xt3[3]
            tmp[3] = self.blk[n] ^ xt1[0] ^ xt3[0] ^ self.blk[n + 1] ^ xt2[1] ^ xt3[1] ^ self.blk[n + 2] ^ xt3[2] ^ xt1[
                3] ^ xt2[3] ^ xt3[3]
            self.blk[n] = tmp[0]
            self.blk[n + 1] = tmp[1]
            self.blk[n + 2] = tmp[2]
            self.blk[n + 3] = tmp[3]
            n = n + 4

    def ReShiftRows(self):
        # 第二行
        t = self.blk[13]
        self.blk[13] = self.blk[9]
        self.blk[9] = self.blk[5]
        self.blk[5] = self.blk[1]
        self.blk[1] = t
        # 第三行
        t = self.blk[2]
        self.blk[2] = self.blk[10]
        self.blk[10] = t
        t = self.blk[6]
        self.blk[6] = self.blk[14]
        self.blk[14] = t
        # 第四行
        t = self.blk[3]
        self.blk[3] = self.blk[7]
        self.blk[7] = self.blk[11]
        self.blk[11] = self.blk[15]
        self.blk[15] = t

    def ReSubBytes(self):
        for i in range(16):
            for j in range(256):
                if (self.sbox[j] == self.blk[i]):
                    self.blk[i] = j
                    break

    def AddRoundKey(self, key):
        x = 0
        k = [0 for m in range(16)]
        for c in range(4):
            for r in range(4):
                k[x] = key[r][c]
                x = x + 1
        for y in range(16):
            self.blk[y] ^= k[y]

    def ScheduleKey(self, w, Nk):
        Rcon = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36]
        for r in range(4):
            for c in range(4):
                w[0][r][c] = self.key[r + c * 4]
        for i in range(1, self.Nr + 1, 1):
            for j in range(Nk):
                t = [0 for x in range(4)]
                for r in range(4):
                    if j:
                        t[r] = w[i][r][j - 1]
                    else:
                        t[r] = w[i - 1][r][3]
                if j == 0:
                    temp = t[0]
                    for r in range(3):
                        t[r] = self.sbox[t[(r + 1) % 4]]
                    t[3] = self.sbox[temp]
                    t[0] ^= int(Rcon[i - 1])
                for r in range(4):
                    w[i][r][j] = w[i - 1][r][j] ^ t[r]

    def AesDecrpyt(self):
        outkey = []
        outkey = [[[0 for col in range(4)]
                   for row in range(4)] for s in range(11)]
        self.ScheduleKey(outkey, 4)
        self.AddRoundKey(outkey[10])
        self.ReShiftRows()
        self.ReSubBytes()
        for x in range(self.Nr - 1, 0, -1):
            self.AddRoundKey(outkey[x])
            self.ReMixColumns()
            self.ReShiftRows()
            self.ReSubBytes()
        self.AddRoundKey(outkey[0])
        mText = ""
        for x in range(16):
            mText += chr(self.blk[x])
        return mText.rstrip(chr(0))


def aes_encrypt(plainText, skey):
    def StringToListN(string):
        s = [0 for x in range(16)]
        l = len(string)
        for x in range(l):
            s[x] = int(ord(string[x]))
        return s

    cText = ""
    key = StringToListN(skey)
    number = int(len(plainText) / 16)
    if (len(plainText) % 16 != 0):
        number = number + 1
    for i in range(0, number):
        blk = StringToListN(plainText[i * 16:i * 16 + 16])
        a = AESE(blk, key, 10)
        cText = cText + a.AesEncrypt()
    return cText


# RSA算法及必要工具函数

def isPrime(num):
    '''对 Miller-Rabin 素性检测算法的封装，判断一个数是否为素数。'''
    if (num < 2):
        return False

    lowPrimes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41,
                 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97,
                 101, 103, 107, 109, 113, 127, 131, 137, 139, 149,
                 151, 157, 163, 167, 173, 179, 181, 191, 193, 197,
                 199, 211, 223, 227, 229, 233, 239, 241, 251, 257,
                 263, 269, 271, 277, 281, 283, 293, 307, 311, 313,
                 317, 331, 337, 347, 349, 353, 359, 367, 373, 379,
                 383, 389, 397, 401, 409, 419, 421, 431, 433, 439,
                 443, 449, 457, 461, 463, 467, 479, 487, 491, 499,
                 503, 509, 521, 523, 541, 547, 557, 563, 569, 571,
                 577, 587, 593, 599, 601, 607, 613, 617, 619, 631,
                 641, 643, 647, 653, 659, 661, 673, 677, 683, 691,
                 701, 709, 719, 727, 733, 739, 743, 751, 757, 761,
                 769, 773, 787, 797, 809, 811, 821, 823, 827, 829,
                 839, 853, 857, 859, 863, 877, 881, 883, 887, 907,
                 911, 919, 929, 937, 941, 947, 953, 967, 971, 977,
                 983, 991, 997]

    if num in lowPrimes:
        return True

    for prime in lowPrimes:
        if num % prime == 0:
            return False

    return millerRabin(num)


def millerRabin(num):
    '''Miller-Rabin 素性检测算法。'''
    if num <= 2:
        return True if num == 2 else False
    d, s = num - 1, 0

    while d % 2 == 0:
        # 令 num = 2 ^ s * d，其中 d 为一个奇数
        d = d // 2
        s += 1
    x = [0 for _ in range(s + 1)]

    for _ in range(20):
        # 在 [2, num - 1] 区间中挑选一个随机数 a
        a = random.randint(2, num - 1)
        # 计算 (a ^ d) % num 的值
        x[0] = pow(a, d, num)
        for i in range(1, s + 1):
            # 根据二次探测定理排查合数
            x[i] = (x[i - 1] ** 2) % num
            if x[i] == 1 and x[i - 1] != 1 and x[i - 1] != num - 1:
                return False
        if x[s] != 1:
            return False

    return True


def generateLargePrime(keysize=1024):
    '''生成一个大素数，默认生成1024位大素数。'''
    while True:
        num = random.randrange(2 ** (keysize - 1), 2 ** keysize)
        if isPrime(num):
            return num


def gcd(a, b):
    '''返回两个数的最大公约数。'''
    while a != 0:
        a, b = b % a, a
    return b


def modInverse(a, m):
    '''计算数值 a 在数值 m 下的模逆，即 (a * a ^ -1) % m = 1。'''
    if gcd(a, m) != 1:
        return None

    s0, t0, r0 = 1, 0, a
    s1, t1, r1 = 0, 1, m

    while r1 != 0:
        q = r0 // r1
        s1, t1, r1, s0, t0, r0 = (
            s0 - q * s1), (t0 - q * t1), (r0 - q * r1), s1, t1, r1

    return s0 % m


class Key:
    _keysize = 1024

    @classmethod
    def getKeySize(cls):
        '''返回当前的 keySize 表示的数值。'''
        return cls._keysize

    @classmethod
    def setKeySize(cls, size):
        '''设置 keySize 的值。'''
        if size in [64, 128, 256, 512, 1024]:
            cls._keysize = size
        else:
            raise ValueError(
                'The size must be in the [64, 128, 256, 512, 1024].')

    @classmethod
    def getByteSize(cls):
        '''返回当前 keySize 下的 byteSize 表示的数值。'''
        return cls._keysize // 8


def generateKeys(keysize):
    '''生成指定位数的 RSA 公钥和私钥，默认生成1024位公钥和私钥，且名称前缀为 rsa。'''

    # 创建两个大素数 p 和 q，并计算它们的乘积 n
    p, q = generateLargePrime(keysize), generateLargePrime(keysize)
    n = p * q

    # 生成 e，并确保 e 和 (p - 1) * (q - 1) 互素
    while True:
        e = random.randrange(2 ** (keysize - 1), 2 ** (keysize))
        if gcd(e, (p - 1) * (q - 1)) == 1:
            break

    # 计算解密系数 d，并使其在 (p - 1) * (q - 1) 下与 e 互为逆元
    d = modInverse(e, (p - 1) * (q - 1))

    publicKey, privateKey = (n, e), (n, d)

    # print('Public key:', publicKey)
    # print('Private key:', privateKey)

    return (publicKey, privateKey)


def makeKeyFiles(name='rsa', keysize=Key.getKeySize()):
    '''生成对应的 RSA 公钥和私钥文件。'''

    # 防止覆盖已有的公钥和私钥文件
    if os.path.exists('{}_pubkey.txt'.format(name)) or os.path.exists('{}_privkey.txt'.format(name)):
        # print(
        #     'WARNING: The file {}_pubkey.txt or {}_privkey.txt already exists! Use a different name or delete these files and re-run this program.'.format(
        #         name, name))
        return False

    publicKey, privateKey = generateKeys(keysize)  # 生成1024位公钥私钥

    # 将公钥和私钥写入文件中
    with open('{}_pubkey.txt'.format(name), 'wt') as f:
        f.write('{},{}'.format(publicKey[0], publicKey[1]))

    with open('{}_privkey.txt'.format(name), 'wt') as f:
        f.write('{},{}'.format(privateKey[0], privateKey[1]))

    return (publicKey, privateKey)


def delKeyFiles(name='rsa'):
    '''删除已有的 RSA 公钥和私钥文件。'''
    if os.path.exists('{}_pubkey.txt'.format(name)) and os.path.exists('{}_privkey.txt'.format(name)):
        os.remove('{}_pubkey.txt'.format(name))
        os.remove('{}_privkey.txt'.format(name))
        return True
    return False


def bin2dex(binflow):
    '''
    将8位二进制数据流转化为十进制数值。
    如：'01100001' -> 97
    '''
    return int(binflow, 2)


def bytes2int(byteflow):
    '''将 bytes 类型数据转化大整型数值。'''
    return int.from_bytes(byteflow, 'big')


def int2bytes(intflow):
    '''将大整型数值转化为 bytes 类型。'''
    KEYSIZE, BYTESIZE = Key.getKeySize(), Key.getByteSize()

    intflow = bin(intflow).replace('0b', '')
    size = 2 * KEYSIZE
    mod = len(intflow) % size

    # 不足 2 * KEYSIZE 位的补全位 2 * KEYSIZE 位
    if mod:
        space = size - mod
        intflow = '0' * space + intflow
    result = []

    for i in range(2 * BYTESIZE):
        temp = intflow[i * 8:i * 8 + 8]
        result.append(bin2dex(''.join(temp)))

    return bytes(result)


def padding(message, length):
    '''填充函数，将信息根据 PKCS1 填充方案，对字节进行填充。'''
    BYTESIZE = Key.getByteSize()

    mod = length % BYTESIZE
    space = BYTESIZE - mod - 3
    message = bytes(
        [0x00, 0x02] + [random.randint(1, 255)
                        for _ in range(space)] + [0x00]) + message
    return message


def readKeyFile(filename):
    '''读取密钥文件，取出其中的信息：n 和 EorD。'''
    with open(filename, 'rt') as f:
        content = f.read()
    n, EorD = content.split(',')
    return (int(n), int(EorD))


def unpadding(byteflow):
    '''去除填充项，只选择有意义的项。'''
    index = byteflow.rfind(b'\x00')
    return byteflow[index + 1:]


class RSA:
    def __init__(self, message, pubkey, privkey):
        self.message = message
        self.pubkey = pubkey
        self.privkey = privkey
        self.BYTESIZE = Key.getByteSize()

    def ciphertext(self):
        return self.__encrypt()

    def plaintext(self):
        return self.__decrypt()

    def __encrypt(self):
        message = bytes(self.message.encode('utf-8'))
        length, size = len(message), self.BYTESIZE - 11
        result = bytes()

        if length <= size:
            # PKCS1 填充方案
            result = padding(message, length)
            n, e = self.pubkey
            cipherdigit = pow(bytes2int(result), e, n)
            result = int2bytes(cipherdigit)
        else:
            times, mod = divmod(length, size)
            n, e = self.pubkey
            if mod:
                times += 1
            # 分组进行填充
            for i in range(times):
                temp = padding(message[i * size:i * size + size],
                               len(message[i * size:i * size + size]))
                cipherdigit = pow(bytes2int(temp), e, n)
                result += int2bytes(cipherdigit)

        self.write2file(base64.b64encode(result), flag=0)
        return base64.b64encode(result).decode('ascii')

    def __decrypt(self):
        message = base64.b64decode(self.message.encode('ascii'))
        length, size, result = len(message), 2 * self.BYTESIZE, bytes()
        times, mod = divmod(length, size)

        if mod:
            return False

        for i in range(times):
            temp = message[i * size:i * size + size]
            n, d = readKeyFile(self.privkey)
            plaindigit = pow(bytes2int(temp), d, n)
            result += unpadding(int2bytes(plaindigit))

        self.write2file(result, flag=1)
        return result.decode('utf-8')

    @staticmethod
    def write2file(bytesflow, flag=0):
        name = ['ciphertext', 'plaintext']
        with open('{}.txt'.format(name[flag]), 'wb') as f:
            f.write(bytesflow)


class DiffieHellman:
    primes = {
        # 1536-bit
        5: {
            "prime": 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA237327FFFFFFFFFFFFFFFF,
            "generator": 2
        },

        # 2048-bit
        14: {
            "prime": 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF,
            "generator": 2
        },

        # 3072-bit
        15: {
            "prime": 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64ECFB850458DBEF0A8AEA71575D060C7DB3970F85A6E1E4C7ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6BF12FFA06D98A0864D87602733EC86A64521F2B18177B200CBBE117577A615D6C770988C0BAD946E208E24FA074E5AB3143DB5BFCE0FD108E4B82D120A93AD2CAFFFFFFFFFFFFFFFF,
            "generator": 2
        },

    }

    def __init__(self, group=14):
        if group in self.primes:
            self.p = self.primes[group]["prime"]  # 素数
            self.g = self.primes[group]["generator"]  # 原根
        else:
            raise Exception("Group not supported")
        self.secretKey = int(binascii.hexlify(
            os.urandom(32)), base=16)  # 随机生成的私钥

    def get_private_key(self):
        """ Return the private key (a) """
        return self.secretKey

    def gen_public_key(self):
        """ Return A, A = g ^ a mod p """
        # calculate G^a mod p
        return pow(self.g, self.secretKey, self.p)  # 根据私钥计算出的公钥

    def check_other_public_key(self, other_contribution):  # 检测公钥是否合法

        if 2 <= other_contribution and other_contribution <= self.p - 2:
            if pow(other_contribution, (self.p - 1) // 2, self.p) == 1:
                return True
        return False

    def gen_shared_key(self, other_contribution):  # 生成共享密钥，即协商密钥
        """ Return g ^ ab mod p """
        # calculate the shared key G^ab mod p
        if self.check_other_public_key(other_contribution):
            self.shared_key = pow(other_contribution,
                                    self.secretKey, self.p)
            return hashlib.sha256(str(self.shared_key).encode()).hexdigest()
        else:
            raise Exception("Bad public key from other party")

