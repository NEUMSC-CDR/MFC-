# -*- coding: utf-8 -*-
import json
import re
import os
import inspect
import ctypes
import time
import threading
import socket
from algorithms import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import doc
import sys

sys.path.append("./")


class ApplicationCore(QTabWidget):

    signal_write_msg = pyqtSignal(str)
    signal_write_msg_info = pyqtSignal(str)

    def __init__(self, parent=None):
        super(ApplicationCore, self).__init__(parent)
        self.algorithms = algoRithms()
        self.diffieHellman = DiffieHellman()
        self.connectionFlag = False

        self.tab1 = QWidget()
        self.tab2 = QWidget()
        self.tab3 = QWidget()
        self.tab4 = QWidget()
        self.tab5 = QWidget()
        self.tab6 = QWidget()
        self.tab7 = QWidget()
        self.tab8 = QWidget()
        self.tab9 = QWidget()
        self.tab10 = QWidget()
        self.tab11 = QWidget()
        self.tab12 = QWidget()
        self.tab13 = QWidget()
        self.tab14 = QWidget()
        self.tab15 = QWidget()
        self.tab16 = QWidget()
        self.tab17 = QWidget()

        # 设置tabbar属性，全局
        self.tabBar().setStyleSheet("color:rgb(20,20,20);font-size:20px;")

        # self.tab1.setToolTip("关键字密码")
        self.addTab(self.tab1, "Tab 1")
        self.addTab(self.tab2, "Tab 2")
        self.addTab(self.tab3, "Tab 3")
        self.addTab(self.tab4, "Tab 4")
        self.addTab(self.tab5, "Tab 5")
        self.addTab(self.tab6, "Tab 6")
        self.addTab(self.tab7, "Tab 7")
        self.addTab(self.tab8, "Tab 8")
        self.addTab(self.tab9, "Tab 9")
        self.addTab(self.tab10, "Tab 10")
        self.addTab(self.tab11, "Tab 11")
        self.addTab(self.tab12, "Tab 12")
        self.addTab(self.tab13, "Tab 13")
        self.addTab(self.tab14, "Tab 14")
        self.addTab(self.tab15, "Tab 15")
        self.addTab(self.tab16, "Tab 16")
        self.addTab(self.tab17, "Tab 16")


        self.setTabToolTip(1, '凯撒密码')
        self.setTabToolTip(2, '关键字密码')
        self.setTabToolTip(3, '仿射密码')
        self.setTabToolTip(4, '多文字密码')
        self.setTabToolTip(5, '维吉尼亚密码')
        self.setTabToolTip(6, '自动密钥（plaintext）')
        self.setTabToolTip(7, '自动密钥（ciphertext）')
        self.setTabToolTip(8, '普莱费尔密码（Playfair cipher）')
        self.setTabToolTip(9, "矩阵换位密码（permutation cipher）")
        self.setTabToolTip(10, "列置换密码（Column permutation cipher）")
        self.setTabToolTip(11, "双移位密码（Double-Transposition cipher）")
        self.setTabToolTip(12, "流密码 RC4 cipher")
        self.setTabToolTip(13, "分块密码 DES cipher")
        self.setTabToolTip(14, "分块密码 AES cipher")
        self.setTabToolTip(15, "公钥密码 RSA cipher")
        self.setTabToolTip(16, "about me")

        self.tab1UI()
        self.tab2UI()
        self.tab3UI()
        self.tab4UI()
        self.tab5UI()
        self.tab6UI()
        self.tab7UI()
        self.tab8UI()
        self.tab9UI()
        self.tab10UI()
        self.tab11UI()
        self.tab12UI()
        self.tab13UI()
        self.tab14UI()
        self.tab15UI()
        self.tab16UI()
        self.tab17UI()
        self.connect()

        # 信号槽
        # 使用的时候用self.signal_write_msg.emit(self.timeWrapper(msg)) msg='ok\n'
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.rightMenuShow)
        self.setWindowTitle("客户端")
        self.resize(952, 845)
        # 背景色设置
        # palette = QPalette()
        # palette.setBrush(QPalette.Background, Qt.black)
        # self.setPalette(palette)

    def connect(self):
        self.signal_write_msg.connect(self.write_msg)
        self.signal_write_msg_info.connect(self.write_msg_info)

    def write_msg(self, msg):
        # signal_write_msg信号会触发这个函数
        self.textBrowser.insertPlainText(msg)
        # 滚动条移动到结尾
        self.textBrowser.moveCursor(QTextCursor.End)

    def write_msg_info(self,msg):
        self.textBrowser_3.insertPlainText(msg)
        # 滚动条移动到结尾
        self.textBrowser_3.moveCursor(QTextCursor.End)

    # 强制关闭线程的方法

    def _async_raise(self, tid, exc_type):
        tid = ctypes.c_long(tid)
        if not inspect.isclass(exc_type):
            exc_type = type(exc_type)
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(
            tid, ctypes.py_object(exc_type))
        if res == 0:
            raise ValueError("invalid thread id")
        elif res != 1:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, None)
            raise SystemError("PyThreadState_SetAsyncExc failed")

    def stop_thread(self, thread):
        self._async_raise(thread.ident, SystemExit)

    def tcp_client_start(self):
        """
        功能函数，TCP客户端连接其他服务端的方法
        :return:
        """
        self.tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # 检测输入的服务端IP和PORT合法性
        def legalityTest(str1, str2):
            p = re.compile(
                '^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
            if p.match(str1) and str2.isnumeric() and 1 < int(str2) < 65535:
                return True

        if not legalityTest(self.lineEdit_3.text(), self.lineEdit_4.text()):
            msg = '请检查服务端IP和端口'
            self.signal_write_msg.emit(self.timeWrapper(msg))
        else:
            address = (self.lineEdit_3.text(), int(self.lineEdit_4.text()))
            try:
                msg = '正在连接目标服务器'
                self.signal_write_msg.emit(self.timeWrapper(msg))
                self.tcp_socket.connect(address)
            except Exception as e:
                msg = '无法连接目标服务器'
                self.signal_write_msg.emit(self.timeWrapper(msg))
            else:
                self.client_th = threading.Thread(
                    target=self.tcp_client_concurrency, args=(address,))
                self.client_th.start()
                msg = 'TCP客户端已连接至服务端（IP:%s端口:%s）' % address
                self.label_13.setText('已连接至服务端')
                self.signal_write_msg.emit(self.timeWrapper(msg))
                import platform
                dataToSend = json.dumps(['计算机网络名：' + platform.node(), '\n服务端IP：' + socket.gethostbyname(platform.node()), \
                                '\n操作系统及版本：' + platform.platform(),
                                '\n操作系统位数：' + platform.architecture()[1] + " " + platform.architecture()[0], \
                                '\n计算机类型：' + platform.machine(), 'information'])
                self.tcp_send(dataToSend)
                self.signal_write_msg.emit(self.timeWrapper("正在请求服务端信息，发送数据：" + str(json.loads(dataToSend))))

    def tcp_client_concurrency(self, address):
        """
        功能函数，用于TCP客户端创建子线程的方法，阻塞式接收
        :return:
        """
        while True:

            recv_msg = self.tcp_socket.recv(4096)
            if recv_msg:
                msg = recv_msg.decode('utf-8')
                _msg = '来自服务端（IP:{}端口:{}）:{}'.format(
                    address[0], address[1], str(json.loads(msg)))
                self.signal_write_msg.emit(self.timeWrapper(_msg))
                self.dataDecrypt(msg)
            else:
                self.tcp_socket.close()
                msg = '从服务器断开连接'
                self.signal_write_msg.emit(self.timeWrapper(msg))
                break

    def dataDecrypt(self, data):  # data应为list，由json.loads得到 data[-1] == type
        dataFormat = json.loads(data)  # 字符串转为列表
        if dataFormat[-1] == "information":
            for info in dataFormat[:-2]:
                self.signal_write_msg_info.emit(info.encode('utf-8').decode())
        elif dataFormat[-1]=="authentication":
            publicKey_server = dataFormat[0] # 服务端公钥
            self.sharedKey = self.diffieHellman.gen_shared_key(int(publicKey_server)) # 生成共享密钥
            self.tcp_send(
                json.dumps(
                    [str(self.sharedKey),'checkAuthentication'] # 把公钥发给客户端，客户端生成协商密钥传给服务端
                )
            )
            self.signal_write_msg.emit(self.timeWrapper('已收到服务端公钥，协商密钥已生成，发往服务端验证...'))

        elif dataFormat[-1] == 'checkAuthentication':
            if dataFormat[0] == "true":
                self.connectionFlag = True
                self.signal_write_msg.emit(self.timeWrapper('身份认证成功，协商密钥为'+str(self.sharedKey)))

            else:
                self.signal_write_msg.emit(self.timeWrapper('身份认证失败，请重新进行身份认证'))
        elif dataFormat[-1] == "keywords":
            self.plainTextEdit_keywords_2.setPlainText(dataFormat[0])

        elif dataFormat[-1] == "affine":
            self.plainTextEdit_affine_2.setPlainText("affine密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "multiliteral":
            self.plainTextEdit_multiliteral_2.setPlainText("multiliteral密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "vigenere":
            self.plainTextEdit_vigenere_2.setPlainText("vigenere密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "autokey_plaintext":
            self.plainTextEdit_autokey_plaintext_2.setPlainText("autokey_plaintext密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "autokey_ciphertext":
            self.plainTextEdit_autokey_ciphertext_2.setPlainText("autokey_ciphertext密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "playfair":
            self.plainTextEdit_playfair_2.setPlainText("playfair密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "permutation":
            self.plainTextEdit_permutation_2.setPlainText("permutation密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "column_permutation":
            self.plainTextEdit_column_permutation_2.setPlainText("column_permutation密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "double_transposition":
            self.plainTextEdit_double_transposition_2.setPlainText("double_transposition密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "rc4":
            self.plainTextEdit_rc4_2.setPlainText("rc4密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "des":
            self.plainTextEdit_des_2.setPlainText("des密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "aes":
            self.plainTextEdit_aes_2.setPlainText("aes密码的解密结果为：\n"+dataFormat[0])

        elif dataFormat[-1] == "RSA_publicKey":
            self.lineEdit_rsa.setText(dataFormat[0])

        elif dataFormat[-1] == "rsa":
            self.plainTextEdit_rsa_2.setPlainText("rsa密码的解密结果为：\n"+dataFormat[0])

        else:
            pass

    def tcp_send(self, text):
        """
        功能函数，用于TCP服务端和TCP客户端发送消息
        :return: None
        """
        try:
            send_msg = (str(text)).encode('utf-8')
            self.tcp_socket.send(send_msg)  # 发送数据
        except Exception as ret:
            msg = '发送失败'
            self.signal_write_msg.emit(self.timeWrapper(msg))



    def rightMenuShow(self):
        try:
            self.contextMenu = QMenu()
            self.actionA = self.contextMenu.addAction(u'显示全部')
            self.actionB = self.contextMenu.addAction(u'单表替代密码')
            self.actionC = self.contextMenu.addAction(u'多表替代密码')
            self.actionD = self.contextMenu.addAction(u'多图替代密码')
            self.actionE = self.contextMenu.addAction(u'置换密码')
            self.actionF = self.contextMenu.addAction(u'流密码')
            self.actionG = self.contextMenu.addAction(u'分块密码')
            self.actionH = self.contextMenu.addAction(u'公钥密码')

            self.contextMenu.popup(QCursor.pos())  # 2菜单显示的位置
            self.actionA.triggered.connect(self.actionHandlerA)
            self.actionB.triggered.connect(self.actionHandlerB)
            self.actionC.triggered.connect(self.actionHandlerC)
            self.actionD.triggered.connect(self.actionHandlerD)
            self.actionE.triggered.connect(self.actionHandlerE)
            self.actionF.triggered.connect(self.actionHandlerF)
            self.actionG.triggered.connect(self.actionHandlerG)
            self.actionH.triggered.connect(self.actionHandlerH)

            self.contextMenu.show()
        except Exception as e:
            print(e)
    def closeAllTabs(self):
        for i in range(1, 16):
            self.setTabVisible(i, False)
    def actionHandlerA(self):
        for i in range(1, 17):
            self.setTabVisible(i, True)

    def actionHandlerB(self):
        self.closeAllTabs()
        for i in range(1, 5):
            self.setTabVisible(i, True)

    def actionHandlerC(self):
        self.closeAllTabs()
        for i in range(5, 8):
            self.setTabVisible(i, True)

    def actionHandlerD(self):
        self.closeAllTabs()
        self.setTabVisible(8, True)

    def actionHandlerE(self):
        self.closeAllTabs()
        for i in range(9, 12):
            self.setTabVisible(i, True)

    def actionHandlerF(self):
        self.closeAllTabs()
        self.setTabVisible(12, True)

    def actionHandlerG(self):
        self.closeAllTabs()
        self.setTabVisible(13, True)
        self.setTabVisible(14, True)

    def actionHandlerH(self):
        self.closeAllTabs()
        self.setTabVisible(15, True)

    def tab1UI(self):
        self.gridLayoutWidget = QWidget()
        self.gridLayoutWidget.setGeometry(QRect(170, 80, 841, 661))
        self.gridLayoutWidget.setObjectName("gridLayoutWidget")
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setContentsMargins(50, 60, 50, 60)
        self.gridLayout.setObjectName("gridLayout")
        self.label_2 = QLabel()
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 1, 2, 1, 1)
        self.textBrowser = QTextBrowser()
        self.textBrowser.setObjectName("textBrowser")
        self.gridLayout.addWidget(self.textBrowser, 2, 3, 1, 1)
        self.formLayout = QFormLayout()
        self.formLayout.setObjectName("formLayout")
        self.label = QLabel()
        self.label.setObjectName("label")
        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.label)
        self.lineEdit_2 = QLineEdit()
        self.lineEdit_2.setMaximumSize(QSize(200, 16777215))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.lineEdit_2)
        self.label_7 = QLabel()
        self.label_7.setObjectName("label_7")
        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.label_7)
        self.lineEdit_3 = QLineEdit()
        self.lineEdit_3.setMaximumSize(QSize(200, 16777215))
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.lineEdit_3)
        self.label_8 = QLabel()
        self.label_8.setObjectName("label_8")
        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.label_8)
        self.lineEdit_4 = QLineEdit()
        self.lineEdit_4.setMaximumSize(QSize(200, 16777215))
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.lineEdit_4)
        self.label_9 = QLabel()
        self.label_9.setMinimumSize(QSize(0, 50))
        self.label_9.setMaximumSize(QSize(16777215, 16777215))
        self.label_9.setText("")
        self.label_9.setObjectName("label_9")
        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.label_9)
        self.label_10 = QLabel()
        self.label_10.setMinimumSize(QSize(0, 50))
        self.label_10.setMaximumSize(QSize(16777215, 16777215))
        self.label_10.setText("")
        self.label_10.setObjectName("label_10")
        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.label_10)
        self.label_12 = QLabel()
        self.label_12.setMinimumSize(QSize(0, 50))
        self.label_12.setMaximumSize(QSize(16777215, 16777215))
        self.label_12.setObjectName("label_12")
        self.formLayout.setWidget(4, QFormLayout.LabelRole, self.label_12)
        self.label_13 = QLabel()
        self.label_13.setMinimumSize(QSize(0, 50))
        self.label_13.setMaximumSize(QSize(16777215, 16777215))
        self.label_13.setObjectName("label_13")
        self.formLayout.setWidget(4, QFormLayout.FieldRole, self.label_13)
        self.label_14 = QLabel()
        self.label_14.setMinimumSize(QSize(0, 50))
        self.label_14.setMaximumSize(QSize(16777215, 16777215))
        self.label_14.setObjectName("label_14")
        self.formLayout.setWidget(5, QFormLayout.LabelRole, self.label_14)
        self.textBrowser_2 = QTextBrowser()
        self.textBrowser_2.setMaximumSize(QSize(16777215, 16777215))
        self.textBrowser_2.setMinimumSize(QSize(200, 0))
        self.textBrowser_2.setObjectName("textBrowser_2")
        self.formLayout.setWidget(5, QFormLayout.FieldRole, self.textBrowser_2)
        self.label_15 = QLabel()
        self.label_15.setMinimumSize(QSize(0, 50))
        self.label_15.setMaximumSize(QSize(16777215, 16777215))
        self.label_15.setObjectName("label_15")
        self.formLayout.setWidget(6, QFormLayout.LabelRole, self.label_15)
        self.textBrowser_3 = QTextBrowser()
        self.textBrowser_3.setMaximumSize(QSize(16777215, 16777215))
        self.textBrowser_3.setMinimumSize(QSize(200, 0))

        self.textBrowser_3.setObjectName("textBrowser_3")
        self.formLayout.setWidget(6, QFormLayout.FieldRole, self.textBrowser_3)
        self.label_16 = QLabel()
        self.label_16.setMinimumSize(QSize(0, 40))
        self.label_16.setText("")
        self.label_16.setObjectName("label_16")
        self.formLayout.setWidget(7, QFormLayout.LabelRole, self.label_16)
        self.gridLayout.addLayout(self.formLayout, 2, 0, 1, 2)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout.addLayout(self.verticalLayout, 0, 4, 1, 1)
        self.label_3 = QLabel()
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 1, 0, 1, 1)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_5 = QLabel()
        self.label_5.setObjectName("label_5")
        self.horizontalLayout.addWidget(self.label_5)
        self.pushButton_4 = QPushButton()
        self.pushButton_4.setMaximumSize(QSize(160, 16777215))
        self.pushButton_4.setObjectName("pushButton_4")
        self.horizontalLayout.addWidget(self.pushButton_4)
        self.pushButton = QPushButton()
        self.pushButton.setMaximumSize(QSize(160, 16777215))
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout.addWidget(self.pushButton)
        self.gridLayout.addLayout(self.horizontalLayout, 1, 3, 1, 1)
        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.pushButton_3 = QPushButton()
        self.pushButton_3.setMaximumSize(QSize(16777215, 35))
        self.pushButton_3.setMinimumSize(QSize(160, 35))

        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalLayout_2.addWidget(self.pushButton_3)
        self.pushButton_5 = QPushButton()  #
        self.pushButton_5.setMaximumSize(QSize(16777215, 35))
        self.pushButton_5.setObjectName("pushButton_5")
        self.verticalLayout_2.addWidget(self.pushButton_5)
        self.pushButton_7 = QPushButton()
        self.pushButton_7.setMaximumSize(QSize(16777215, 35))
        self.pushButton_7.setObjectName("pushButton_7")
        self.verticalLayout_2.addWidget(self.pushButton_7)
        self.pushButton_6 = QPushButton()
        self.pushButton_6.setMaximumSize(QSize(16777215, 35))
        self.pushButton_6.setObjectName("pushButton_6")
        self.verticalLayout_2.addWidget(self.pushButton_6)
        self.label_6 = QLabel()
        self.label_6.setText("")
        self.label_6.setObjectName("label_6")
        self.verticalLayout_2.addWidget(self.label_6)
        self.gridLayout.addLayout(self.verticalLayout_2, 2, 2, 1, 1)
        self.label_11 = QLabel()
        self.label_11.setGeometry(QRect(0, 0, 72, 50))
        self.label_11.setMinimumSize(QSize(0, 50))
        self.label_11.setMaximumSize(QSize(16777215, 16777215))
        self.label_11.setObjectName("label_11")
        self.label.setText("本机IP")
        self.label_7.setText("服务端IP")
        self.label_8.setText("服务端端口")
        self.lineEdit_4.setText("8888")
        self.label_12.setText("当前状态")
        self.label_13.setText("未连接")
        self.label_14.setText("客户端")
        self.label_15.setText("服务端")
        self.label_3.setText("设置界面")
        self.label_5.setText("操作日志")
        self.pushButton_4.setText("清除日志")
        self.pushButton.setText("导出日志")
        self.pushButton_3.setText("获取本机IP")
        self.pushButton_5.setText("连接服务端")
        self.pushButton_7.setText("身份认证")
        self.pushButton_6.setText("断开连接")
        self.label_11.setText("TextLabel")

        import platform
        self.textBrowser_2.insertPlainText('计算机网络名：' + platform.node())
        self.textBrowser_2.insertPlainText(
            '\n本机IP：' + socket.gethostbyname(platform.node()))
        self.textBrowser_2.insertPlainText('\n操作系统及版本：' + platform.platform())
        # platform.architecture()[1] + " " + platform.architecture()[0]
        self.textBrowser_2.insertPlainText(
            '\n操作系统位数：' + platform.architecture()[1] + " " + platform.architecture()[0])
        self.textBrowser_2.insertPlainText('\n计算机类型：' + platform.machine())
        self.textBrowser_2.setAutoFillBackground(True)

        self.tab1.setLayout(self.gridLayout)
        self.setTabText(0, "连接设置")

        self.pushButton_3.clicked.connect(self.getIp)
        self.pushButton_5.clicked.connect(self.createConnection)
        self.pushButton_6.clicked.connect(self.clearConnection)
        self.pushButton_7.clicked.connect(self.testConnection)
        self.pushButton_4.clicked.connect(self.clearLogs)
        self.pushButton.clicked.connect(self.saveLogs)

        # lab_13显示连接状态

    def getIp(self):
        # 获取本机ip
        self.lineEdit_2.clear()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(('8.8.8.8', 80))
            my_addr = s.getsockname()[0]
            self.lineEdit_ip_local.setText(str(my_addr))
        except Exception as ret:
            # 若无法连接互联网使用，会调用以下方法
            try:
                my_addr = socket.gethostbyname(socket.gethostname())
                self.lineEdit_2.setText(str(my_addr))
            except Exception as ret_e:
                self.signal_write_msg.emit(self.timeWrapper("无法获取ip，请连接网络！"))
        finally:
            s.close()

    def clearConnection(self):
        self.stop_thread(self.client_th)
        self.connectionFlag = False
        self.signal_write_msg.emit(self.timeWrapper("已与服务端断开连接！"))

    def testConnection(self):
        dh = self.diffieHellman # 初始化类，已生成素数和原根
        publicKey = dh.gen_public_key() # 客户端公钥
        self.tcp_send(json.dumps([str(publicKey),'authentication']))
        self.signal_write_msg.emit(self.timeWrapper("执行身份认证，发送DiffieHellman客户端公钥："+str([str(publicKey),'authentication'])))

    def createConnection(self):
        self.tcp_client_start()

    def clearLogs(self):
        self.textBrowser.clear()

    def saveLogs(self):

        if not os.path.exists('logs'):
            os.mkdir('logs')
            os.chdir('logs')
        else:
            os.chdir('logs')
        try:
            logs = self.textBrowser.toPlainText()
            filename = str(time.strftime(
                "%Y%m%d%H%M%S", time.localtime())) + '.txt'
            with open(filename, 'w', encoding='utf-8') as logFile:
                logFile.write(logs)
                msg = "日志文件已保存至logs文件夹中，文件名为" + \
                    str(time.strftime("%Y%m%d%H%M%S", time.localtime())) + ".txt\n"
                self.signal_write_msg.emit(self.timeWrapper(msg))
                os.chdir('..')
        except:
            self.signal_write_msg.emit(self.timeWrapper('日志文件保存失败'))
            os.chdir('..')

    def timeWrapper(self, message):
        if len(message) <= 100:
            return "\n"+str(time.strftime("%m-%d %H:%M:%S", time.localtime())) + " " + message
        else:
            return "\n"+str(time.strftime("%m-%d %H:%M:%S", time.localtime())) + " " + message[:100] + "...."

    # 同理如上
    def tab2UI(self):  # 凯撒密码

        self.setUsesScrollButtons(True)
        self.gridLayout_caesar = QGridLayout()
        self.gridLayout_caesar.setContentsMargins(50, 60, 50, 60)
        # 设置左侧、顶部、右侧和底部边距，以便在布局周围使用。
        self.gridLayout_caesar.setObjectName("gridLayout_caesar")
        self.plainTextEdit_caesar_2 = QPlainTextEdit()
        self.plainTextEdit_caesar_2.setObjectName("plainTextEdit_caesar_2")
        self.gridLayout_caesar.addWidget(
            self.plainTextEdit_caesar_2, 4, 0, 1, 1)
        # QWidget * widget：需要添加的widget
        # fromRow：所在行
        # fromColumn：所在列
        # rowSpan：所占行
        # columnSpan：所占列数
        # alignment：对齐方式
        self.horizontalLayout_caesar = QHBoxLayout()
        self.horizontalLayout_caesar.setObjectName("horizontalLayout_caesar")
        self.label_caesar = QLabel()
        self.label_caesar.setText("")
        self.label_caesar.setObjectName("label_caesar")
        self.horizontalLayout_caesar.addWidget(self.label_caesar)
        self.pushButton_caesar = QPushButton()
        self.pushButton_caesar.setObjectName("pushButton_caesar")
        self.horizontalLayout_caesar.addWidget(self.pushButton_caesar)
        self.label_caesar_3 = QLabel()
        self.label_caesar_3.setText("")
        self.label_caesar_3.setObjectName("label_caesar_3")
        self.horizontalLayout_caesar.addWidget(self.label_caesar_3)
        self.pushButton_caesar_2 = QPushButton()
        self.pushButton_caesar_2.setObjectName("pushButton_caesar_2")
        self.horizontalLayout_caesar.addWidget(self.pushButton_caesar_2)
        self.label_caesar_2 = QLabel()
        self.label_caesar_2.setText("")
        self.label_caesar_2.setObjectName("label_caesar_2")
        self.horizontalLayout_caesar.addWidget(self.label_caesar_2)
        self.gridLayout_caesar.addLayout(
            self.horizontalLayout_caesar, 3, 0, 1, 1)
        self.plainTextEdit_caesar = QPlainTextEdit()
        self.plainTextEdit_caesar.setObjectName("plainTextEdit_caesar")
        self.gridLayout_caesar.addWidget(self.plainTextEdit_caesar, 0, 0, 1, 1)
        self.label_caesar_4 = QLabel()
        self.label_caesar_4.setMaximumSize(QSize(1000000, 20))
        self.label_caesar_4.setText("")
        self.label_caesar_4.setObjectName("label_caesar_3")
        self.gridLayout_caesar.addWidget(self.label_caesar_4, 7, 0, 1, 1)
        self.textBrowser_caesar = QTextBrowser()
        self.textBrowser_caesar.setObjectName("textBrowser_caesar")
        self.gridLayout_caesar.addWidget(self.textBrowser_caesar, 8, 0, 1, 1)
        self.textBrowser_caesar.setHtml(doc.caesar_doc)

        self.plainTextEdit_caesar_2.setPlainText("输出将显示在这里\n")
        self.pushButton_caesar.setText("加密")
        self.pushButton_caesar_2.setText("解密")
        self.plainTextEdit_caesar.setPlainText("输入要加密的文本")
        self.tab2.setLayout(self.gridLayout_caesar)

        self.setTabText(1, "caesar")
        self.pushButton_caesar.clicked.connect(self.caesar_encrypt_button)
        self.pushButton_caesar_2.clicked.connect(self.caesar_decrypt_button)

        # 页面定义好之后，写按钮触发的实践，调用函数，需要用到信号与槽

    def caesar_encrypt_button(self):
        result_list = []

        def caesar_encrypt_all(strings):
            for i in range(1, 27):
                result_list.append(
                    "位移为" + str(i) + "的凯撒：" + self.algorithms.caesar_encrypt(strings, i) + "\n")
            return result_list

        plainText = self.plainTextEdit_caesar.toPlainText()  # 获取文本
        try:
            cipherText = caesar_encrypt_all(plainText)
            self.plainTextEdit_caesar_2.setPlainText(''.join(cipherText))
        except:
            pass

    def caesar_decrypt_button(self):
        if self.connectionFlag:
            self.caesar_encrypt_button()
        else:
            self.plainTextEdit_caesar_2.setPlainText('请先连接至服务端！')

    def tab3UI(self):  # 关键词加密
        self.gridLayout_keywords = QGridLayout()
        self.gridLayout_keywords.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_keywords.setObjectName("gridLayout_keywords")
        self.horizontalLayout_keywords = QHBoxLayout()
        self.horizontalLayout_keywords.setObjectName(
            "horizontalLayout_keywords")
        self.label_keywords = QLabel()
        self.label_keywords.setText("")
        self.label_keywords.setObjectName("label_keywords")
        self.horizontalLayout_keywords.addWidget(self.label_keywords)
        self.pushButton_keywords = QPushButton()
        self.pushButton_keywords.setObjectName("pushButton_keywords")
        self.horizontalLayout_keywords.addWidget(self.pushButton_keywords)
        self.plainTextEdit_keywords_3 = QPlainTextEdit()
        self.plainTextEdit_keywords_3.setMinimumSize(QSize(100, 35))
        self.plainTextEdit_keywords_3.setMaximumSize(QSize(16777215, 35))
        self.plainTextEdit_keywords_3.setLayoutDirection(Qt.LeftToRight)
        self.plainTextEdit_keywords_3.setObjectName("plainTextEdit_keywords_3")
        self.horizontalLayout_keywords.addWidget(
            self.plainTextEdit_keywords_3, 0, Qt.AlignHCenter)
        self.pushButton_keywords_2 = QPushButton()
        self.pushButton_keywords_2.setObjectName("pushButton_keywords_2")
        self.horizontalLayout_keywords.addWidget(self.pushButton_keywords_2)
        self.label_keywords_2 = QLabel()
        self.label_keywords_2.setText("")
        self.label_keywords_2.setObjectName("label_keywords_2")
        self.horizontalLayout_keywords.addWidget(self.label_keywords_2)
        self.gridLayout_keywords.addLayout(
            self.horizontalLayout_keywords, 4, 0, 1, 1)
        self.label_keywords_3 = QLabel()
        self.label_keywords_3.setMaximumSize(QSize(1000000, 20))
        self.label_keywords_3.setText("")
        self.label_keywords_3.setObjectName("label_keywords_3")
        self.gridLayout_keywords.addWidget(self.label_keywords_3, 7, 0, 1, 1)
        self.plainTextEdit_keywords_2 = QPlainTextEdit()
        self.plainTextEdit_keywords_2.setObjectName("plainTextEdit_keywords_2")
        self.gridLayout_keywords.addWidget(
            self.plainTextEdit_keywords_2, 5, 0, 1, 1)
        self.plainTextEdit_keywords = QPlainTextEdit()
        self.plainTextEdit_keywords.setObjectName("plainTextEdit_keywords")
        self.gridLayout_keywords.addWidget(
            self.plainTextEdit_keywords, 0, 0, 1, 1)
        self.textBrowser_keywords = QTextBrowser()
        self.textBrowser_keywords.setObjectName("textBrowser_keywords")
        self.gridLayout_keywords.addWidget(
            self.textBrowser_keywords, 8, 0, 1, 1)
        self.pushButton_keywords.setText("加密")
        self.plainTextEdit_keywords_3.setPlainText("输入密钥")
        self.pushButton_keywords_2.setText("解密")
        self.plainTextEdit_keywords_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_keywords.setPlainText("输入要加密或解密的文本")
        self.textBrowser_keywords.setHtml(doc.keywords_doc)
        self.setTabText(2, "keywords")
        self.tab3.setLayout(self.gridLayout_keywords)
        self.pushButton_keywords.clicked.connect(self.keywords_encrypt_button)
        self.pushButton_keywords_2.clicked.connect(
            self.keywords_decrypt_button)

    def keywords_encrypt_button(self):
        plainText = self.plainTextEdit_keywords.toPlainText()
        key = self.plainTextEdit_keywords_3.toPlainText()
        _key, cipherText = self.algorithms.keywords_encrypt(plainText, key)
        self.plainTextEdit_keywords_2.setPlainText(
            "关键字密码的密钥顺序为：" + _key + "\n" + "关键字密码的加密结果为：" + cipherText)

    def keywords_decrypt_button(self):

        if self.connectionFlag:
            plainText = self.plainTextEdit_keywords.toPlainText()
            key = self.plainTextEdit_keywords_3.toPlainText()
            dataToSend = json.dumps([plainText, key, 'keywords'])
            self.signal_write_msg.emit(self.timeWrapper(
                '\n向服务端请求关键词解密（keywords cipher），发送数据：' + dataToSend))
            self.tcp_send(dataToSend)
        else:
            self.plainTextEdit_keywords_2.setPlainText('请先连接服务端！')

    def tab4UI(self):  # 仿射密码

        self.gridLayout_affine = QGridLayout()
        self.gridLayout_affine.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_affine.setObjectName("gridLayout")
        self.horizontalLayout_affine = QHBoxLayout()
        self.horizontalLayout_affine.setObjectName("horizontalLayout")
        self.label_affine = QLabel()
        self.label_affine.setText("")
        self.label_affine.setObjectName("label")
        self.horizontalLayout_affine.addWidget(self.label_affine)
        self.pushButton_affine = QPushButton()
        self.pushButton_affine.setObjectName("pushButton")
        self.horizontalLayout_affine.addWidget(self.pushButton_affine)
        self.lineEdit_affine = QLineEdit()
        self.lineEdit_affine.setMaximumSize(QSize(100, 16777215))
        self.lineEdit_affine.setObjectName("lineEdit")
        self.horizontalLayout_affine.addWidget(self.lineEdit_affine)
        self.lineEdit_affine_2 = QLineEdit()
        self.lineEdit_affine_2.setMaximumSize(QSize(100, 16777215))
        self.lineEdit_affine_2.setObjectName("lineEdit_2")
        self.horizontalLayout_affine.addWidget(self.lineEdit_affine_2)
        self.pushButton_affine_2 = QPushButton()
        self.pushButton_affine_2.setObjectName("pushButton_2")
        self.horizontalLayout_affine.addWidget(self.pushButton_affine_2)
        self.label_affine_2 = QLabel()
        self.label_affine_2.setText("")
        self.label_affine_2.setObjectName("label_2")
        self.horizontalLayout_affine.addWidget(self.label_affine_2)
        self.gridLayout_affine.addLayout(
            self.horizontalLayout_affine, 4, 0, 1, 1)
        self.label_affine_3 = QLabel()
        self.label_affine_3.setMaximumSize(QSize(1000000, 20))
        self.label_affine_3.setText("")
        self.label_affine_3.setObjectName("label_3")
        self.gridLayout_affine.addWidget(self.label_affine_3, 7, 0, 1, 1)
        self.plainTextEdit_affine_2 = QPlainTextEdit()
        self.plainTextEdit_affine_2.setObjectName("plainTextEdit_2")
        self.gridLayout_affine.addWidget(
            self.plainTextEdit_affine_2, 5, 0, 1, 1)
        self.plainTextEdit_affine = QPlainTextEdit()
        self.plainTextEdit_affine.setObjectName("plainTextEdit")
        self.gridLayout_affine.addWidget(self.plainTextEdit_affine, 0, 0, 1, 1)
        self.textBrowser_affine = QTextBrowser()
        self.textBrowser_affine.setObjectName("textBrowser")
        self.gridLayout_affine.addWidget(self.textBrowser_affine, 8, 0, 1, 1)

        self.pushButton_affine.setText("加密")
        self.lineEdit_affine.setText("key_a")
        self.lineEdit_affine_2.setText("key_b")
        self.pushButton_affine_2.setText("解密")
        self.plainTextEdit_affine_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_affine.setPlainText("输入要加密或解密的文本")
        self.textBrowser_affine.setHtml(doc.affine_doc)

        self.setTabText(3, "affine")
        self.tab4.setLayout(self.gridLayout_affine)
        self.pushButton_affine.clicked.connect(self.affine_encrypt_button)
        self.pushButton_affine_2.clicked.connect(self.affine_decrypt_button)

    def affine_decrypt_button(self):
        if self.connectionFlag:
            key_a = self.lineEdit_affine.text()
            key_b = self.lineEdit_affine_2.text()
            plainText = self.plainTextEdit_affine.toPlainText()

            def gcd(a, b):
                if a < b:
                    a, b = b, a
                while b != 0:
                    temp = a % b
                    a = b
                    b = temp
                return a

            if plainText != "" and plainText.isalpha() and key_a.isnumeric() and key_b.isnumeric() and int(
                    key_a) > 0 and int(key_b) > 0:
                if gcd(int(key_a), 26) == 1:  # 互素
                    dataToSend = json.dumps(
                        [plainText, key_a, key_b, 'affine'])
                    self.signal_write_msg.emit(self.timeWrapper(
                        '\n向服务端请求仿射密码解密（affine cipher），发送数据：' + dataToSend))
                    self.tcp_send(dataToSend)
                else:
                    self.plainTextEdit_affine_2.setPlainText("key_a必须与26互素！")
            else:
                self.plainTextEdit_affine_2.setPlainText("key_a和key_b必须是正整数！")

        else:
            self.plainTextEdit_keywords_2.setPlainText('请先连接服务端！')

    def affine_encrypt_button(self):
        key_a = self.lineEdit_affine.text()
        key_b = self.lineEdit_affine_2.text()
        plainText = self.plainTextEdit_affine.toPlainText()

        def gcd(a, b):
            if a < b:
                a, b = b, a
            while b != 0:
                temp = a % b
                a = b
                b = temp
            return a

        if plainText.isalpha() and key_a.isnumeric() and key_b.isnumeric() and int(key_a) > 0 and int(key_b) > 0:
            if gcd(int(key_a), 26) == 1:  # 互素
                cipherText = self.algorithms.affine_encrypt(
                    plainText, int(key_a), int(key_b))
                self.plainTextEdit_affine_2.setPlainText(
                    "仿射加密的结果为：\n" + cipherText)
            else:
                self.plainTextEdit_affine_2.setPlainText("key_a必须与26互素！")
        else:
            self.plainTextEdit_affine_2.setPlainText(
                "明文只能是英文字母，且key_a和key_b必须是正整数！")

    def tab5UI(self):
        self.gridLayout_multiliteral = QGridLayout()
        self.gridLayout_multiliteral.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_multiliteral.setObjectName("gridLayout_multiliteral")
        self.horizontalLayout_multiliteral = QHBoxLayout()
        self.horizontalLayout_multiliteral.setObjectName(
            "horizontalLayout_multiliteral")
        self.label_multiliteral = QLabel()
        self.label_multiliteral.setText("")
        self.label_multiliteral.setObjectName("label_multiliteral")
        self.horizontalLayout_multiliteral.addWidget(self.label_multiliteral)
        self.pushButton_multiliteral = QPushButton()
        self.pushButton_multiliteral.setObjectName("pushButton_multiliteral")
        self.horizontalLayout_multiliteral.addWidget(
            self.pushButton_multiliteral)
        self.plainTextEdit_multiliteral_3 = QPlainTextEdit()
        self.plainTextEdit_multiliteral_3.setMinimumSize(QSize(100, 35))
        self.plainTextEdit_multiliteral_3.setMaximumSize(QSize(16777215, 35))
        self.plainTextEdit_multiliteral_3.setLayoutDirection(Qt.LeftToRight)
        self.plainTextEdit_multiliteral_3.setObjectName(
            "plainTextEdit_multiliteral_3")
        self.horizontalLayout_multiliteral.addWidget(
            self.plainTextEdit_multiliteral_3, 0, Qt.AlignHCenter)
        self.pushButton_multiliteral_2 = QPushButton()
        self.pushButton_multiliteral_2.setObjectName(
            "pushButton_multiliteral_2")
        self.horizontalLayout_multiliteral.addWidget(
            self.pushButton_multiliteral_2)
        self.label_multiliteral_2 = QLabel()
        self.label_multiliteral_2.setText("")
        self.label_multiliteral_2.setObjectName("label_multiliteral_2")
        self.horizontalLayout_multiliteral.addWidget(self.label_multiliteral_2)
        self.gridLayout_multiliteral.addLayout(
            self.horizontalLayout_multiliteral, 4, 0, 1, 1)
        self.label_multiliteral_3 = QLabel()
        self.label_multiliteral_3.setMaximumSize(QSize(1000000, 20))
        self.label_multiliteral_3.setText("")
        self.label_multiliteral_3.setObjectName("label_multiliteral_3")
        self.gridLayout_multiliteral.addWidget(
            self.label_multiliteral_3, 7, 0, 1, 1)
        self.plainTextEdit_multiliteral_2 = QPlainTextEdit()
        self.plainTextEdit_multiliteral_2.setObjectName(
            "plainTextEdit_multiliteral_2")
        self.gridLayout_multiliteral.addWidget(
            self.plainTextEdit_multiliteral_2, 5, 0, 1, 1)
        self.plainTextEdit_multiliteral = QPlainTextEdit()
        self.plainTextEdit_multiliteral.setObjectName(
            "plainTextEdit_multiliteral")
        self.gridLayout_multiliteral.addWidget(
            self.plainTextEdit_multiliteral, 0, 0, 1, 1)
        self.textBrowser_multiliteral = QTextBrowser()
        self.textBrowser_multiliteral.setObjectName("textBrowser_multiliteral")
        self.gridLayout_multiliteral.addWidget(
            self.textBrowser_multiliteral, 8, 0, 1, 1)
        self.pushButton_multiliteral.setText("加密")
        self.plainTextEdit_multiliteral_3.setPlainText("输入密钥")
        self.pushButton_multiliteral_2.setText("解密")
        self.plainTextEdit_multiliteral_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_multiliteral.setPlainText("输入要加密或解密的文本")
        self.textBrowser_multiliteral.setHtml(doc.multiliteral_doc)
        self.setTabText(4, "multiliteral")
        self.tab5.setLayout(self.gridLayout_multiliteral)
        self.pushButton_multiliteral.clicked.connect(
            self.multiliteral_encrypt_button)
        self.pushButton_multiliteral_2.clicked.connect(
            self.multiliteral_decrypt_button)

    def multiliteral_encrypt_button(self):
        plainText = self.plainTextEdit_multiliteral.toPlainText()
        key = self.plainTextEdit_multiliteral_3.toPlainText()
        if len(key) == 5:
            try:
                cipherText = self.algorithms.multiliteral_encrypt(
                    plainText, key)
                self.plainTextEdit_multiliteral_2.setPlainText(
                    "Multiliteral密码的加密结果为：\n" + cipherText)
            except:
                self.plainTextEdit_multiliteral_2.setPlainText("请检查明文与密钥合法性！")
        else:
            self.plainTextEdit_multiliteral_2.setPlainText(
                "Multiliteral密码的加密密钥必须为五位！")

    def multiliteral_decrypt_button(self):
        if self.connectionFlag:
            plainText = self.plainTextEdit_multiliteral.toPlainText()
            key = self.plainTextEdit_multiliteral_3.toPlainText()
            if len(key) == 5:
                dataToSend = json.dumps([plainText, key, 'multiliteral'])
                self.signal_write_msg.emit(self.timeWrapper(
                    '\n向服务端请求多文字密码解密（multiliteral cipher），发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_multiliteral_2.setPlainText(
                    "Multiliteral密码的加密密钥必须为五位！")
        else:
            self.plainTextEdit_multiliteral_2.setPlainText('请先连接服务端！')

    def tab6UI(self):  # 维吉尼亚加密
        self.gridLayout_vigenere = QGridLayout()
        self.gridLayout_vigenere.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_vigenere.setObjectName("gridLayout_vigenere")
        self.horizontalLayout_vigenere = QHBoxLayout()
        self.horizontalLayout_vigenere.setObjectName(
            "horizontalLayout_vigenere")
        self.label_vigenere = QLabel()
        self.label_vigenere.setText("")
        self.label_vigenere.setObjectName("label_vigenere")
        self.horizontalLayout_vigenere.addWidget(self.label_vigenere)
        self.pushButton_vigenere = QPushButton()
        self.pushButton_vigenere.setObjectName("pushButton_vigenere")
        self.horizontalLayout_vigenere.addWidget(self.pushButton_vigenere)
        self.plainTextEdit_vigenere_3 = QPlainTextEdit()
        self.plainTextEdit_vigenere_3.setMinimumSize(QSize(100, 35))
        self.plainTextEdit_vigenere_3.setMaximumSize(QSize(16777215, 35))
        self.plainTextEdit_vigenere_3.setLayoutDirection(Qt.LeftToRight)
        self.plainTextEdit_vigenere_3.setObjectName("plainTextEdit_vigenere_3")
        self.horizontalLayout_vigenere.addWidget(
            self.plainTextEdit_vigenere_3, 0, Qt.AlignHCenter)
        self.pushButton_vigenere_2 = QPushButton()
        self.pushButton_vigenere_2.setObjectName("pushButton_vigenere_2")
        self.horizontalLayout_vigenere.addWidget(self.pushButton_vigenere_2)
        self.label_vigenere_2 = QLabel()
        self.label_vigenere_2.setText("")
        self.label_vigenere_2.setObjectName("label_vigenere_2")
        self.horizontalLayout_vigenere.addWidget(self.label_vigenere_2)
        self.gridLayout_vigenere.addLayout(
            self.horizontalLayout_vigenere, 4, 0, 1, 1)
        self.label_vigenere_3 = QLabel()
        self.label_vigenere_3.setMaximumSize(QSize(1000000, 20))
        self.label_vigenere_3.setText("")
        self.label_vigenere_3.setObjectName("label_vigenere_3")
        self.gridLayout_vigenere.addWidget(self.label_vigenere_3, 7, 0, 1, 1)
        self.plainTextEdit_vigenere_2 = QPlainTextEdit()
        self.plainTextEdit_vigenere_2.setObjectName("plainTextEdit_vigenere_2")
        self.gridLayout_vigenere.addWidget(
            self.plainTextEdit_vigenere_2, 5, 0, 1, 1)
        self.plainTextEdit_vigenere = QPlainTextEdit()
        self.plainTextEdit_vigenere.setObjectName("plainTextEdit_vigenere")
        self.gridLayout_vigenere.addWidget(
            self.plainTextEdit_vigenere, 0, 0, 1, 1)
        self.textBrowser_vigenere = QTextBrowser()
        self.textBrowser_vigenere.setObjectName("textBrowser_vigenere")
        self.gridLayout_vigenere.addWidget(
            self.textBrowser_vigenere, 8, 0, 1, 1)
        self.pushButton_vigenere.setText("加密")
        self.plainTextEdit_vigenere_3.setPlainText("输入密钥")
        self.pushButton_vigenere_2.setText("解密")
        self.plainTextEdit_vigenere_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_vigenere.setPlainText("输入要加密或解密的文本")
        self.textBrowser_vigenere.setHtml(doc.vigenere_doc)
        self.setTabText(5, "vigenere")
        self.tab6.setLayout(self.gridLayout_vigenere)
        self.pushButton_vigenere.clicked.connect(self.vigenere_encrypt_button)
        self.pushButton_vigenere_2.clicked.connect(
            self.vigenere_decrypt_button)

    def vigenere_encrypt_button(self):
        try:
            plainText = self.plainTextEdit_vigenere.toPlainText()
            key = self.plainTextEdit_vigenere_3.toPlainText()
            cipherText = self.algorithms.vigenere_encrypt(plainText, key)
            self.plainTextEdit_vigenere_2.setPlainText(
                "维吉尼亚密码的加密结果为：\n" + cipherText)
        except:
            self.plainTextEdit_vigenere_2.setPlainText("请检查明文和密钥合法性！")

    def vigenere_decrypt_button(self):
        if self.connectionFlag:
            plainText = self.plainTextEdit_vigenere.toPlainText()
            key = self.plainTextEdit_vigenere_3.toPlainText()
            if plainText.isalpha() and key.isalpha():
                dataToSend = json.dumps([plainText, key, 'vigenere'])
                self.signal_write_msg.emit(self.timeWrapper(
                    '\n向服务端请求维吉尼亚密码解密（vigenere cipher），发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_vigenere_2.setPlainText("请检查明文和密钥合法性！")
        else:
            self.plainTextEdit_vigenere_2.setPlainText('请先连接服务端！')

    def tab7UI(self):  # autokey plaiintext
        self.gridLayout_autokey_plaintext = QGridLayout()
        self.gridLayout_autokey_plaintext.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_autokey_plaintext.setObjectName(
            "gridLayout_autokey_plaintext")
        self.horizontalLayout_autokey_plaintext = QHBoxLayout()
        self.horizontalLayout_autokey_plaintext.setObjectName(
            "horizontalLayout_autokey_plaintext")
        self.label_autokey_plaintext = QLabel()
        self.label_autokey_plaintext.setText("")
        self.label_autokey_plaintext.setObjectName("label_autokey_plaintext")
        self.horizontalLayout_autokey_plaintext.addWidget(
            self.label_autokey_plaintext)
        self.pushButton_autokey_plaintext = QPushButton()
        self.pushButton_autokey_plaintext.setObjectName(
            "pushButton_autokey_plaintext")
        self.horizontalLayout_autokey_plaintext.addWidget(
            self.pushButton_autokey_plaintext)
        self.plainTextEdit_autokey_plaintext_3 = QPlainTextEdit()
        self.plainTextEdit_autokey_plaintext_3.setMinimumSize(QSize(100, 35))
        self.plainTextEdit_autokey_plaintext_3.setMaximumSize(
            QSize(16777215, 35))
        self.plainTextEdit_autokey_plaintext_3.setLayoutDirection(
            Qt.LeftToRight)
        self.plainTextEdit_autokey_plaintext_3.setObjectName(
            "plainTextEdit_autokey_plaintext_3")
        self.horizontalLayout_autokey_plaintext.addWidget(
            self.plainTextEdit_autokey_plaintext_3, 0, Qt.AlignHCenter)
        self.pushButton_autokey_plaintext_2 = QPushButton()
        self.pushButton_autokey_plaintext_2.setObjectName(
            "pushButton_autokey_plaintext_2")
        self.horizontalLayout_autokey_plaintext.addWidget(
            self.pushButton_autokey_plaintext_2)
        self.label_autokey_plaintext_2 = QLabel()
        self.label_autokey_plaintext_2.setText("")
        self.label_autokey_plaintext_2.setObjectName(
            "label_autokey_plaintext_2")
        self.horizontalLayout_autokey_plaintext.addWidget(
            self.label_autokey_plaintext_2)
        self.gridLayout_autokey_plaintext.addLayout(
            self.horizontalLayout_autokey_plaintext, 4, 0, 1, 1)
        self.label_autokey_plaintext_3 = QLabel()
        self.label_autokey_plaintext_3.setMaximumSize(QSize(1000000, 20))
        self.label_autokey_plaintext_3.setText("")
        self.label_autokey_plaintext_3.setObjectName(
            "label_autokey_plaintext_3")
        self.gridLayout_autokey_plaintext.addWidget(
            self.label_autokey_plaintext_3, 7, 0, 1, 1)
        self.plainTextEdit_autokey_plaintext_2 = QPlainTextEdit()
        self.plainTextEdit_autokey_plaintext_2.setObjectName(
            "plainTextEdit_autokey_plaintext_2")
        self.gridLayout_autokey_plaintext.addWidget(
            self.plainTextEdit_autokey_plaintext_2, 5, 0, 1, 1)
        self.plainTextEdit_autokey_plaintext = QPlainTextEdit()
        self.plainTextEdit_autokey_plaintext.setObjectName(
            "plainTextEdit_autokey_plaintext")
        self.gridLayout_autokey_plaintext.addWidget(
            self.plainTextEdit_autokey_plaintext, 0, 0, 1, 1)
        self.textBrowser_autokey_plaintext = QTextBrowser()
        self.textBrowser_autokey_plaintext.setObjectName(
            "textBrowser_autokey_plaintext")
        self.gridLayout_autokey_plaintext.addWidget(
            self.textBrowser_autokey_plaintext, 8, 0, 1, 1)
        self.pushButton_autokey_plaintext.setText("加密")
        self.plainTextEdit_autokey_plaintext_3.setPlainText("输入密钥")
        self.pushButton_autokey_plaintext_2.setText("解密")
        self.plainTextEdit_autokey_plaintext_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_autokey_plaintext.setPlainText("输入要加密或解密的文本")
        self.textBrowser_autokey_plaintext.setHtml(doc.autokey_plaintext_doc)
        self.setTabText(6, "autokeyP")
        self.tab7.setLayout(self.gridLayout_autokey_plaintext)
        self.pushButton_autokey_plaintext.clicked.connect(
            self.autokey_plaintext_encrypt_button)
        self.pushButton_autokey_plaintext_2.clicked.connect(
            self.autokey_plaintext_decrypt_button)

    def autokey_plaintext_encrypt_button(self):
        plainText = self.plainTextEdit_autokey_plaintext.toPlainText()
        key = self.plainTextEdit_autokey_plaintext_3.toPlainText()
        try:
            cipherText = self.algorithms.autokey_plaintext_encrypt(
                plainText, key)
            self.plainTextEdit_autokey_plaintext_2.setPlainText(
                "autokey_plaintext的加密结果为：\n" + cipherText)
        except:
            self.plainTextEdit_autokey_plaintext_2.setPlainText("请检查明文和密钥合法性！")

    def autokey_plaintext_decrypt_button(self):
        if self.connectionFlag:
            plainText = self.plainTextEdit_autokey_plaintext.toPlainText()
            key = self.plainTextEdit_autokey_plaintext_3.toPlainText()
            if plainText.isalpha() and key.isalpha():
                dataToSend = json.dumps([plainText, key, 'autokey_plaintext'])
                self.signal_write_msg.emit(
                    self.timeWrapper('\n向服务端请求自动密钥明文密码解密（autokey_plaintext cipher），发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_autokey_plaintext_2.setPlainText("请检查明文和密钥合法性！")
        else:
            self.plainTextEdit_autokey_plaintext_2.setPlainText('请先连接服务端！')

    def tab8UI(self):  # autokey ciphertext
        self.gridLayout_autokey_ciphertext = QGridLayout()
        self.gridLayout_autokey_ciphertext.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_autokey_ciphertext.setObjectName(
            "gridLayout_autokey_ciphertext")
        self.horizontalLayout_autokey_ciphertext = QHBoxLayout()
        self.horizontalLayout_autokey_ciphertext.setObjectName(
            "horizontalLayout_autokey_ciphertext")
        self.label_autokey_ciphertext = QLabel()
        self.label_autokey_ciphertext.setText("")
        self.label_autokey_ciphertext.setObjectName("label_autokey_ciphertext")
        self.horizontalLayout_autokey_ciphertext.addWidget(
            self.label_autokey_ciphertext)
        self.pushButton_autokey_ciphertext = QPushButton()
        self.pushButton_autokey_ciphertext.setObjectName(
            "pushButton_autokey_ciphertext")
        self.horizontalLayout_autokey_ciphertext.addWidget(
            self.pushButton_autokey_ciphertext)
        self.plainTextEdit_autokey_ciphertext_3 = QPlainTextEdit()
        self.plainTextEdit_autokey_ciphertext_3.setMinimumSize(QSize(100, 35))
        self.plainTextEdit_autokey_ciphertext_3.setMaximumSize(
            QSize(16777215, 35))
        self.plainTextEdit_autokey_ciphertext_3.setLayoutDirection(
            Qt.LeftToRight)
        self.plainTextEdit_autokey_ciphertext_3.setObjectName(
            "plainTextEdit_autokey_ciphertext_3")
        self.horizontalLayout_autokey_ciphertext.addWidget(
            self.plainTextEdit_autokey_ciphertext_3, 0, Qt.AlignHCenter)
        self.pushButton_autokey_ciphertext_2 = QPushButton()
        self.pushButton_autokey_ciphertext_2.setObjectName(
            "pushButton_autokey_ciphertext_2")
        self.horizontalLayout_autokey_ciphertext.addWidget(
            self.pushButton_autokey_ciphertext_2)
        self.label_autokey_ciphertext_2 = QLabel()
        self.label_autokey_ciphertext_2.setText("")
        self.label_autokey_ciphertext_2.setObjectName(
            "label_autokey_ciphertext_2")
        self.horizontalLayout_autokey_ciphertext.addWidget(
            self.label_autokey_ciphertext_2)
        self.gridLayout_autokey_ciphertext.addLayout(
            self.horizontalLayout_autokey_ciphertext, 4, 0, 1, 1)
        self.label_autokey_ciphertext_3 = QLabel()
        self.label_autokey_ciphertext_3.setMaximumSize(QSize(1000000, 20))
        self.label_autokey_ciphertext_3.setText("")
        self.label_autokey_ciphertext_3.setObjectName(
            "label_autokey_ciphertext_3")
        self.gridLayout_autokey_ciphertext.addWidget(
            self.label_autokey_ciphertext_3, 7, 0, 1, 1)
        self.plainTextEdit_autokey_ciphertext_2 = QPlainTextEdit()
        self.plainTextEdit_autokey_ciphertext_2.setObjectName(
            "plainTextEdit_autokey_ciphertext_2")
        self.gridLayout_autokey_ciphertext.addWidget(
            self.plainTextEdit_autokey_ciphertext_2, 5, 0, 1, 1)
        self.plainTextEdit_autokey_ciphertext = QPlainTextEdit()
        self.plainTextEdit_autokey_ciphertext.setObjectName(
            "plainTextEdit_autokey_ciphertext")
        self.gridLayout_autokey_ciphertext.addWidget(
            self.plainTextEdit_autokey_ciphertext, 0, 0, 1, 1)
        self.textBrowser_autokey_ciphertext = QTextBrowser()
        self.textBrowser_autokey_ciphertext.setObjectName(
            "textBrowser_autokey_ciphertext")
        self.gridLayout_autokey_ciphertext.addWidget(
            self.textBrowser_autokey_ciphertext, 8, 0, 1, 1)
        self.pushButton_autokey_ciphertext.setText("加密")
        self.plainTextEdit_autokey_ciphertext_3.setPlainText("输入密钥")
        self.pushButton_autokey_ciphertext_2.setText("解密")
        self.plainTextEdit_autokey_ciphertext_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_autokey_ciphertext.setPlainText("输入要加密或解密的文本")
        self.textBrowser_autokey_ciphertext.setHtml(doc.autokey_ciphertext_doc)
        self.setTabText(7, "autokeyC")
        self.tab8.setLayout(self.gridLayout_autokey_ciphertext)
        self.pushButton_autokey_ciphertext.clicked.connect(
            self.autokey_ciphertext_encrypt_button)
        self.pushButton_autokey_ciphertext_2.clicked.connect(
            self.autokey_ciphertext_decrypt_button)

    def autokey_ciphertext_encrypt_button(self):
        plainText = self.plainTextEdit_autokey_ciphertext.toPlainText()
        key = self.plainTextEdit_autokey_ciphertext_3.toPlainText()
        cipherText = self.algorithms.autokey_ciphertext_encrypt(plainText, key)
        self.plainTextEdit_autokey_ciphertext_2.setPlainText(
            "autokey_ciphertext的加密结果为：\n" + cipherText)

    def autokey_ciphertext_decrypt_button(self):
        if self.connectionFlag:
            plainText = self.plainTextEdit_autokey_ciphertext.toPlainText()
            key = self.plainTextEdit_autokey_ciphertext_3.toPlainText()
            if plainText.isalpha() and key.isalpha():
                dataToSend = json.dumps([plainText, key, 'autokey_ciphertext'])
                self.signal_write_msg.emit(
                    self.timeWrapper('向服务端请求自动密钥暗文密码解密（autokey_ciphertext cipher），发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_autokey_ciphertext_2.setPlainText(
                    "请检查密文和密钥合法性！")
        else:
            self.plainTextEdit_autokey_ciphertext_2.setPlainText('请先连接服务端！')

    def tab9UI(self):  # autokey ciphertext
        self.gridLayout_playfair = QGridLayout()
        self.gridLayout_playfair.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_playfair.setObjectName("gridLayout_playfair")
        self.horizontalLayout_playfair = QHBoxLayout()
        self.horizontalLayout_playfair.setObjectName(
            "horizontalLayout_playfair")
        self.label_playfair = QLabel()
        self.label_playfair.setText("")
        self.label_playfair.setObjectName("label_playfair")
        self.horizontalLayout_playfair.addWidget(self.label_playfair)
        self.pushButton_playfair = QPushButton()
        self.pushButton_playfair.setObjectName("pushButton_playfair")
        self.horizontalLayout_playfair.addWidget(self.pushButton_playfair)
        self.plainTextEdit_playfair_3 = QPlainTextEdit()
        self.plainTextEdit_playfair_3.setMinimumSize(QSize(100, 35))
        self.plainTextEdit_playfair_3.setMaximumSize(QSize(16777215, 35))
        self.plainTextEdit_playfair_3.setLayoutDirection(Qt.LeftToRight)
        self.plainTextEdit_playfair_3.setObjectName("plainTextEdit_playfair_3")
        self.horizontalLayout_playfair.addWidget(
            self.plainTextEdit_playfair_3, 0, Qt.AlignHCenter)
        self.pushButton_playfair_2 = QPushButton()
        self.pushButton_playfair_2.setObjectName("pushButton_playfair_2")
        self.horizontalLayout_playfair.addWidget(self.pushButton_playfair_2)
        self.label_playfair_2 = QLabel()
        self.label_playfair_2.setText("")
        self.label_playfair_2.setObjectName("label_playfair_2")
        self.horizontalLayout_playfair.addWidget(self.label_playfair_2)
        self.gridLayout_playfair.addLayout(
            self.horizontalLayout_playfair, 4, 0, 1, 1)
        self.label_playfair_3 = QLabel()
        self.label_playfair_3.setMaximumSize(QSize(1000000, 20))
        self.label_playfair_3.setText("")
        self.label_playfair_3.setObjectName("label_playfair_3")
        self.gridLayout_playfair.addWidget(self.label_playfair_3, 7, 0, 1, 1)
        self.plainTextEdit_playfair_2 = QPlainTextEdit()
        self.plainTextEdit_playfair_2.setObjectName("plainTextEdit_playfair_2")
        self.gridLayout_playfair.addWidget(
            self.plainTextEdit_playfair_2, 5, 0, 1, 1)
        self.plainTextEdit_playfair = QPlainTextEdit()
        self.plainTextEdit_playfair.setObjectName("plainTextEdit_playfair")
        self.gridLayout_playfair.addWidget(
            self.plainTextEdit_playfair, 0, 0, 1, 1)
        self.textBrowser_playfair = QTextBrowser()
        self.textBrowser_playfair.setObjectName("textBrowser_playfair")
        self.gridLayout_playfair.addWidget(
            self.textBrowser_playfair, 8, 0, 1, 1)
        self.pushButton_playfair.setText("加密")
        self.plainTextEdit_playfair_3.setPlainText("输入密钥")
        self.pushButton_playfair_2.setText("解密")
        self.plainTextEdit_playfair_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_playfair.setPlainText("输入要加密或解密的文本")
        self.textBrowser_playfair.setHtml(doc.playfair_doc)
        self.setTabText(8, "playfair")
        self.tab9.setLayout(self.gridLayout_playfair)
        self.pushButton_playfair.clicked.connect(self.playfair_encrypt_button)
        self.pushButton_playfair_2.clicked.connect(
            self.playfair_decrypt_button)

    def playfair_encrypt_button(self):
        plainText = self.plainTextEdit_playfair.toPlainText()
        key = self.plainTextEdit_playfair_3.toPlainText()
        try:
            cipherText = self.algorithms.playfair_encrypt(plainText, key)
            self.plainTextEdit_playfair_2.setPlainText(
                "playfair的加密结果为：\n" + cipherText)
        except:
            self.plainTextEdit_playfair_2.setPlainText("请检查明文和密钥合法性！")

    def playfair_decrypt_button(self):
        if self.connectionFlag:
            plainText = self.plainTextEdit_playfair.toPlainText()
            key = self.plainTextEdit_playfair_3.toPlainText()
            if plainText.isalpha() and key.isalpha():
                dataToSend = json.dumps([plainText, key, 'playfair'])
                self.signal_write_msg.emit(
                    self.timeWrapper('\n向服务端请求多图密码解密（playfair cipher），发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_playfair_2.setPlainText("请检查密文和密钥合法性！")
        else:
            self.plainTextEdit_playfair_2.setPlainText('请先连接服务端！')

    def tab10UI(self):  # permutation cipher
        self.gridLayout_permutation = QGridLayout()
        self.gridLayout_permutation.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_permutation.setObjectName("gridLayout_permutation")
        self.horizontalLayout_permutation = QHBoxLayout()
        self.horizontalLayout_permutation.setObjectName(
            "horizontalLayout_permutation")
        self.label_permutation = QLabel()
        self.label_permutation.setText("")
        self.label_permutation.setObjectName("label_permutation")
        self.horizontalLayout_permutation.addWidget(self.label_permutation)
        self.pushButton_permutation = QPushButton()
        self.pushButton_permutation.setObjectName("pushButton_permutation")
        self.horizontalLayout_permutation.addWidget(
            self.pushButton_permutation)
        self.plainTextEdit_permutation_3 = QPlainTextEdit()
        self.plainTextEdit_permutation_3.setMinimumSize(QSize(100, 35))
        self.plainTextEdit_permutation_3.setMaximumSize(QSize(16777215, 35))
        self.plainTextEdit_permutation_3.setLayoutDirection(Qt.LeftToRight)
        self.plainTextEdit_permutation_3.setObjectName(
            "plainTextEdit_permutation_3")
        self.horizontalLayout_permutation.addWidget(
            self.plainTextEdit_permutation_3, 0, Qt.AlignHCenter)
        self.pushButton_permutation_2 = QPushButton()
        self.pushButton_permutation_2.setObjectName("pushButton_permutation_2")
        self.horizontalLayout_permutation.addWidget(
            self.pushButton_permutation_2)
        self.label_permutation_2 = QLabel()
        self.label_permutation_2.setText("")
        self.label_permutation_2.setObjectName("label_permutation_2")
        self.horizontalLayout_permutation.addWidget(self.label_permutation_2)
        self.gridLayout_permutation.addLayout(
            self.horizontalLayout_permutation, 4, 0, 1, 1)
        self.label_permutation_3 = QLabel()
        self.label_permutation_3.setMaximumSize(QSize(1000000, 20))
        self.label_permutation_3.setText("")
        self.label_permutation_3.setObjectName("label_permutation_3")
        self.gridLayout_permutation.addWidget(
            self.label_permutation_3, 7, 0, 1, 1)
        self.plainTextEdit_permutation_2 = QPlainTextEdit()
        self.plainTextEdit_permutation_2.setObjectName(
            "plainTextEdit_permutation_2")
        self.gridLayout_permutation.addWidget(
            self.plainTextEdit_permutation_2, 5, 0, 1, 1)
        self.plainTextEdit_permutation = QPlainTextEdit()
        self.plainTextEdit_permutation.setObjectName(
            "plainTextEdit_permutation")
        self.gridLayout_permutation.addWidget(
            self.plainTextEdit_permutation, 0, 0, 1, 1)
        self.textBrowser_permutation = QTextBrowser()
        self.textBrowser_permutation.setObjectName("textBrowser_permutation")
        self.gridLayout_permutation.addWidget(
            self.textBrowser_permutation, 8, 0, 1, 1)
        self.pushButton_permutation.setText("加密")
        self.plainTextEdit_permutation_3.setPlainText("输入密钥")
        self.pushButton_permutation_2.setText("解密")
        self.plainTextEdit_permutation_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_permutation.setPlainText("输入要加密或解密的文本")
        self.textBrowser_permutation.setHtml(doc.permutation_doc)
        self.setTabText(9, "矩阵换位密码")
        self.tab10.setLayout(self.gridLayout_permutation)
        self.pushButton_permutation.clicked.connect(
            self.permutation_encrypt_button)
        self.pushButton_permutation_2.clicked.connect(
            self.permutation_decrypt_button)

    def permutation_encrypt_button(self):
        plainText = self.plainTextEdit_permutation.toPlainText()
        key = self.plainTextEdit_permutation_3.toPlainText()
        try:
            cipherText = self.algorithms.permutation_encrypt(plainText, key)
            self.plainTextEdit_permutation_2.setPlainText(
                "permutation的加密结果为：\n" + cipherText)
        except:
            self.plainTextEdit_permutation_2.setPlainText("请检查明文和密钥的合法性！")

    def permutation_decrypt_button(self):
        if self.connectionFlag:
            plainText = self.plainTextEdit_permutation.toPlainText()
            key = self.plainTextEdit_permutation_3.toPlainText()
            if plainText.isalpha() and key.isalpha():
                dataToSend = json.dumps([plainText, key, 'permutation'])
                self.signal_write_msg.emit(
                    self.timeWrapper('\n向服务端请求置换密码解密（permutation cipher），发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_permutation_2.setPlainText("请检查密文和密钥合法性！")
        else:
            self.plainTextEdit_permutation_2.setPlainText('请先连接服务端！')
    def tab11UI(self):  # column_permutation cipher
        self.gridLayout_column_permutation = QGridLayout()
        self.gridLayout_column_permutation.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_column_permutation.setObjectName(
            "gridLayout_column_permutation")
        self.horizontalLayout_column_permutation = QHBoxLayout()
        self.horizontalLayout_column_permutation.setObjectName(
            "horizontalLayout_column_permutation")
        self.label_column_permutation = QLabel()
        self.label_column_permutation.setText("")
        self.label_column_permutation.setObjectName("label_column_permutation")
        self.horizontalLayout_column_permutation.addWidget(
            self.label_column_permutation)
        self.pushButton_column_permutation = QPushButton()
        self.pushButton_column_permutation.setObjectName(
            "pushButton_column_permutation")
        self.horizontalLayout_column_permutation.addWidget(
            self.pushButton_column_permutation)
        self.plainTextEdit_column_permutation_3 = QPlainTextEdit()
        self.plainTextEdit_column_permutation_3.setMinimumSize(QSize(100, 35))
        self.plainTextEdit_column_permutation_3.setMaximumSize(
            QSize(16777215, 35))
        self.plainTextEdit_column_permutation_3.setLayoutDirection(
            Qt.LeftToRight)
        self.plainTextEdit_column_permutation_3.setObjectName(
            "plainTextEdit_column_permutation_3")
        self.horizontalLayout_column_permutation.addWidget(
            self.plainTextEdit_column_permutation_3, 0, Qt.AlignHCenter)
        self.pushButton_column_permutation_2 = QPushButton()
        self.pushButton_column_permutation_2.setObjectName(
            "pushButton_column_permutation_2")
        self.horizontalLayout_column_permutation.addWidget(
            self.pushButton_column_permutation_2)
        self.label_column_permutation_2 = QLabel()
        self.label_column_permutation_2.setText("")
        self.label_column_permutation_2.setObjectName(
            "label_column_permutation_2")
        self.horizontalLayout_column_permutation.addWidget(
            self.label_column_permutation_2)
        self.gridLayout_column_permutation.addLayout(
            self.horizontalLayout_column_permutation, 4, 0, 1, 1)
        self.label_column_permutation_3 = QLabel()
        self.label_column_permutation_3.setMaximumSize(QSize(1000000, 20))
        self.label_column_permutation_3.setText("")
        self.label_column_permutation_3.setObjectName(
            "label_column_permutation_3")
        self.gridLayout_column_permutation.addWidget(
            self.label_column_permutation_3, 7, 0, 1, 1)
        self.plainTextEdit_column_permutation_2 = QPlainTextEdit()
        self.plainTextEdit_column_permutation_2.setObjectName(
            "plainTextEdit_column_permutation_2")
        self.gridLayout_column_permutation.addWidget(
            self.plainTextEdit_column_permutation_2, 5, 0, 1, 1)
        self.plainTextEdit_column_permutation = QPlainTextEdit()
        self.plainTextEdit_column_permutation.setObjectName(
            "plainTextEdit_column_permutation")
        self.gridLayout_column_permutation.addWidget(
            self.plainTextEdit_column_permutation, 0, 0, 1, 1)
        self.textBrowser_column_permutation = QTextBrowser()
        self.textBrowser_column_permutation.setObjectName(
            "textBrowser_column_permutation")
        self.gridLayout_column_permutation.addWidget(
            self.textBrowser_column_permutation, 8, 0, 1, 1)
        self.pushButton_column_permutation.setText("加密")
        self.plainTextEdit_column_permutation_3.setPlainText("输入密钥")
        self.pushButton_column_permutation_2.setText("解密")
        self.plainTextEdit_column_permutation_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_column_permutation.setPlainText("输入要加密或解密的文本")
        self.textBrowser_column_permutation.setHtml(doc.column_permutation_doc)
        self.setTabText(10, "列置换密码")
        self.tab11.setLayout(self.gridLayout_column_permutation)
        self.pushButton_column_permutation.clicked.connect(
            self.column_permutation_encrypt_button)
        self.pushButton_column_permutation_2.clicked.connect(
            self.column_permutation_decrypt_button)

    def column_permutation_encrypt_button(self):
        try:
            plainText = self.plainTextEdit_column_permutation.toPlainText()
            key = self.plainTextEdit_column_permutation_3.toPlainText()
            cipherText = self.algorithms.column_permutation_encrypt(
                plainText, key)
            self.plainTextEdit_column_permutation_2.setPlainText(
                "column_permutation的加密结果为：\n" + cipherText)
        except:
            self.plainTextEdit_column_permutation_2.setPlainText(
                "请检查密文和密钥合法性！")

    def column_permutation_decrypt_button(self):
        if self.connectionFlag:
            plainText = self.plainTextEdit_column_permutation.toPlainText()
            key = self.plainTextEdit_column_permutation_3.toPlainText()
            if plainText.isalpha() and key.isalpha():
                dataToSend = json.dumps([plainText, key, 'column_permutation'])
                self.signal_write_msg.emit(
                    self.timeWrapper('\n向服务端请求置换密码解密（column_permutation cipher），发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_column_permutation_2.setPlainText(
                    "请检查密文和密钥合法性！")
        else:
            self.plainTextEdit_column_permutation_2.setPlainText('请先连接服务端！')
    def tab12UI(self):  # double_transposition密码

        self.gridLayout_double_transposition = QGridLayout()
        self.gridLayout_double_transposition.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_double_transposition.setObjectName("gridLayout")
        self.horizontalLayout_double_transposition = QHBoxLayout()
        self.horizontalLayout_double_transposition.setObjectName(
            "horizontalLayout")
        self.label_double_transposition = QLabel()
        self.label_double_transposition.setText("")
        self.label_double_transposition.setObjectName("label")
        self.horizontalLayout_double_transposition.addWidget(
            self.label_double_transposition)
        self.pushButton_double_transposition = QPushButton()
        self.pushButton_double_transposition.setObjectName("pushButton")
        self.horizontalLayout_double_transposition.addWidget(
            self.pushButton_double_transposition)
        self.lineEdit_double_transposition = QLineEdit()
        self.lineEdit_double_transposition.setMaximumSize(QSize(100, 16777215))
        self.lineEdit_double_transposition.setObjectName("lineEdit")
        self.horizontalLayout_double_transposition.addWidget(
            self.lineEdit_double_transposition)
        self.lineEdit_double_transposition_2 = QLineEdit()
        self.lineEdit_double_transposition_2.setMaximumSize(
            QSize(100, 16777215))
        self.lineEdit_double_transposition_2.setObjectName("lineEdit_2")
        self.horizontalLayout_double_transposition.addWidget(
            self.lineEdit_double_transposition_2)
        self.pushButton_double_transposition_2 = QPushButton()
        self.pushButton_double_transposition_2.setObjectName("pushButton_2")
        self.horizontalLayout_double_transposition.addWidget(
            self.pushButton_double_transposition_2)
        self.label_double_transposition_2 = QLabel()
        self.label_double_transposition_2.setText("")
        self.label_double_transposition_2.setObjectName("label_2")
        self.horizontalLayout_double_transposition.addWidget(
            self.label_double_transposition_2)
        self.gridLayout_double_transposition.addLayout(
            self.horizontalLayout_double_transposition, 4, 0, 1, 1)
        self.label_double_transposition_3 = QLabel()
        self.label_double_transposition_3.setMaximumSize(QSize(1000000, 20))
        self.label_double_transposition_3.setText("")
        self.label_double_transposition_3.setObjectName("label_3")
        self.gridLayout_double_transposition.addWidget(
            self.label_double_transposition_3, 7, 0, 1, 1)
        self.plainTextEdit_double_transposition_2 = QPlainTextEdit()
        self.plainTextEdit_double_transposition_2.setObjectName(
            "plainTextEdit_2")
        self.gridLayout_double_transposition.addWidget(
            self.plainTextEdit_double_transposition_2, 5, 0, 1, 1)
        self.plainTextEdit_double_transposition = QPlainTextEdit()
        self.plainTextEdit_double_transposition.setObjectName("plainTextEdit")
        self.gridLayout_double_transposition.addWidget(
            self.plainTextEdit_double_transposition, 0, 0, 1, 1)
        self.textBrowser_double_transposition = QTextBrowser()
        self.textBrowser_double_transposition.setObjectName("textBrowser")
        self.gridLayout_double_transposition.addWidget(
            self.textBrowser_double_transposition, 8, 0, 1, 1)

        self.pushButton_double_transposition.setText("加密")
        self.lineEdit_double_transposition.setText("key_a")
        self.lineEdit_double_transposition_2.setText("key_b")
        self.pushButton_double_transposition_2.setText("解密")
        self.plainTextEdit_double_transposition_2.setPlainText("输出将显示在这里\n")
        self.plainTextEdit_double_transposition.setPlainText("输入要加密或解密的文本")
        self.textBrowser_double_transposition.setHtml(
            doc.double_transposition_doc)

        self.setTabText(11, "双移位密码")
        self.tab12.setLayout(self.gridLayout_double_transposition)
        self.pushButton_double_transposition.clicked.connect(
            self.double_transposition_encrypt_button)
        self.pushButton_double_transposition_2.clicked.connect(
            self.double_transposition_decrypt_button)

    def double_transposition_encrypt_button(self):
        try:
            key_a = self.lineEdit_double_transposition.text()
            key_b = self.lineEdit_double_transposition_2.text()
            plainText = self.plainTextEdit_double_transposition.toPlainText()
            cipherText = self.algorithms.double_transposition_encrypt(
                plainText, key_a, key_b)
            self.plainTextEdit_double_transposition_2.setPlainText(
                "double_transposition密码的加密结果为：\n" + cipherText)
        except:
            self.plainTextEdit_double_transposition_2.setPlainText(
                '请检查明文和密钥的合法性！')

    def double_transposition_decrypt_button(self):
        if self.connectionFlag:
            key_a = self.lineEdit_double_transposition.text()
            key_b = self.lineEdit_double_transposition_2.text()
            plainText = self.plainTextEdit_double_transposition.toPlainText()
            if key_a.isalpha() and key_b.isalpha() and plainText.isalpha():
                dataToSend = json.dumps(
                    [plainText, key_a, key_b, 'double_transposition'])
                self.signal_write_msg.emit(
                    self.timeWrapper('\n向服务端请求置换密码解密（double_transposition cipher），发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_double_transposition_2.setPlainText(
                    '请检查明文和密钥的合法性！')
        else:
            self.plainTextEdit_double_transposition_2.setPlainText('请先连接服务端！')
    def tab13UI(self):

        self.gridLayout_rc4 = QGridLayout()
        self.gridLayout_rc4.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_rc4.setObjectName("gridLayout_rc4")
        self.horizontalLayout_rc4 = QHBoxLayout()
        self.horizontalLayout_rc4.setObjectName("horizontalLayout_rc4")
        self.label_rc4 = QLabel()
        self.label_rc4.setText("")
        self.label_rc4.setObjectName("label_rc4")
        self.horizontalLayout_rc4.addWidget(self.label_rc4)
        self.pushButton_rc4 = QPushButton()
        self.pushButton_rc4.setObjectName("pushButton_rc4")
        self.horizontalLayout_rc4.addWidget(self.pushButton_rc4)
        self.lineEdit_rc4_2 = QLineEdit()
        self.lineEdit_rc4_2.setMaximumSize(QSize(200, 16777215))
        self.lineEdit_rc4_2.setObjectName("lineEdit_rc4_2")
        self.horizontalLayout_rc4.addWidget(self.lineEdit_rc4_2)
        self.pushButton_rc4_2 = QPushButton()
        self.pushButton_rc4_2.setObjectName("pushButton_rc4_2")
        self.horizontalLayout_rc4.addWidget(self.pushButton_rc4_2)
        self.label_rc4_2 = QLabel()
        self.label_rc4_2.setText("")
        self.label_rc4_2.setObjectName("label_rc4_2")
        self.horizontalLayout_rc4.addWidget(self.label_rc4_2)
        self.gridLayout_rc4.addLayout(self.horizontalLayout_rc4, 5, 1, 1, 1)
        self.plainTextEdit_rc4_2 = QPlainTextEdit()
        self.plainTextEdit_rc4_2.setObjectName("plainTextEdit_rc4_2")
        self.gridLayout_rc4.addWidget(self.plainTextEdit_rc4_2, 6, 1, 1, 1)
        self.horizontalLayout_rc4_2 = QHBoxLayout()
        self.horizontalLayout_rc4_2.setObjectName("horizontalLayout_rc4_2")
        self.lineEdit_rc4 = QLineEdit()
        self.lineEdit_rc4.setMaximumSize(QSize(400, 16777215))
        self.lineEdit_rc4.setObjectName("lineEdit_rc4")
        self.horizontalLayout_rc4_2.addWidget(self.lineEdit_rc4)
        self.pushButton_rc4_4 = QPushButton()
        self.pushButton_rc4_4.setMaximumSize(QSize(150, 16777215))
        self.pushButton_rc4_4.setObjectName("pushButton_rc4_4")
        self.horizontalLayout_rc4_2.addWidget(self.pushButton_rc4_4)
        self.gridLayout_rc4.addLayout(self.horizontalLayout_rc4_2, 3, 1, 1, 1)
        self.plainTextEdit_rc4 = QPlainTextEdit()
        self.plainTextEdit_rc4.setObjectName("plainTextEdit_rc4")
        self.gridLayout_rc4.addWidget(self.plainTextEdit_rc4, 0, 1, 1, 1)
        self.textBrowser_rc4 = QTextBrowser()
        self.textBrowser_rc4.setObjectName("textBrowser_rc4")
        self.gridLayout_rc4.addWidget(self.textBrowser_rc4, 9, 1, 1, 1)
        self.label_rc4_3 = QLabel()
        self.label_rc4_3.setMaximumSize(QSize(1000000, 20))
        self.label_rc4_3.setText("")
        self.label_rc4_3.setObjectName("label_rc4_3")
        self.gridLayout_rc4.addWidget(self.label_rc4_3, 8, 1, 1, 1)

        self.pushButton_rc4.setText("加密")
        self.pushButton_rc4_2.setText("解密")
        self.plainTextEdit_rc4_2.setPlainText("输出将显示在这里\n")
        self.lineEdit_rc4.setText("点击导入文件导入要加解密的文件（txt）")
        self.pushButton_rc4_4.setText("导入文件")
        self.plainTextEdit_rc4.setPlainText("输入要加密或解密的文本")
        self.textBrowser_rc4.setHtml(doc.rc4_doc)

        self.setTabText(12, "RC4密码")
        self.tab13.setLayout(self.gridLayout_rc4)
        self.pushButton_rc4.clicked.connect(self.rc4_encrypt_button)
        self.pushButton_rc4_2.clicked.connect(self.rc4_decrypt_button)

        self.pushButton_rc4_4.clicked.connect(self.rc4_file_button)

    def rc4_decrypt_button(self):
        if self.connectionFlag:
            key = self.lineEdit_rc4_2.text()  # 得到密钥
            plainText = self.plainTextEdit_rc4.toPlainText()
            if plainText != '' and key != '':
                dataToSend = json.dumps([plainText, key, 'rc4'])
                self.signal_write_msg.emit(
                    self.timeWrapper('向服务端请求流密码解密（RC4 cipher），发送数据：' + dataToSend))
                self.tcp_send(dataToSend)

        else:
            self.plainTextEdit_rc4_2.setPlainText("请先连接服务器！")

    def rc4_encrypt_button(self):
        # self.lineEdit_rc4.text()  # 设置文件名
        key = self.lineEdit_rc4_2.text()  # 得到密钥
        plainText = self.plainTextEdit_rc4.toPlainText()
        try:
            rc4 = RC4()
            cipherText = rc4.rc4_encrypt(plainText, key)
            self.plainTextEdit_rc4_2.setPlainText("RC4加密的结果为：\n" + cipherText)

        except:
            self.plainTextEdit_rc4_2.setPlainText("请检查明文和密钥的合法性！")

    def rc4_file_button(self):
        selectedFile = QFileDialog.getOpenFileName(
            self, "Select one file", "C:", 'Docement ( *.txt )')
        self.lineEdit_rc4.setText(selectedFile[0])
        try:
            with open(selectedFile[0], 'r', encoding='utf-8') as readFile:
                text = readFile.read()
                self.plainTextEdit_rc4.setPlainText(text)
        except:
            pass

    # setValidator(QIntValidator(0, 65535))

    def tab14UI(self):
        self.gridLayout_des = QGridLayout()
        self.gridLayout_des.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_des.setObjectName("gridLayout_des")
        self.horizontalLayout_des = QHBoxLayout()
        self.horizontalLayout_des.setObjectName("horizontalLayout_des")
        self.label_des = QLabel()
        self.label_des.setText("")
        self.label_des.setObjectName("label_des")
        self.horizontalLayout_des.addWidget(self.label_des)
        self.pushButton_des = QPushButton()
        self.pushButton_des.setObjectName("pushButton_des")
        self.horizontalLayout_des.addWidget(self.pushButton_des)
        self.lineEdit_des_2 = QLineEdit()
        self.lineEdit_des_2.setMaximumSize(QSize(200, 16777215))
        self.lineEdit_des_2.setCursorMoveStyle(Qt.LogicalMoveStyle)
        self.lineEdit_des_2.setObjectName("lineEdit_des_2")
        self.horizontalLayout_des.addWidget(self.lineEdit_des_2)
        self.pushButton_des_2 = QPushButton()
        self.pushButton_des_2.setObjectName("pushButton_des_2")
        self.horizontalLayout_des.addWidget(self.pushButton_des_2)
        self.label_des_2 = QLabel()
        self.label_des_2.setText("")
        self.label_des_2.setObjectName("label_des_2")
        self.horizontalLayout_des.addWidget(self.label_des_2)
        self.gridLayout_des.addLayout(self.horizontalLayout_des, 5, 1, 1, 1)
        self.plainTextEdit_des_2 = QPlainTextEdit()
        self.plainTextEdit_des_2.setObjectName("plainTextEdit_des_2")
        self.gridLayout_des.addWidget(self.plainTextEdit_des_2, 6, 1, 1, 1)
        self.horizontalLayout_des_2 = QHBoxLayout()
        self.horizontalLayout_des_2.setObjectName("horizontalLayout_des_2")
        self.lineEdit_des = QLineEdit()
        self.lineEdit_des.setMaximumSize(QSize(400, 16777215))
        self.lineEdit_des.setObjectName("lineEdit_des")
        self.horizontalLayout_des_2.addWidget(self.lineEdit_des)
        self.pushButton_des_4 = QPushButton()
        self.pushButton_des_4.setMaximumSize(QSize(101, 16777215))
        self.pushButton_des_4.setObjectName("pushButton_des_4")
        self.horizontalLayout_des_2.addWidget(self.pushButton_des_4)
        self.gridLayout_des.addLayout(self.horizontalLayout_des_2, 3, 1, 1, 1)
        self.plainTextEdit_des = QPlainTextEdit()
        self.plainTextEdit_des.setObjectName("plainTextEdit_des")
        self.gridLayout_des.addWidget(self.plainTextEdit_des, 0, 1, 1, 1)
        self.textBrowser_des = QTextBrowser()
        self.textBrowser_des.setObjectName("textBrowser_des")
        self.gridLayout_des.addWidget(self.textBrowser_des, 13, 1, 1, 1)
        self.horizontalLayout_des_4 = QHBoxLayout()
        self.horizontalLayout_des_4.setObjectName("horizontalLayout_des_4")
        self.label_des_3 = QLabel()
        self.label_des_3.setMaximumSize(QSize(300, 16777215))
        self.label_des_3.setText("")
        self.label_des_3.setObjectName("label_des_3")
        self.horizontalLayout_des_4.addWidget(self.label_des_3)
        self.pushButton_des_5 = QPushButton()
        self.pushButton_des_5.setMaximumSize(QSize(130, 16777215))
        self.pushButton_des_5.setObjectName("pushButton_des_5")
        self.horizontalLayout_des_4.addWidget(self.pushButton_des_5)
        self.gridLayout_des.addLayout(self.horizontalLayout_des_4, 11, 1, 1, 1)
        self.pushButton_des.setText("加密")
        self.pushButton_des_2.setText("解密")
        self.plainTextEdit_des_2.setPlainText("输出将显示在这里\n")
        self.lineEdit_des.setText("点击导入文件导入要加解密的文件（txt）")
        self.pushButton_des_4.setText("导入文件")
        self.plainTextEdit_des.setPlainText("输入要加密或解密的文本")
        self.pushButton_des_5.setText("保存至文件")
        self.textBrowser_des.setHtml(doc.des_doc)

        self.setTabText(13, "DES加解密")
        self.tab14.setLayout(self.gridLayout_des)
        self.pushButton_des.clicked.connect(self.des_encrypt_button)
        self.pushButton_des_2.clicked.connect(self.des_decrypt_button)

    def des_decrypt_button(self):
        if self.connectionFlag:
            key = self.lineEdit_des_2.text().encode()
            plainText = self.plainTextEdit_des.toPlainText().encode()
            if self.lineEdit_des_2.text() != '' and self.plainTextEdit_des.toPlainText() != '':
                dataToSend = json.dumps([plainText, key, 'des'])
                self.signal_write_msg.emit(
                    self.timeWrapper('向服务端请求分块密码解密（DES cipher）,发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_des_2.setPlainText("请检查明文和密钥的合法性！")
        else:
            self.plainTextEdit_des_2.setPlainText('请先连接服务端！')


            # def des_encrypt_button(self):
        # try:
        #     key = self.lineEdit_des_2.text().encode()
        #     plainText = self.plainTextEdit_des.toPlainText().encode()
        #     des = DES(key)
        #     cipherText = des.Encrypt(plainText)
        #     cipherTextView = binascii.hexlify(cipherText).decode('utf-8')  # str->bytes->hex
        #     self.plainTextEdit_des_2.setPlainText('DES加密后的密文hex为'+cipherTextView)
        # except:
        #     self.plainTextEdit_des_2.setPlainText("请检查明文和密钥的合法性")
    def des_encrypt_button(self):
        try:
            key = self.lineEdit_des_2.text().encode()
            plainText = self.plainTextEdit_des.toPlainText().encode()
            des = DES(key)
            cipherText = des.Encrypt(plainText)
            cipherTextView = des.bytes_hex(cipherText)  # bytes形式
            self.plainTextEdit_des_2.setPlainText(
                "DES加密的结果为（已转换成十六进制）：" + cipherTextView)
        except:
            self.plainTextEdit_des_2.setPlainText("请检查明文和密钥的合法性！")

    def des_file_button(self):
        selectedFile = QFileDialog.getOpenFileName(
            self, "Select one file", "C:", 'Docement ( *.txt )')
        self.lineEdit_des.setText(selectedFile[0])  # 设置文件名
        try:
            with open(selectedFile[0], 'r', encoding='utf-8') as readFile:
                text = readFile.read()
                self.plainTextEdit_des.setPlainText(text)
        except:
            pass

    def tab15UI(self):
        self.gridLayout_aes = QGridLayout()
        self.gridLayout_aes.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_aes.setObjectName("gridLayout_aes")
        self.horizontalLayout_aes = QHBoxLayout()
        self.horizontalLayout_aes.setObjectName("horizontalLayout_aes")
        self.label_aes = QLabel()
        self.label_aes.setText("")
        self.label_aes.setObjectName("label_aes")
        self.horizontalLayout_aes.addWidget(self.label_aes)
        self.pushButton_aes = QPushButton()
        self.pushButton_aes.setObjectName("pushButton_aes")
        self.horizontalLayout_aes.addWidget(self.pushButton_aes)
        self.lineEdit_aes_2 = QLineEdit()
        self.lineEdit_aes_2.setMaximumSize(QSize(200, 16777215))
        self.lineEdit_aes_2.setCursorMoveStyle(Qt.LogicalMoveStyle)
        self.lineEdit_aes_2.setObjectName("lineEdit_aes_2")
        self.horizontalLayout_aes.addWidget(self.lineEdit_aes_2)
        self.pushButton_aes_2 = QPushButton()
        self.pushButton_aes_2.setObjectName("pushButton_aes_2")
        self.horizontalLayout_aes.addWidget(self.pushButton_aes_2)
        self.label_aes_2 = QLabel()
        self.label_aes_2.setText("")
        self.label_aes_2.setObjectName("label_aes_2")
        self.horizontalLayout_aes.addWidget(self.label_aes_2)
        self.gridLayout_aes.addLayout(self.horizontalLayout_aes, 5, 1, 1, 1)
        self.plainTextEdit_aes_2 = QPlainTextEdit()
        self.plainTextEdit_aes_2.setObjectName("plainTextEdit_aes_2")
        self.gridLayout_aes.addWidget(self.plainTextEdit_aes_2, 6, 1, 1, 1)
        self.horizontalLayout_aes_2 = QHBoxLayout()
        self.horizontalLayout_aes_2.setObjectName("horizontalLayout_aes_2")
        self.lineEdit_aes = QLineEdit()
        self.lineEdit_aes.setMaximumSize(QSize(400, 16777215))
        self.lineEdit_aes.setObjectName("lineEdit_aes")
        self.horizontalLayout_aes_2.addWidget(self.lineEdit_aes)
        self.pushButton_aes_4 = QPushButton()
        self.pushButton_aes_4.setMaximumSize(QSize(101, 16777215))
        self.pushButton_aes_4.setObjectName("pushButton_aes_4")
        self.horizontalLayout_aes_2.addWidget(self.pushButton_aes_4)
        self.gridLayout_aes.addLayout(self.horizontalLayout_aes_2, 3, 1, 1, 1)
        self.plainTextEdit_aes = QPlainTextEdit()
        self.plainTextEdit_aes.setObjectName("plainTextEdit_aes")
        self.gridLayout_aes.addWidget(self.plainTextEdit_aes, 0, 1, 1, 1)
        self.textBrowser_aes = QTextBrowser()
        self.textBrowser_aes.setObjectName("textBrowser_aes")
        self.gridLayout_aes.addWidget(self.textBrowser_aes, 13, 1, 1, 1)
        self.horizontalLayout_aes_4 = QHBoxLayout()
        self.horizontalLayout_aes_4.setObjectName("horizontalLayout_aes_4")
        self.label_aes_3 = QLabel()
        self.label_aes_3.setMaximumSize(QSize(300, 16777215))
        self.label_aes_3.setText("")
        self.label_aes_3.setObjectName("label_aes_3")
        self.horizontalLayout_aes_4.addWidget(self.label_aes_3)
        self.pushButton_aes_5 = QPushButton()
        self.pushButton_aes_5.setMaximumSize(QSize(130, 16777215))
        self.pushButton_aes_5.setObjectName("pushButton_aes_5")
        self.horizontalLayout_aes_4.addWidget(self.pushButton_aes_5)
        self.gridLayout_aes.addLayout(self.horizontalLayout_aes_4, 11, 1, 1, 1)
        self.pushButton_aes.setText("加密")
        self.pushButton_aes_2.setText("解密")
        self.plainTextEdit_aes_2.setPlainText("输出将显示在这里\n")
        self.lineEdit_aes.setText("点击导入文件导入要加解密的文件（txt）")
        self.pushButton_aes_4.setText("导入文件")
        self.plainTextEdit_aes.setPlainText("输入要加密或解密的文本")
        self.pushButton_aes_5.setText("保存至文件")
        self.textBrowser_aes.setHtml(doc.aes_doc)

        self.setTabText(14, "AES加解密")
        self.tab15.setLayout(self.gridLayout_aes)
        self.pushButton_aes.clicked.connect(self.aes_encrypt_button)
        self.pushButton_aes_2.clicked.connect(self.aes_decrypt_button)
        self.pushButton_aes_4.clicked.connect(self.aes_file_button)

    def aes_decrypt_button(self):
        if self.connectionFlag:
            key = self.lineEdit_aes_2.text()
            plainText = self.plainTextEdit_aes.toPlainText()
            if len(key.strip()) != 0 and len(plainText.strip()) != 0:
                dataToSend = json.dumps([plainText, key, 'aes'])
                self.signal_write_msg.emit(
                    self.timeWrapper('向服务端请求分块密码解密（AES cipher）,发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            else:
                self.plainTextEdit_aes_2.setPlainText("请检查明文和密钥的合法性！")
        else:
            self.plainTextEdit_aes_2.setPlainText('请先连接服务端！')
    def aes_encrypt_button(self):
        try:
            key = self.lineEdit_aes_2.text()
            plainText = self.plainTextEdit_aes.toPlainText()
            cipherText = aes_encrypt(plainText, key)
            self.plainTextEdit_aes_2.setPlainText("AES加密的结果为：\n" + cipherText)
        except:
            self.plainTextEdit_aes_2.setPlainText("请检查明文和密钥的合法性！")

    def aes_file_button(self):
        selectedFile = QFileDialog.getOpenFileName(
            self, "Select one file", "C:", 'Docement ( *.txt )')
        self.lineEdit_aes.setText(selectedFile[0])  # 设置文件名
        try:
            with open(selectedFile[0], 'r', encoding='utf-8') as readFile:
                text = readFile.read()
                self.plainTextEdit_aes.setPlainText(text)
        except:
            pass

    def tab16UI(self):
        self.gridLayout_rsa = QGridLayout()
        self.gridLayout_rsa.setContentsMargins(50, 60, 50, 60)
        self.gridLayout_rsa.setObjectName("gridLayout_rsa")
        self.horizontalLayout_rsa = QHBoxLayout()
        self.horizontalLayout_rsa.setObjectName("horizontalLayout_rsa")
        self.label_rsa = QLabel()
        self.label_rsa.setText("")
        self.label_rsa.setObjectName("label_rsa")
        self.horizontalLayout_rsa.addWidget(self.label_rsa)
        self.pushButton_rsa = QPushButton()
        self.pushButton_rsa.setObjectName("pushButton_rsa")
        self.horizontalLayout_rsa.addWidget(self.pushButton_rsa)
        self.label_rsa_3 = QLabel()
        self.label_rsa_3.setText("")
        self.label_rsa_3.setObjectName("label_rsa_3")
        self.horizontalLayout_rsa.addWidget(self.label_rsa_3)
        self.pushButton_rsa_2 = QPushButton()
        self.pushButton_rsa_2.setObjectName("pushButton_rsa_2")
        self.horizontalLayout_rsa.addWidget(self.pushButton_rsa_2)
        self.label_rsa_2 = QLabel()
        self.label_rsa_2.setText("")
        self.label_rsa_2.setObjectName("label_rsa_2")
        self.horizontalLayout_rsa.addWidget(self.label_rsa_2)
        self.gridLayout_rsa.addLayout(self.horizontalLayout_rsa, 4, 0, 1, 1)
        self.plainTextEdit_rsa_2 = QPlainTextEdit()
        self.plainTextEdit_rsa_2.setObjectName("plainTextEdit_rsa_2")
        self.gridLayout_rsa.addWidget(self.plainTextEdit_rsa_2, 5, 0, 1, 1)
        self.horizontalLayout_rsa_2 = QHBoxLayout()
        self.horizontalLayout_rsa_2.setObjectName("horizontalLayout_rsa_2")
        self.lineEdit_rsa = QLineEdit()
        self.lineEdit_rsa.setMaximumSize(QSize(400, 16777215))
        self.lineEdit_rsa.setObjectName("lineEdit_rsa")
        self.horizontalLayout_rsa_2.addWidget(self.lineEdit_rsa)
        self.pushButton_rsa_4 = QPushButton()
        self.pushButton_rsa_4.setMaximumSize(QSize(101, 16777215))
        self.pushButton_rsa_4.setObjectName("pushButton_rsa_4")
        self.horizontalLayout_rsa_2.addWidget(self.pushButton_rsa_4)
        self.gridLayout_rsa.addLayout(self.horizontalLayout_rsa_2, 2, 0, 1, 1)
        self.plainTextEdit_rsa = QPlainTextEdit()
        self.plainTextEdit_rsa.setObjectName("plainTextEdit_rsa")
        self.gridLayout_rsa.addWidget(self.plainTextEdit_rsa, 0, 0, 1, 1)
        self.textBrowser_rsa = QTextBrowser()
        self.textBrowser_rsa.setObjectName("textBrowser_rsa")
        self.gridLayout_rsa.addWidget(self.textBrowser_rsa, 11, 0, 1, 1)
        self.pushButton_rsa.setText("加密")
        self.pushButton_rsa_2.setText("解密")
        self.plainTextEdit_rsa_2.setPlainText("输出将显示在这里\n")
        self.lineEdit_rsa.setText("公钥将显示在这里")
        self.pushButton_rsa_4.setText("申请公钥")
        self.plainTextEdit_rsa.setPlainText("输入要加密或解密的文本")
        self.textBrowser_rsa.setHtml(doc.rsa_doc)

        self.setTabText(15, "RSA加解密")
        self.tab16.setLayout(self.gridLayout_rsa)
        self.pushButton_rsa.clicked.connect(self.rsa_encrypt_button)
        self.pushButton_rsa_2.clicked.connect(self.rsa_decrypt_button)
        self.pushButton_rsa_4.clicked.connect(
            self.rsa_publickey_button)  # 申请公钥

    def rsa_encrypt_button(self):
        try:
            plainText = self.plainTextEdit_rsa.toPlainText()
            _list = self.lineEdit_rsa.text().split(',')
            key = tuple([int(_list[0]), int(_list[1])])  # 变成可以直接解析的形式
            res = RSA(plainText, pubkey=key, privkey='')
            self.plainTextEdit_rsa_2.setPlainText(
                "RSA加密的结果为：\n" + res.ciphertext())
        except:
            self.plainTextEdit_rsa_2.setPlainText("请检查明文和公钥的合法性！")

    def rsa_decrypt_button(self):
        if self.connectionFlag:
            try:
                plainText = self.plainTextEdit_rsa.toPlainText()
                _list = self.lineEdit_rsa.text().split(',')
                publickKey = tuple([int(_list[0]), int(_list[1])])  # 变成可以直接解析的形式
                dataToSend = json.dumps([plainText, publickKey, 'rsa'])
                self.signal_write_msg.emit(
                    self.timeWrapper('向服务端请求RSA解密,发送数据：' + dataToSend))
                self.tcp_send(dataToSend)
            except:
                self.plainTextEdit_rsa_2.setPlainText("请检查明文和公钥的合法性！")
        else:
            self.plainTextEdit_rsa_2.setPlainText('请先连接服务端！')
    def rsa_publickey_button(self):
        # publicKey, privateKey = (n, e), (n, d)
        dataToSend = json.dumps(['RSA_publicKey'])
        self.signal_write_msg.emit(
            self.timeWrapper('向服务端请求RSA公钥,发送数据：' + dataToSend))
        self.tcp_send(dataToSend)

        # self.lineEdit_rsa.setText(str(self.publicKey[0])+","+str(self.publicKey[1]))

    def tab17UI(self):
        self.verticalLayout_about = QVBoxLayout()
        self.verticalLayout_about.setContentsMargins(100, 200, 100, 200)
        self.verticalLayout_about.setObjectName("verticalLayout_about")
        self.label_about = QLabel()
        self.label_about.setMaximumSize(QSize(300, 300))
        self.label_about.setText("")
        self.label_about.setPixmap(QPixmap("QcureUi/images/touxiang.jpg"))
        self.label_about.setScaledContents(True)
        self.label_about.setObjectName("label_about")
        self.label.setAlignment(Qt.AlignCenter)
        self.verticalLayout_about.addWidget(self.label_about, 0, Qt.AlignHCenter)
        self.pushButton_about = QPushButton()
        self.pushButton_about.setMaximumSize(QSize(250, 40))
        self.pushButton_about.setMinimumSize(QSize(250, 40))

        self.pushButton_about.setObjectName("pushButton_about")
        self.verticalLayout_about.addWidget(self.pushButton_about, 0, Qt.AlignHCenter)
        self.label_about_2 = QLabel()
        self.label_about_2.setMaximumSize(QSize(320, 100))
        font = QFont()
        font.setFamily("Alef")
        font.setPointSize(12)
        self.label_about_2.setFont(font)
        self.label_about_2.setObjectName("label_about_2")
        self.verticalLayout_about.addWidget(self.label_about_2, 0, Qt.AlignHCenter)
        self.setTabText(16, "关于")
        self.tab17.setLayout(self.verticalLayout_about)
        self.pushButton_about.setText("博客导航")
        self.label_about_2.setText("Copyright 2020.07.04 Wander")
        self.pushButton_about.clicked.connect(self.openUrl)

    def openUrl(self):
        QDesktopServices.openUrl(QUrl('http://nav.iwonder.run'))
