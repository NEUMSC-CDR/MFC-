import sys
sys.path.append("./")
import applicationCore
from PyQt5.QtWidgets import QApplication
from QcureUi import cure

if __name__ == '__main__':
    app = QApplication(sys.argv)
    core = applicationCore.ApplicationCore()
    win = cure.Windows(core,'服务端','QcureUi/images/png.png',theme = 'blue', title = '服务端', ico_path = 'QcureUi/images/png.png')
    core.show()
    sys.exit(app.exec_())



